import argparse
import logging
import multiprocessing
import time
import os
import copy
import matplotlib.pyplot as plt
import numpy as np

from deap import base, creator, tools
from solutions.genetic_algorithm.operators import mutate_shortest_proc_time, mutate_sequence_exchange, pox_crossover
from solutions.NSGA3.nsga3 import association, divide, point_ideal, uniformpoint, point_ideal1, select_FL, select
from solutions.genetic_algorithm.q_learning_hybrid_agent import QLearningHybridAgent
from plotting.drawer import draw_gantt_chart, draw_precedence_relations
from solutions.helper_functions import record_stats, load_parameters, load_job_shop_env

from solutions.genetic_algorithm.operators import (
    variation, init_individual, init_population, repair_precedence_constraints,
    evaluate_individual_double  # 确保导入了原始的评估函数
)

logging.basicConfig(level=logging.INFO)

PARAM_FILE = "configs/genetic_algorithm.toml"
DEFAULT_RESULTS_ROOT = "./results/single_runs"

# --- 并行工作进程的函数 ---
worker_env = None


def init_worker(base_env_to_copy):
    """为每个并行工作进程初始化一个独立的环境副本。"""
    global worker_env
    # 使用 print 而不是 logging，因为 logging 在子进程中配置可能复杂
    print(f"进程 {os.getpid()} 正在初始化其专属的环境...")
    worker_env = copy.deepcopy(base_env_to_copy)


def evaluate_on_worker(individual):
    """在工作进程中执行单个个体的评估。"""
    makespan, total_power, _ = evaluate_individual_double(individual, worker_env)
    return makespan, total_power


# --- 绘图函数 ---
def plot_dual_objective_convergence(min_makespans, min_energies, save_path="results/convergence_dual_axis.png",
                                    window_size=5):
    """绘制双目标收敛曲线图"""

    def moving_average(data, window_size):
        if len(data) < window_size:
            return data
        return np.convolve(data, np.ones(window_size) / window_size, mode='valid')

    # 确保有足够的数据点进行平滑
    if len(min_makespans) < window_size or len(min_energies) < window_size:
        logging.warning("Not enough data points for moving average smoothing. Plotting raw data.")
        smooth_makespans = min_makespans
        smooth_energies = min_energies
    else:
        smooth_makespans = moving_average(min_makespans, window_size)
        smooth_energies = moving_average(min_energies, window_size)

    generations = list(range(len(smooth_makespans)))

    fig, ax1 = plt.subplots(figsize=(10, 7))
    ax1.set_xlabel('Generation')
    ax1.set_ylabel('Min Makespan', color='tab:blue')
    ax1.plot(generations, smooth_makespans, color='tab:blue', label='Min Makespan (Smoothed)')
    ax1.tick_params(axis='y', labelcolor='tab:blue')
    ax1.grid(True, axis='y', linestyle='--', alpha=0.6)

    ax2 = ax1.twinx()
    ax2.set_ylabel('Min Energy', color='tab:orange')
    ax2.plot(generations, smooth_energies, color='tab:orange', label='Min Energy (Smoothed)')
    ax2.tick_params(axis='y', labelcolor='tab:orange')

    fig.suptitle("Convergence Curves of Two Objectives (Smoothed)", fontsize=16)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    logging.info(f"Convergence plot saved to {save_path}")


def initialize_run(pool: multiprocessing.Pool, jobShopEnv, **kwargs):
    """
    初始化DEAP工具箱，并使用并行池评估初始种群。
    """
    toolbox = base.Toolbox()
    # 注册并行的 map 函数，用于大规模种群评估
    toolbox.register("map", pool.map, evaluate_on_worker)

    # 创建类型
    creator.create("Fitness", base.Fitness, weights=(-1.0, -1.0))
    creator.create("Individual", list, fitness=creator.Fitness)

    # 为模拟退火(SA)等单点评估场景，注册一个标准的、非并行的评估函数
    toolbox.register("evaluate_individual_double", evaluate_individual_double, jobShopEnv=jobShopEnv)

    # 注册遗传算子
    toolbox.register("init_individual", init_individual, creator.Individual, kwargs, jobShopEnv=jobShopEnv)
    toolbox.register("population", init_population, toolbox, kwargs['algorithm']['population_size'])

    toolbox.register("mate_TwoPoint", tools.cxTwoPoint)
    toolbox.register("mate_Uniform", tools.cxUniform, indpb=0.5)
    toolbox.register("mate_POX", pox_crossover, nr_preserving_jobs=1)
    toolbox.register("mate_TwoPoint", tools.cxTwoPoint)
    toolbox.register("mutate_machine_selection", mutate_shortest_proc_time)
    toolbox.register("mutate_operation_sequence", mutate_sequence_exchange)

    # 为繁殖选择注册一个专门的算子
    toolbox.register("select_for_mating", tools.selNSGA2)

    # 注册统计和名人堂
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("std", np.std, axis=0)
    stats.register("min", np.min, axis=0)
    stats.register("max", np.max, axis=0)

    # 【关键修改】使用 ParetoFront 作为名人堂，以保存所有非支配解
    hof = tools.ParetoFront()

    # 初始化并评估种群
    initial_population = toolbox.population()

    start_time = time.time()
    fitnesses = toolbox.map(initial_population)  # 调用并行 map
    logging.info(f"---Initial population evaluation took {time.time() - start_time:.4f} seconds ---")

    for ind, fit in zip(initial_population, fitnesses):
        ind.fitness.values = fit

    hof.update(initial_population)
    return initial_population, toolbox, stats, hof

def algo_run(jobShopEnv, population, toolbox, folder, exp_name, stats=None, hof=None, **kwargs):
    gen = 0  # 在 try 块外部初始化 gen
    try:
        if kwargs['output']['plotting']:
            draw_precedence_relations(jobShopEnv)

        logbook = tools.Logbook()
        logbook.header = ["gen"] + (stats.fields if stats else [])
        log_file = kwargs.get('output', {}).get('logbook_file')
        record_stats(0, population, logbook, stats, log_file, [], logging, header=True)
        # record_stats(0, population, logbook, stats, kwargs['output']['logbook'], [], logging)

        min_makespans = [min(ind.fitness.values[0] for ind in population)]
        min_energies = [min(ind.fitness.values[1] for ind in population)]

        uniformPoint = uniformpoint(int(kwargs['algorithm']['population_size'] / 10), 2)

        for gen in range(1, kwargs['algorithm']['ngen'] + 1):
            gentime = time.time()  # 整代总耗时开始计时
            total_gens = kwargs['algorithm']['ngen']

            if gen <= total_gens * 0.3:
                sa_prob = 0.2
            elif gen <= total_gens * 0.7:
                sa_prob = 0.5
            else:
                sa_prob = 0.8
            # SA概率
            logging.info(f"Gen {gen}/{total_gens} [sa_prob={sa_prob}]")

            k_value = kwargs['algorithm']['population_size']

            # 1、繁殖选择 (Mating Selection) 使用selNSGA2从当前种群中选择优秀的父母
            mating_pool = toolbox.select_for_mating(population, k=k_value)
            # 2、生成后代 (Variation) 让 variation 函数从我们选出的 mating_pool 中选择父母，而不是从整个 population 中随机选择

            offspring = variation(mating_pool, toolbox, kwargs['algorithm']['population_size'],
                                  kwargs['algorithm']['cr'], kwargs['algorithm']['indpb'],
                                  jobShopEnv=jobShopEnv, sa_prob=sa_prob)

            if '/dafjs/' in jobShopEnv.instance_name or '/yfjs/' in jobShopEnv.instance_name:
                offspring = repair_precedence_constraints(jobShopEnv, offspring)

            eval_start_time = time.time()  # 评估耗时开始计时
            fitnesses = toolbox.map(offspring)
            # 日志点 2: 评估耗时 (已存在，但我们用自己的计时器让格式更统一)
            logging.info(f"---evaluation took {time.time() - eval_start_time:.4f} seconds ---")

            for ind, fit in zip(offspring, fitnesses):
                ind.fitness.values = fit

            # 3、环境选择 (Environmental Selection) - NSGA-III 的核心
            combinspring = offspring + population
            answer = [ind.fitness.values for ind in combinspring]

            # 非支配排序耗时
            divide_start_time = time.time()
            fronts = divide(answer)
            logging.info(f"---divide took {time.time() - divide_start_time:.4f} seconds ---")

            # 第一阶段选择耗时
            select_pre_fl_start_time = time.time()
            population, FL_individuals, num_select = select_FL(kwargs['algorithm']['population_size'], fronts,
                                                               combinspring)
            logging.info(f"---select_pre_FL took {time.time() - select_pre_fl_start_time:.4f} seconds ---")

            # 第二阶段选择耗时
            if num_select != 0:
                select_in_fl_start_time = time.time()
                answer_pop = [ind.fitness.values for ind in population]
                ideal_answer_pop, ideal_point = point_ideal1(answer_pop, 0)
                point_assoc_pop, _ = association(ideal_answer_pop, uniformPoint)

                answer_fl = [ind.fitness.values for ind in FL_individuals]
                ideal_answer_fl, _ = point_ideal1(answer_fl, ideal_point)
                point_assoc_fl, d_min_fl = association(ideal_answer_fl, uniformPoint)

                sel_ind = select(num_select, point_assoc_fl, point_assoc_pop, d_min_fl)
                for indx in sel_ind:
                    population.append(FL_individuals[indx])
                logging.info(f"---select in FL took {time.time() - select_in_fl_start_time:.4f} seconds ---")

            hof.update(population)
            # 整代总耗时
            logging.info(f"---Gen {gen} total time: {time.time() - gentime:.4f} seconds ---")

            record_stats(gen, population, logbook, stats, log_file, [], logging, header=False)
            # record_stats(gen, population, logbook, stats, kwargs['output']['logbook'], [], logging)

            min_makespans.append(min(ind.fitness.values[0] for ind in population))
            min_energies.append(min(ind.fitness.values[1] for ind in population))

        # --- 算法主循环结束 ---
        logging.info("=" * 50)
        logging.info("Algorithm run finished. Final Results:")

        if not hof:
            logging.warning("The Hall of Fame (Pareto Front) is empty. Cannot determine best solution.")
            return None

        # 1. 自动保存最终的 Pareto 前沿数据
        try:
            final_pf_values = np.array([ind.fitness.values for ind in hof])
            problem_name = kwargs['instance']['problem_instance'].split('/')[-1].replace('.txt', '')

            # 【关键修改】在文件名中加入时间戳，避免覆盖
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            output_filename = f"{problem_name}_pareto_front_{timestamp}.txt"

            output_path = os.path.join(folder, exp_name.strip("/"), output_filename)
            np.savetxt(output_path, final_pf_values, fmt='%.4f', header="Makespan Energy", comments="")
            logging.info(f"==> Final Pareto front with {len(hof)} solutions saved to: {output_path}")
        except Exception as e:
            logging.error(f"Failed to save the final Pareto front data. Error: {e}")

        # 2. 评估并打印 makespan 最小的那个解作为代表
        best_makespan_ind = min(hof, key=lambda ind: ind.fitness.values[0])
        final_env_for_eval = copy.deepcopy(jobShopEnv)
        # 【关键修改】使用我们注册的本地评估器
        makespan, total_power, drawn_env = toolbox.evaluate_individual_double(best_makespan_ind)
        logging.info(f"Representative solution (min makespan): Makespan={makespan}, Energy={total_power}")
        logging.info("=" * 50)

        # 3. 绘图
        if kwargs['output']['plotting']:
            logging.info("Generating final Gantt chart and convergence plot...")
            draw_gantt_chart(drawn_env)

            convergence_filename = f"convergence_{timestamp}.png"
            convergence_path = os.path.join(folder, exp_name.strip("/"), convergence_filename)
            plot_dual_objective_convergence(min_makespans, min_energies, save_path=convergence_path)

        return hof, min_makespans, min_energies

    except Exception as e:
        current_gen_info = f"at generation {gen}"
        logging.error(f"An error occurred during the algorithm run {current_gen_info}: {e}", exc_info=True)
        return None, [], []

def main(param_file=PARAM_FILE):
    """
    主逻辑，负责加载配置、创建并行池和启动算法。
    """
    try:
        parameters = load_parameters(param_file)
    except FileNotFoundError:
        logging.error(f"Parameter file {param_file} not found.")
        return

    try:
        base_jobShopEnv = load_job_shop_env(parameters['instance']['problem_instance'])
    except FileNotFoundError:
        logging.error(f"Problem instance {parameters['instance']['problem_instance']} not found.")
        return

    try:
        # 使用 with 管理并行池
        with multiprocessing.Pool(processes=parameters['algorithm'].get('processes', 11),
                                  initializer=init_worker,
                                  initargs=(base_jobShopEnv,)) as pool:

            folder = (
                    DEFAULT_RESULTS_ROOT
                    + "/"
                    + parameters['instance']['problem_instance'].split('/')[-1].replace('.txt', '')
                    + "/ngen" + str(parameters['algorithm']["ngen"])
                    + "_pop" + str(parameters['algorithm']['population_size'])
            )
            exp_name = ("/rseed" + str(parameters['algorithm']["rseed"]) + "/")
            os.makedirs(os.path.join(folder, exp_name.strip("/")), exist_ok=True)

            init_results = initialize_run(pool, base_jobShopEnv, **parameters)
            if not all(init_results):
                logging.error("Initialization failed. Exiting.")
                return

            population, toolbox, stats, hof = init_results
            final_pareto_front = algo_run(base_jobShopEnv, population, toolbox, folder, exp_name, stats, hof,
                                          **parameters)

            if final_pareto_front:
                logging.info("Main process finished successfully.")
            else:
                logging.warning("Main process finished with errors.")
            return final_pareto_front

    except Exception as e:
        logging.error(f"An error occurred in the main process: {e}", exc_info=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run NSGA-III for Job Shop Scheduling (Parallel Version)")
    parser.add_argument("config_file", metavar='-f', type=str, nargs="?", default=PARAM_FILE)
    args = parser.parse_args()
    main(param_file=args.config_file)