from typing import List, Dict
from scheduling_environment.machine import Machine
from scheduling_environment.job import Job
from scheduling_environment.operation import Operation


class JobShop:
    def __init__(self) -> None:
        self._nr_of_jobs = 0
        self._nr_of_machines = 0
        self._jobs: List[Job] = []
        self._operations: List[Operation] = []
        self._machines: List[Machine] = []
        self._precedence_relations_jobs: Dict[int, List[int]] = {}
        self._precedence_relations_operations: Dict[int, List[int]] = {}
        self._sequence_dependent_setup_times: List = []
        self._operations_to_be_scheduled: List[Operation] = []
        self._operations_available_for_scheduling: List[Operation] = []
        self._scheduled_operations: List[Operation] = []
        self._name: str = ""
        self.machine_ready_offsets = None  # 新增：用于存储重调度时的机器起始时间

    # def reset(self):
    #
    #     self._makespan = 0
    #     self._total_machinepower = 0
    #
    #     self._scheduled_operations = []
    #
    #     self._operations_to_be_scheduled = [
    #         operation for operation in self._operations]
    #
    #     self._operations_available_for_scheduling = []
    #
    #     for machine in self._machines:
    #         machine.reset()
    #
    #     for operation in self._operations:
    #         operation.reset()


    def reset(self, ready_times=None):

        self._makespan = 0
        self._total_machinepower = 0
        self._scheduled_operations = []
        self._operations_to_be_scheduled = [
            operation for operation in self._operations]

        self._operations_available_for_scheduling = []

        # 记录偏移量
        self.machine_ready_offsets = ready_times

        for i, machine in enumerate(self._machines):
            machine.reset()
            # 如果传入了就绪时间（重调度场景），强制设置机器的起始空闲时刻
            if ready_times is not None:
                # 假设 Machine 类有 current_end_time 属性控制最早可用时间
                # 这种方式可以防止算法把工序排在故障维修期间
                machine.current_end_time = ready_times[i]

        for operation in self._operations:
            operation.reset()


    def __str__(self):
        return f"Instance {self._name}, {self.nr_of_jobs} jobs, {len(self.operations)} operations, {len(self.machines)} machines"

    def set_nr_of_jobs(self, nr_of_jobs: int) -> None:
        """Set the number of jobs."""
        self._nr_of_jobs = nr_of_jobs

    def set_nr_of_machines(self, nr_of_machines: int) -> None:
        """Set the number of jobs."""
        self._nr_of_machines = nr_of_machines

    def add_operation(self, operation) -> None:
        """Add an operation to the environment."""
        self._operations_to_be_scheduled.append(operation)
        self._operations.append(operation)

    def add_machine(self, machine) -> None:
        """Add a machine to the environment."""
        self._machines.append(machine)

    def add_job(self, job) -> None:
        """Add a job to the environment."""
        self._jobs.append(job)

    def add_precedence_relations_jobs(self, precedence_relations_jobs: Dict[int, List[int]]) -> None:
        """Add precedence relations between jobs --> applicable for assembly scheduling problems."""
        self._precedence_relations_jobs = precedence_relations_jobs

    def add_precedence_relations_operations(self, precedence_relations_operations: Dict[int, List[int]]) -> None:
        """Add precedence relations between operations."""
        self._precedence_relations_operations = precedence_relations_operations

    def add_sequence_dependent_setup_times(self, sequence_dependent_setup_times: List) -> None:
        """Add sequence dependent setup times."""
        self._sequence_dependent_setup_times = sequence_dependent_setup_times

    def set_operations_available_for_scheduling(self, operations_available_for_scheduling: List) -> None:
        """Set the operations that are available for scheduling."""
        self._operations_available_for_scheduling = operations_available_for_scheduling

    # 在 JobShop 类中添加
    def inject_machine_breakdown(self, machine_id, event_time, repair_duration):
        """
        machine_id: 故障机器索引 (0-indexed)
        event_time: 故障发生时刻
        repair_duration: 维修持续时间
        """
        self.breakdown_info = {
            'm_id': machine_id,
            't_event': event_time,
            'duration': repair_duration
        }

    # 在 JobShop 类中添加:
    def get_current_state_snapshot(self):
        """获取当前车间所有工序的加工状态，用于重调度"""
        return {
            'scheduled_ops': [op for op in self.operations_to_be_scheduled if op.is_completed],
            'machine_end_times': [m.current_end_time for m in self.machines]
        }

    # 在 JobShop 类中添加：
    def apply_breakdown(self, breakdown_machine, start_time, duration):
        """手动注入故障，将机器可用时间顺延"""
        machine = self.machines[breakdown_machine]
        # 如果机器当前时间小于故障时间，则直接推迟到故障结束；否则从当前时间开始推迟
        machine.current_end_time = max(machine.current_end_time, start_time + duration)

    def get_job(self, job_id):
        """Return operation object with operation id."""
        return next((job for job in self.jobs if job.job_id == job_id), None)

    def get_operation(self, operation_id):
        """Return operation object with operation id."""
        return next((operation for operation in self.operations if operation.operation_id == operation_id), None)

    def get_machine(self, machine_id):
        """Return machine object with machine id."""
        for machine in self._machines:
            if machine.machine_id == machine_id:
                return machine

    @property
    def jobs(self) -> List[Job]:
        """Return all the jobs."""
        return self._jobs

    @property
    def nr_of_jobs(self) -> int:
        """Return the number of jobs."""
        return self._nr_of_jobs

    @property
    def operations(self) -> List[Operation]:
        """Return all the operations."""
        return self._operations

    @property
    def nr_of_operations(self) -> int:
        """Return the number of jobs."""
        return len(self._operations)

    @property
    def machines(self) -> List[Machine]:
        """Return all the machines"""
        return self._machines

    @property
    def nr_of_machines(self) -> int:
        """Return the number of jobs."""
        return self._nr_of_machines

    @property
    def operations_to_be_scheduled(self) -> List[Operation]:
        """Return all the operations to be schedule"""
        return self._operations_to_be_scheduled

    @property
    def operations_available_for_scheduling(self) -> List[Operation]:
        """Return all the operations that are available for scheduling"""
        return self._operations_available_for_scheduling

    @property
    def scheduled_operations(self) -> List[Operation]:
        """Return all the operations that are scheduled"""
        return self._scheduled_operations

    @property
    def precedence_relations_operations(self) -> Dict[int, List[int]]:
        """Return the precedence relations between operations."""
        return self._precedence_relations_operations

    @property
    def precedence_relations_jobs(self) -> Dict[int, List[int]]:
        """Return the precedence relations between operations."""
        return self._precedence_relations_jobs

    @property
    def instance_name(self) -> str:
        """Return the name of the instance."""
        return self._name

    # @property
    # def makespan(self) -> float:
    #     """Return the total makespan needed to complete all operations."""
    #     return max(
    #         [operation.scheduled_end_time for machine in self.machines for operation in machine.scheduled_operations])

    @property
    def makespan(self) -> float:
        """Return the total makespan needed to complete all operations."""
        end_times = [
            op_data['end_time']
            for machine in self.machines
            for op_data in machine._processed_operations
            if op_data.get('end_time') is not None
        ]
        return max(end_times) if end_times else 0.0

    @property
    def total_machinepower(self) -> float:
        total_energy = 0
        for machine in self.machines:
            busy_time = sum(op.scheduled_end_time - op.scheduled_start_time for op in machine.scheduled_operations)
            idle_time = self.makespan - busy_time
            energy = busy_time * machine.machine_processpower + idle_time * machine.machine_idlepower
            total_energy += energy
        return total_energy

    # @property
    # def total_machinepower(self) -> float:
    #     """
    #     计算总能耗 (Total Energy Consumption)。
    #     【升级版】: 引入“关机策略” (Turn On/Off Strategy)。
    #     逻辑: 遍历每台机器的空闲时间段，如果空闲能耗 > 开关机能耗，则执行关机。
    #     """
    #     # 假设关机+开机一次的总能耗成本 (单位与 Energy 一致)
    #     # 你可以把这个提取为类属性或配置参数
    #     # SWITCH_COST = 20.0
    #
    #     total_energy = 0.0
    #
    #     # 假设关机+重启的时间成本相当于待机 30 秒
    #     # 这个系数 30.0 可以写在配置里
    #     BREAK_EVEN_TIME = 30.0
    #
    #     for machine in self.machines:
    #
    #         # 动态计算这台机器的关机成本
    #         switch_cost = machine.machine_idlepower * BREAK_EVEN_TIME
    #
    #         # 1. 加工能耗 (Processing Energy)
    #         # 遍历所有工序，累加 (加工时长 * 加工功率)
    #         # 注意：这里我们用 op['processing_time'] 获取实际时长（含恶化）
    #         # scheduled_operations 属性返回的是 Operation 对象，不含时长信息
    #         # 所以我们要用 machine._processed_operations 这个内部列表
    #         proc_energy = 0.0
    #
    #         # 获取该机器上按时间排序的工序列表
    #         sorted_ops = sorted(machine._processed_operations, key=lambda x: x['start_time'])
    #
    #         for op_data in sorted_ops:
    #             proc_energy += op_data['processing_time'] * machine.machine_processpower
    #
    #         # 2. 待机/关机能耗 (Idle/Turn-off Energy)
    #         idle_energy = 0.0
    #         last_end_time = 0.0
    #
    #         # 2.1 中间空隙
    #         for op_data in sorted_ops:
    #             start_time = op_data['start_time']
    #             gap = start_time - last_end_time  # 空闲时长
    #
    #             if gap > 0:
    #                 potential_idle_cost = gap * machine.machine_idlepower
    #                 # 【核心决策】：待机还是关机？
    #                 if potential_idle_cost > switch_cost:
    #                     idle_energy += switch_cost  # 关机划算
    #                 else:
    #                     idle_energy += potential_idle_cost  # 待机划算
    #
    #             last_end_time = op_data['end_time']
    #
    #         # 2.2 最后一段空隙 (直到整个车间完工)
    #         # 机器完工后，通常会关机，直到下班
    #         # 如果定义为“完工即关机”，这段能耗为0 (或一次关机能耗)
    #         # 如果定义为“待机到下班”，则计算 gap
    #
    #         # 这里我们采用通用的“完工即关机”策略，所以最后这段能耗为0
    #         # 除非你的业务场景要求机器一直开到 makespan
    #
    #         # 如果要求待机到 makespan:
    #         # final_gap = self.makespan - last_end_time
    #         # if final_gap > 0:
    #         #     cost = final_gap * machine.machine_idlepower
    #         #     idle_energy += (SWITCH_COST if cost > SWITCH_COST else cost)
    #
    #         total_energy += (proc_energy + idle_energy)
    #
    #     return total_energy

    @property
    def total_workload(self) -> float:
        """Return the total workload (sum of processing times of all scheduled operations)"""
        return sum(
            [operation.scheduled_duration for machine in self.machines for operation in machine.scheduled_operations])

    @property
    def max_workload(self) -> float:
        """Return the max workload of machines (sum of processing times of all scheduled operations on a machine)"""
        return max(sum(op.scheduled_duration for op in machine.scheduled_operations) for machine in self.machines)

    def schedule_operation_with_backfilling(self, operation: Operation, machine_id, duration) -> None:
        """Schedule an operation"""
        if operation not in self.operations_available_for_scheduling:
            raise ValueError(
                f"Operation {operation.operation_id} is not available for scheduling")
        machine = self.get_machine(machine_id)
        if not machine:
            raise ValueError(
                f"Invalid machine ID {machine_id}")
        self.schedule_operation_on_machine_backfilling(operation, machine_id, duration)
        self.mark_operation_as_scheduled(operation)

    def unschedule_operation(self, operation: Operation) -> None:
        """Unschedule an operation"""
        machine = self.get_machine(operation.scheduled_machine)
        machine.unschedule_operation(operation)
        self.mark_operation_as_available(operation)

    def schedule_operation_on_machine_backfilling(self, operation: Operation, machine_id, duration) -> None:
        """Schedule an operation on a specific machine."""
        machine = self.get_machine(machine_id)
        if machine is None:
            raise ValueError(
                f"Invalid machine ID {machine_id}")

        machine.add_operation_to_schedule_backfilling(
            operation, duration, self._sequence_dependent_setup_times)

    def mark_operation_as_scheduled(self, operation: Operation) -> None:
        """Mark an operation as scheduled."""
        if operation not in self.operations_available_for_scheduling:
            raise ValueError(
                f"Operation {operation.operation_id} is not available for scheduling")
        self.operations_available_for_scheduling.remove(operation)
        self.scheduled_operations.append(operation)
        self.operations_to_be_scheduled.remove(operation)

    def mark_operation_as_available(self, operation: Operation) -> None:
        """Mark an operation as available for scheduling."""
        if operation not in self.scheduled_operations:
            raise ValueError(
                f"Operation {operation.operation_id} is not scheduled")
        self.scheduled_operations.remove(operation)
        self.operations_available_for_scheduling.append(operation)
        self.operations_to_be_scheduled.append(operation)
