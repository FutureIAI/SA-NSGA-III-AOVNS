from typing import List, Dict
from collections import OrderedDict


class Operation:
    def __init__(self, job, job_id, operation_id):
        self._job = job
        self._job_id = job_id
        self._operation_id = operation_id
        self._processing_times = OrderedDict()
        self._predecessors: List = []
        self._scheduling_information = {}
        self._scheduled_duration = 0
    def reset(self):
        self._scheduling_information = {}
        self._scheduled_duration = 0

        # if hasattr(self, '_start_time_setup'):
        #     del self._start_time_setup
        # if hasattr(self, '_setup_duration'):
        #     del self._setup_duration

        self._start_time_setup = None
        self._setup_duration = None

    def __str__(self):
        return f"Job {self.job_id}, Operation {self.operation_id}"

    @property
    def job(self):
        """Return the job object of the operation."""
        return self._job

    @property
    def job_id(self) -> int:
        """Return the job's id of the operation."""
        return self._job_id

    @property
    def operation_id(self) -> int:
        """Return the operation's id."""
        return self._operation_id

    @property
    def scheduling_information(self) -> Dict:
        """Return the scheduling information of the operation"""
        return self._scheduling_information

    @property
    def processing_times(self) -> dict:
        """Return a dictionary of machine ids and processing time durations."""
        return self._processing_times

    # def get_actual_processing_time(self, machine) -> float:
    #     """根据累计工作时间计算实际加工时间（考虑非线性恶化）"""
    #     p_base = self._processing_times[machine.machine_id]
    #     wt = sum(op.scheduled_duration for op in machine.scheduled_operations)  # 当前机器累计工作时间
    #
    #     if wt <= machine.t_min:
    #         return p_base
    #     elif machine.t_min < wt < machine.t_max:
    #         return p_base + machine.alpha * (wt - machine.t_min) ** machine.beta
    #     else:
    #         return p_base + machine.alpha * (machine.t_max - machine.t_min) ** machine.beta

    # def get_actual_processing_time(self, machine: 'Machine') -> float:
    #
    #     p_base = self._processing_times[machine.machine_id]
    #
    #     # 1. 直接从 machine 对象获取它内部记录的、真实的累计工作量。
    #     #    machine._processed_operations 存储了每个操作恶化后的真实时长。
    #     #    我们累加这个列表里的 'processing_time'。
    #     wt = sum(op_data['processing_time'] for op_data in machine._processed_operations)
    #
    #     if wt <= machine.t_min:
    #         return p_base
    #     elif machine.t_min < wt < machine.t_max:
    #         return p_base + machine.alpha * (wt - machine.t_min) ** machine.beta
    #     else:
    #         return p_base + machine.alpha * (machine.t_max - machine.t_min) ** machine.beta

    @property
    def scheduled_start_time(self) -> int:
        """Return the scheduled start time of the operation."""
        if 'start_time' in self._scheduling_information:
            return self._scheduling_information['start_time']
        return None

    @property
    def scheduled_end_time(self) -> int:
        """Return the scheduled end time of the operation."""
        if 'end_time' in self._scheduling_information:
            return self._scheduling_information['end_time']
        return None

    @property
    def scheduled_duration(self) -> int:
        """Return the scheduled duration of the operation."""
        return self._scheduled_duration

    # @property
    # def scheduled_duration(self) -> int:
    #     machine = self._job.jobshop.machines[self.scheduled_machine]
    #     return self.get_actual_processing_time(machine)

    @property
    def scheduled_machine(self) -> None:
        """Return the machine id that the operation is scheduled on."""
        if 'machine_id' in self._scheduling_information:
            return self._scheduling_information['machine_id']
        return None

    @property
    def predecessors(self) -> List:
        """Return the list of predecessor operations."""
        return self._predecessors

    @property
    def finishing_time_predecessors(self) -> int:
        """Return the finishing time of the latest predecessor."""
        if not self.predecessors:
            return 0
        end_times_predecessors = [operation.scheduled_end_time for operation in self.predecessors]
        return max(end_times_predecessors)

    def update_job_id(self, new_job_id: int) -> None:
        """Update the id of a job (used for assembly scheduling problems, with no pregiven job id)"""
        self._job_id = new_job_id

    def update_job(self, job) -> None:
        self._job = job

    def add_predecessors(self, predecessors: List) -> None:
        """Add a list of predecessor operations to the current operation."""
        self.predecessors.extend(predecessors)

    def add_operation_option(self, machine_id, duration) -> None:
        """Add an operation option to the current operation."""
        self._processing_times[machine_id] = duration

    def update_sequence_dependent_setup_times(self, start_time_setup, setup_duration):
        self._start_time_setup = start_time_setup
        self._setup_duration = setup_duration

    # def add_operation_scheduling_information(self, machine_id: int, start_time: int, setup_time: int, duration) -> None:
    #     """Add scheduling information to the current operation."""
    #
    #     self._scheduled_duration = duration  # 在这里更新持续时间
    #     self._scheduling_information = {
    #         'machine_id': machine_id,
    #         'start_time': start_time,
    #         'end_time': start_time + duration,
    #         'processing_time': duration,
    #         'start_setup': start_time - setup_time,
    #         'end_setup': start_time,
    #         'setup_time': setup_time
    #     }

    def add_operation_scheduling_information(self, machine: 'Machine', start_time: int, setup_time: int,
                                             duration) -> None:
        """
        【修复版】只负责存储，不负责计算。
        duration 必须是 Machine 类已经计算好的实际加工时长。
        """
        self._scheduled_duration = duration
        self._scheduling_information = {
            'machine_id': machine.machine_id,
            'start_time': start_time,
            'end_time': start_time + duration,
            'processing_time': duration,
            'start_setup': start_time - setup_time,
            'end_setup': start_time,
            'setup_time': setup_time
        }


