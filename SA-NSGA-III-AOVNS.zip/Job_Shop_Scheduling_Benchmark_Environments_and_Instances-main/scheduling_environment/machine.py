from typing import List
from scheduling_environment.operation import Operation


class Machine:
    def __init__(self, machine_id, machine_name=None, machine_processpower=0, machine_idlepower=0,
                 t_min=0, t_max=0, alpha=0.0, beta=1.0):
        self._machine_id = machine_id
        self._machine_name = machine_name
        self._processed_operations = []
        self._machine_idlepower = machine_idlepower
        self._machine_processpower = machine_processpower
        self._current_end_time = 0.0

        # 【新增】：记录该机器的故障/不可用时间窗列表，格式为 [(start_time, end_time), ...]
        self.breakdown_windows = []

        # 恶化参数
        self._t_min = t_min
        self._t_max = t_max
        self._alpha = alpha
        self._beta = beta

    def reset(self):
        """重置机器状态，清空所有已调度的工序。"""
        self._processed_operations = []
        self._current_end_time = 0.0
        # 【新增】：通常 reset 时是否清空故障取决于你的实验设计，这里建议提供参数或不清空
        # self.breakdown_windows = []

        # 【新增方法】：注入故障时间窗

    def add_breakdown_window(self, start_time: float, duration: float):
        """为机器添加一个故障时间段"""
        end_time = start_time + duration
        self.breakdown_windows.append((start_time, end_time))
        # 按开始时间排序，方便后续查找
        self.breakdown_windows.sort(key=lambda x: x[0])

        # 【新增内部方法】：计算避开故障的真实开始时间

    def _get_earliest_available_time(self, desired_start_time: float, duration: float) -> float:
        """
        给定一个期望的开始时间，检查是否与任何故障时间窗冲突。
        如果冲突，则将开始时间顺延到故障结束之后，直到能完整放下该工序。
        """
        actual_start = desired_start_time

        for brk_start, brk_end in self.breakdown_windows:
            # 检查 [actual_start, actual_start + duration] 是否与 [brk_start, brk_end] 存在交集
            # 只有当工序的结束时间大于故障开始，且工序开始时间小于故障结束时，才算重叠
            if actual_start < brk_end and (actual_start + duration) > brk_start:
                # 发生冲突，工序必须推迟到本次故障修复之后开始
                actual_start = brk_end

        return actual_start

    def __str__(self):
        return f"Machine {self._machine_id}, {len(self._processed_operations)} scheduled operations"

    @property
    def current_end_time(self):
        # """
        # 获取机器当前的最后完工时间。
        # 如果机器没有任何已安排的工序，返回 0.0。
        # """
        # if not self._processed_operations:
        #     return 0.0
        #
        # # 找到所有工序中结束时间最大的那个
        # # 注意：这里假设 _processed_operations 里存的是字典 {'end_time': ...}
        # last_op = max(self._processed_operations, key=lambda x: x['end_time'])
        # return last_op['end_time']

        return self._current_end_time

    @current_end_time.setter
    def current_end_time(self, value):
        # 这里根据你的类内部变量名来定，通常是 _current_end_time
        self._current_end_time = value

    # --- Properties (属性) ---
    @property
    def machine_id(self):
        return self._machine_id

    @property
    def machine_name(self):
        return self._machine_name

    @property
    def machine_processpower(self):
        return self._machine_processpower

    @property
    def machine_idlepower(self):
        return self._machine_idlepower

    @property
    def t_min(self):
        return self._t_min

    @property
    def t_max(self):
        return self._t_max

    @property
    def alpha(self):
        return self._alpha

    @property
    def beta(self):
        return self._beta

    @property
    def scheduled_operations(self) -> List[Operation]:
        """按开始时间排序，返回已调度工序的 Operation 对象列表。"""
        sorted_ops = sorted(self._processed_operations, key=lambda op: op['start_time'])
        return [op['operation'] for op in sorted_ops]

    # # 核心计算与调度函数
    # def get_actual_processing_time(self, operation, base_time: float) -> float:
    #     """
    #     根据当前机器已处理的工序列表 (self._processed_operations) 计算新工序的实际加工时间。
    #     这个函数保持你原来的实现，以便最小化改动。
    #     【修改】如果是 PM 维护工序 (id=999999)，不应用恶化效应，直接返回 base_time。
    #     """
    #     # --- 新增判断 ---
    #     if operation.job_id == -1:
    #         return base_time
    #     # ----------------
    #
    #     wt = sum(op_data['processing_time'] for op_data in self._processed_operations)
    #     if wt <= self.t_min:
    #         return base_time
    #     elif self.t_min < wt < self.t_max:
    #         return base_time + self.alpha * (wt - self.t_min) ** self.beta
    #     else:
    #         return base_time + self.alpha * (self.t_max - self.t_min) ** self.beta

    # def get_actual_processing_time(self, operation, base_time: float) -> float:
    #     """
    #     计算工序实际加工时间。
    #     - PM 工序直接返回 base_time（不老化）
    #     - 普通工序：如果调用方已在外部完成老化计算并传入 actual_duration 作为 base_time，
    #       则此处 t_min 应设为 0，使得 wt <= t_min 时直接返回 base_time，避免二次老化。
    #       实际上，只要保证 evaluate 中传入的是 actual_duration，
    #       且机器的 t_min > 0（即机器有磨损起始阈值），就不会触发二次老化。
    #     """
    #     # PM 工序不参与老化
    #     if operation.job_id == -1:
    #         return base_time
    #
    #     # 计算当前机器已累积的工时（仅统计已入队的工序）
    #     wt = sum(op_data['processing_time'] for op_data in self._processed_operations
    #              if op_data['operation'].job_id != -1)  # 排除 PM 工序的时长，避免维护时间被计入磨损
    #
    #     if wt <= self.t_min:
    #         return base_time
    #     elif self.t_min < wt < self.t_max:
    #         return base_time + self.alpha * (wt - self.t_min) ** self.beta
    #     else:
    #         return base_time + self.alpha * (self.t_max - self.t_min) ** self.beta

    def get_actual_processing_time(self, operation, base_time: float, PM_K=0.1) -> float:
        """
        计算工序实际加工时间。
        【核心修复】：按照时间顺序累加，遇到 PM 维护块时进行老化系数打折，保持与环境逻辑同步。
        """
        if operation.job_id == -1:
            return base_time

        wt = 0.0
        # 必须按时间顺序遍历，模拟老化的累积与回退过程
        sorted_ops = sorted(self._processed_operations, key=lambda op: op['start_time'])
        for op_data in sorted_ops:
            if op_data['operation'].job_id == -1:
                wt = wt * PM_K  # 遇到维护块，役龄回退
            else:
                wt += op_data['base_processing_time']  # 按照基准时间累加老化（与 evaluate 保持一致）

        if wt <= self.t_min:
            return base_time
        elif self.t_min < wt < self.t_max:
            return base_time + self.alpha * (wt - self.t_min) ** self.beta
        else:
            return base_time + self.alpha * (self.t_max - self.t_min) ** self.beta

    # def add_operation_to_schedule_backfilling(self, operation: Operation, base_processing_time: float,
    #                                           sequence_dependent_setup_times):
    #     """
    #     【最终修正版】
    #     使用回填策略将工序添加到调度中，并正确处理机器恶化。
    #     这个函数是整个调度的核心入口。
    #     """
    #
    #     # 内部辅助函数，只负责在当前列表末尾顺序添加一个工序
    #     def _add_sequentially(op_to_add, bpt, sdts):
    #         finishing_time_preds = op_to_add.finishing_time_predecessors
    #         last_op_info = None
    #         if self._processed_operations:
    #             last_op_info = max(self._processed_operations, key=lambda op: op['end_time'])
    #
    #         finishing_time_machine = last_op_info['end_time'] if last_op_info else 0
    #
    #         setup_time = 0
    #         if last_op_info:
    #             last_op_id = last_op_info['operation'].operation_id
    #             current_op_id = op_to_add.operation_id
    #             if self.machine_id in sdts and \
    #                     last_op_id in sdts[self.machine_id] and \
    #                     current_op_id in sdts[self.machine_id][last_op_id]:
    #                 setup_time = sdts[self.machine_id][last_op_id][current_op_id]
    #
    #         start_time = max(finishing_time_preds, finishing_time_machine + setup_time)
    #
    #         # 调用你现有的 get_actual_processing_time, 它会基于 self._processed_operations 的当前状态计算 wt
    #         actual_proc_time = self.get_actual_processing_time(op_to_add, bpt)
    #
    #         op_to_add.add_operation_scheduling_information(
    #             self, start_time, setup_time, actual_proc_time)
    #
    #         self._processed_operations.append({
    #             'operation': op_to_add,
    #             'start_time': start_time,
    #             'end_time': start_time + actual_proc_time,
    #             'processing_time': actual_proc_time,
    #             'base_processing_time': bpt,  # 保存基础时间，对于重调度至关重要
    #             'start_setup': start_time - setup_time,
    #             'end_setup': start_time,
    #             'setup_time': setup_time,
    #         })
    #
    #         # 【在这里添加】 更新当前机器的最晚结束时间
    #         self._current_end_time = max(self._current_end_time, start_time + actual_proc_time)
    #
    #     # 回填主逻辑开始
    #     if not self._processed_operations:
    #         _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)
    #         return
    #
    #     sorted_ops = sorted(self._processed_operations, key=lambda op: op['start_time'])
    #     finishing_time_predecessors = operation.finishing_time_predecessors
    #
    #     # 检查所有可能的间隙 (包括最开始的)
    #     gaps_to_check = []
    #     # 间隙0: 从时间0到第一个工序
    #     gaps_to_check.append({'prev_op_info': None, 'next_op_info': sorted_ops[0], 'insertion_index': 0})
    #     # 间隙1, 2, ...: 在工序之间
    #     for i in range(len(sorted_ops) - 1):
    #         gaps_to_check.append(
    #             {'prev_op_info': sorted_ops[i], 'next_op_info': sorted_ops[i + 1], 'insertion_index': i + 1})
    #
    #     for gap in gaps_to_check:
    #         prev_op_info = gap['prev_op_info']
    #         next_op_info = gap['next_op_info']
    #
    #         # 1. 计算潜在开始时间
    #         prev_op_end = prev_op_info['end_time'] if prev_op_info else 0
    #         prev_op_id = prev_op_info['operation'].operation_id if prev_op_info else None
    #
    #         setup_from_prev = 0
    #         if prev_op_id is not None:
    #             # 【修正】使用 job_id == -1 来判断是否为 PM 工序
    #             current_is_pm = (operation.job_id == -1)
    #             prev_is_pm = (prev_op_info['operation'].job_id == -1)
    #
    #             # 只有当两个都不是 PM 时，才去查表
    #             if not current_is_pm and not prev_is_pm:
    #                 try:
    #                     setup_from_prev = sequence_dependent_setup_times[self.machine_id][prev_op_id][
    #                         operation.operation_id]
    #                 except IndexError:
    #                     # 兜底：如果 ID 依然越界（理论上不应该），默认为 0
    #                     setup_from_prev = 0
    #         # 修改的
    #
    #         potential_start_time = max(finishing_time_predecessors, prev_op_end + setup_from_prev)
    #
    #         # 2. 【核心】模拟计算实际加工时间
    #         # 通过临时修改 self._processed_operations 来让你的 get_actual_processing_time 工作
    #         original_processed_ops = self._processed_operations
    #         self._processed_operations = sorted_ops[:gap['insertion_index']]  # 临时截断列表以模拟插入点之前的状态
    #         actual_proc_time_if_inserted = self.get_actual_processing_time(operation, base_processing_time)
    #         self._processed_operations = original_processed_ops  # **立即恢复列表**
    #
    #         potential_end_time = potential_start_time + actual_proc_time_if_inserted
    #
    #         # # 3. 检查是否能放下
    #         # setup_to_next = sequence_dependent_setup_times[self.machine_id][operation.operation_id][
    #         #     next_op_info['operation'].operation_id]
    #
    #         # 修改的
    #         # --- 3. 检查是否能放下 (计算与后一个工序的切换时间) ---
    #         next_op = next_op_info['operation']
    #         op_id1 = operation.operation_id
    #         op_id2 = next_op.operation_id
    #
    #         setup_to_next = 0  # 默认值
    #
    #         # 【修正】使用 job_id == -1 来判断是否为 PM 工序
    #         current_is_pm = (operation.job_id == -1)
    #         next_is_pm = (next_op.job_id == -1)
    #
    #         # 只有当 op_id1 和 op_id2 都不是维护工序时，才查表
    #         if not current_is_pm and not next_is_pm:
    #             if (self.machine_id in sequence_dependent_setup_times and
    #                     op_id1 in sequence_dependent_setup_times[self.machine_id] and
    #                     op_id2 in sequence_dependent_setup_times[self.machine_id][op_id1]):
    #                 try:
    #                     setup_to_next = sequence_dependent_setup_times[self.machine_id][op_id1][op_id2]
    #                 except IndexError:
    #                     setup_to_next = 0
    #
    #         # 检查时间窗口是否足够
    #         if potential_end_time + setup_to_next <= next_op_info['start_setup']:
    #             # 找到了！执行“分割-插入-重调度”
    #             insertion_index = gap['insertion_index']
    #
    #             # 1. 准备重调度所需的数据
    #             # 注意：必须先从 sorted_ops 提取，因为 self._processed_operations 即将被修改
    #             ops_before_insertion = sorted_ops[:insertion_index]
    #             ops_to_reschedule_data = sorted_ops[insertion_index:]
    #
    #             # 2. 【核心修复】：重置机器已处理列表为插入点之前的状态
    #             # 这样后续的 _add_sequentially 调用 get_actual_processing_time 时，wt 统计才是准确的
    #             self._processed_operations = list(ops_before_insertion)
    #
    #             # 3. 插入当前工序
    #             _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)
    #
    #             # 4. 依次重调度后续所有工序
    #             for op_data in ops_to_reschedule_data:
    #                 # 必须使用原始保存的 base_processing_time，让它在新的 wt 下重新计算老化
    #                 bpt_for_reschedule = op_data.get('base_processing_time', op_data['processing_time'])
    #                 _add_sequentially(
    #                     op_data['operation'], bpt_for_reschedule, sequence_dependent_setup_times
    #                 )
    #
    #             # 5. 成功回填并重调度，直接返回，不再执行后续逻辑
    #             return
    #
    #             # 如果所有间隙都不能回填，就在末尾顺序添加
    #     _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)

    def add_operation_to_schedule_backfilling(self, operation: Operation, base_processing_time: float,
                                              sequence_dependent_setup_times):
        """
        【最终修正版】
        使用回填策略将工序添加到调度中，并正确处理机器恶化。
        这个函数是整个调度的核心入口。
        """

        # 内部辅助函数，只负责在当前列表末尾顺序添加一个工序
        def _add_sequentially(op_to_add, bpt, sdts):
            finishing_time_preds = op_to_add.finishing_time_predecessors
            last_op_info = None
            if self._processed_operations:
                last_op_info = max(self._processed_operations, key=lambda op: op['end_time'])

            finishing_time_machine = last_op_info['end_time'] if last_op_info else 0

            setup_time = 0
            if last_op_info:
                last_op_id = last_op_info['operation'].operation_id
                current_op_id = op_to_add.operation_id
                if self.machine_id in sdts and \
                        last_op_id in sdts[self.machine_id] and \
                        current_op_id in sdts[self.machine_id][last_op_id]:
                    setup_time = sdts[self.machine_id][last_op_id][current_op_id]

            # 原来的 start_time
            desired_start_time = max(finishing_time_preds, finishing_time_machine + setup_time)

            # 调用你现有的 get_actual_processing_time, 它会基于 self._processed_operations 的当前状态计算 wt
            actual_proc_time = self.get_actual_processing_time(op_to_add, bpt)

            # 【核心修改点】：获取避开机器故障时间段的真实开始时间
            start_time = self._get_earliest_available_time(desired_start_time, actual_proc_time)

            op_to_add.add_operation_scheduling_information(
                self, start_time, setup_time, actual_proc_time)

            self._processed_operations.append({
                'operation': op_to_add,
                'start_time': start_time,
                'end_time': start_time + actual_proc_time,
                'processing_time': actual_proc_time,
                'base_processing_time': bpt,  # 保存基础时间，对于重调度至关重要
                'start_setup': start_time - setup_time,
                'end_setup': start_time,
                'setup_time': setup_time,
            })

            # 【在这里添加】 更新当前机器的最晚结束时间
            self._current_end_time = max(self._current_end_time, start_time + actual_proc_time)

        # 回填主逻辑开始
        if not self._processed_operations:
            _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)
            return

        sorted_ops = sorted(self._processed_operations, key=lambda op: op['start_time'])
        finishing_time_predecessors = operation.finishing_time_predecessors

        # 检查所有可能的间隙 (包括最开始的)
        gaps_to_check = []
        # 间隙0: 从时间0到第一个工序
        gaps_to_check.append({'prev_op_info': None, 'next_op_info': sorted_ops[0], 'insertion_index': 0})
        # 间隙1, 2, ...: 在工序之间
        for i in range(len(sorted_ops) - 1):
            gaps_to_check.append(
                {'prev_op_info': sorted_ops[i], 'next_op_info': sorted_ops[i + 1], 'insertion_index': i + 1})

        for gap in gaps_to_check:
            prev_op_info = gap['prev_op_info']
            next_op_info = gap['next_op_info']

            # 1. 计算潜在开始时间
            prev_op_end = prev_op_info['end_time'] if prev_op_info else 0
            prev_op_id = prev_op_info['operation'].operation_id if prev_op_info else None

            setup_from_prev = 0
            if prev_op_id is not None:
                # 【修正】使用 job_id == -1 来判断是否为 PM 工序
                current_is_pm = (operation.job_id == -1)
                prev_is_pm = (prev_op_info['operation'].job_id == -1)

                # 只有当两个都不是 PM 时，才去查表
                if not current_is_pm and not prev_is_pm:
                    try:
                        setup_from_prev = sequence_dependent_setup_times[self.machine_id][prev_op_id][
                            operation.operation_id]
                    except IndexError:
                        # 兜底：如果 ID 依然越界（理论上不应该），默认为 0
                        setup_from_prev = 0

            # 在回填逻辑 (gap 检查) 中找到这行：
            potential_start_time = max(finishing_time_predecessors, prev_op_end + setup_from_prev)
            actual_proc_time_temp = self.get_actual_processing_time(operation, base_processing_time)
            potential_start_time = self._get_earliest_available_time(potential_start_time, actual_proc_time_temp)

            # 2. 【核心】模拟计算实际加工时间
            # 通过临时修改 self._processed_operations 来让你的 get_actual_processing_time 工作
            original_processed_ops = self._processed_operations
            self._processed_operations = sorted_ops[:gap['insertion_index']]  # 临时截断列表以模拟插入点之前的状态
            actual_proc_time_if_inserted = self.get_actual_processing_time(operation, base_processing_time)
            self._processed_operations = original_processed_ops  # **立即恢复列表**

            potential_end_time = potential_start_time + actual_proc_time_if_inserted

            # # 3. 检查是否能放下
            # setup_to_next = sequence_dependent_setup_times[self.machine_id][operation.operation_id][
            #     next_op_info['operation'].operation_id]

            # 修改的
            # --- 3. 检查是否能放下 (计算与后一个工序的切换时间) ---
            next_op = next_op_info['operation']
            op_id1 = operation.operation_id
            op_id2 = next_op.operation_id

            setup_to_next = 0  # 默认值

            # 【修正】使用 job_id == -1 来判断是否为 PM 工序
            current_is_pm = (operation.job_id == -1)
            next_is_pm = (next_op.job_id == -1)

            # 只有当 op_id1 和 op_id2 都不是维护工序时，才查表
            if not current_is_pm and not next_is_pm:
                if (self.machine_id in sequence_dependent_setup_times and
                        op_id1 in sequence_dependent_setup_times[self.machine_id] and
                        op_id2 in sequence_dependent_setup_times[self.machine_id][op_id1]):
                    try:
                        setup_to_next = sequence_dependent_setup_times[self.machine_id][op_id1][op_id2]
                    except IndexError:
                        setup_to_next = 0

            # 检查时间窗口是否足够
            if potential_end_time + setup_to_next <= next_op_info['start_setup']:
                # 找到了！执行“分割-插入-重调度”
                insertion_index = gap['insertion_index']

                # 1. 准备重调度所需的数据
                # 注意：必须先从 sorted_ops 提取，因为 self._processed_operations 即将被修改
                ops_before_insertion = sorted_ops[:insertion_index]
                ops_to_reschedule_data = sorted_ops[insertion_index:]

                # # 2. 【核心修复】：重置机器已处理列表为插入点之前的状态
                # # 这样后续的 _add_sequentially 调用 get_actual_processing_time 时，wt 统计才是准确的
                # self._processed_operations = list(ops_before_insertion)
                #
                # # 3. 插入当前工序
                # _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)

                # 2. 【核心修复】：重置机器已处理列表为插入点之前的状态
                self._processed_operations = list(ops_before_insertion)

                # 【新增修复】：同步重置该机器的最大完工时间
                if self._processed_operations:
                    self._current_end_time = max(op['end_time'] for op in self._processed_operations)
                else:
                    self._current_end_time = 0.0

                # 3. 插入当前工序
                _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)

                # 4. 依次重调度后续所有工序
                for op_data in ops_to_reschedule_data:
                    # 必须使用原始保存的 base_processing_time，让它在新的 wt 下重新计算老化
                    bpt_for_reschedule = op_data.get('base_processing_time', op_data['processing_time'])
                    _add_sequentially(
                        op_data['operation'], bpt_for_reschedule, sequence_dependent_setup_times
                    )

                # 5. 成功回填并重调度，直接返回，不再执行后续逻辑
                return

                # 如果所有间隙都不能回填，就在末尾顺序添加
        _add_sequentially(operation, base_processing_time, sequence_dependent_setup_times)

    def append_operation_sequentially(self, operation: Operation, duration: float, forced_start: float = None):
        """
        强制顺序追加工序到机器末尾，跳过回填逻辑。
        专用于 CBM/OM 维护工序的插入。
        forced_start: 若指定，则以此为开始时间（用于 OM 填入空闲窗口）；
                      若不指定，则从机器当前末尾开始（用于 CBM 紧接在当前末尾）。
        """
        # if forced_start is not None:
        #     start_time = forced_start
        # else:
        #     if self._processed_operations:
        #         start_time = max(op['end_time'] for op in self._processed_operations)
        #     else:
        #         start_time = 0.0
        #
        # end_time = start_time + duration

        # 【核心修复】：不再遍历列表，直接使用内部维护的指针
        if forced_start is not None:
            start_time = forced_start
        else:
            # self._current_end_time 是最权威的“机器当前可用末尾”
            start_time = self._current_end_time

        end_time = start_time + duration

        self._processed_operations.append({
            'operation': operation,
            'start_time': start_time,
            'end_time': end_time,
            'processing_time': duration,
            'base_processing_time': duration,
            'start_setup': start_time,
            'end_setup': start_time,
            'setup_time': 0,
        })
        self._current_end_time = max(self._current_end_time, end_time)

        # 同步到 operation 对象，供画图读取
        operation.start_time = start_time
        operation.end_time = end_time

        # 核心修复：通过字典设置，避开只读属性限制
        operation._scheduling_information = {
            'machine_id': self.machine_id,
            'start_time': start_time,
            'end_time': end_time,
            'processing_time': duration,
            'start_setup': start_time,  # <--- 加上这个
            'end_setup': start_time,
            'setup_time': 0
        }
        operation._scheduled_duration = duration

