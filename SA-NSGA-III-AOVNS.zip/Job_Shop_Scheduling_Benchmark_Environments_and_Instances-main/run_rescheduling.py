import argparse
import logging
import multiprocessing
import time
import os

os.environ['MKL_NUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import copy
import random

from scipy.spatial.distance import cdist

from deap.tools._hypervolume import hv

import numpy as np
import matplotlib.pyplot as plt
from deap import base, creator, tools

from solutions.genetic_algorithm.operators import (
    init_individual, init_population, repair_precedence_constraints,
    mutate_shortest_proc_time, mutate_sequence_exchange, pox_crossover,
    simulated_annealing_double, insertion_search, inversion_search, variation_adaptive,
    variation, pm_avoidance_search,
    pm_shift_operator,
    pm_threshold_tuning_operator
)

# --- 导入新创建的 ETMA-Lite 算法组件 ---
from solutions.ETMA.etma_operators import (
    VNS_lite, potential_solution_selection, energy_saving_right_shift,
    Structured_MOVNS, initialize_population_etma, Structured_MOVNS_PM
)
# --- 导入新的带老化效应的评估函数 ---
from solutions.genetic_algorithm.operators import evaluate_individual_double

# --- 其他通用导入 ---
from solutions.NSGA3.nsga3 import divide, select_FL, point_ideal1, association, select, uniformpoint
from plotting.drawer import draw_gantt_chart_ch5, draw_precedence_relations
from solutions.helper_functions import record_stats, load_parameters, load_job_shop_env

logging.basicConfig(level=logging.INFO)

PARAM_FILE = "configs/genetic_algorithm.toml"
DEFAULT_RESULTS_ROOT = os.path.join(".", "results", "comparison_runs")

# --- 并行工作进程的函数 (使用带老化效应的评估) ---
base_worker_env_template = None  # 我们现在存储一个干净的环境“模板”

def init_worker(base_env_to_copy):
    """每个工作进程启动时调用一次，用来接收并存储一个干净的环境模板。"""
    global base_worker_env_template
    # 直接存储传入的模板对象，它本身是干净的
    base_worker_env_template = base_env_to_copy

def evaluate_on_worker(individual):
    # 直接使用全局的环境模板（不用拷贝）
    global base_worker_env_template

    # 瞬间重置状态（毫秒级），代替耗时的深拷贝（秒级）
    base_worker_env_template.reset()

    makespan, total_power, _ = evaluate_individual_double(individual, base_worker_env_template)
    return makespan, total_power

def generate_comparison_plots(all_results, save_dir):

    logging.info("\n" + "=" * 25 + " Generating All Comparison Plots " + "=" * 25)
    os.makedirs(save_dir, exist_ok=True)

    styles = {
        'nsga3': {'color': 'blue', 'linestyle': '-', 'marker': 'o', 'label': 'AOS-NSGA-III'}
    }

    # --- 2. 绘制收敛曲线对比图 (双子图) ---
    logging.info("Generating convergence comparison plot...")
    fig_conv, (ax1_conv, ax2_conv) = plt.subplots(2, 1, figsize=(14, 12), sharex=True)

    for algo_name, result_data in all_results.items():
        # 确保算法在样式定义中，并且有收敛数据
        if algo_name in styles and 'min_makespans' in result_data and 'min_energies' in result_data:
            style = styles[algo_name]
            # 绘制 Makespan 收敛曲线
            ax1_conv.plot(result_data['min_makespans'], color=style['color'], linestyle=style['linestyle'],
                          label=style['label'])
            # 绘制 Energy 收敛曲线
            ax2_conv.plot(result_data['min_energies'], color=style['color'], linestyle=style['linestyle'],
                          label=style['label'])

    ax1_conv.set_title('Makespan Convergence Comparison', fontsize=14)
    ax1_conv.set_ylabel('Best Makespan')
    ax1_conv.legend()
    ax1_conv.grid(True, linestyle='--', alpha=0.7)

    ax2_conv.set_title('Energy Convergence Comparison', fontsize=14)
    ax2_conv.set_xlabel('Generation', fontsize=12)
    ax2_conv.set_ylabel('Best Energy')
    ax2_conv.legend()
    ax2_conv.grid(True, linestyle='--', alpha=0.7)

    fig_conv.tight_layout()
    convergence_plot_path = os.path.join(save_dir, "comparison_convergence_subplots.png")
    plt.savefig(convergence_plot_path, dpi=300)
    plt.close(fig_conv)
    logging.info(f"-> Convergence plot saved to: {convergence_plot_path}")

    # --- 3. 绘制帕累托前沿对比图 (散点图) ---
    logging.info("Generating Pareto front comparison plot...")
    fig_pf, ax_pf = plt.subplots(figsize=(12, 9))

    for algo_name, result_data in all_results.items():
        if algo_name in styles and 'pareto_front' in result_data:
            style = styles[algo_name]
            # 从 DEAP 的 ParetoFront 对象中提取适应度值
            pf = np.array([ind.fitness.values for ind in result_data['pareto_front']])
            if pf.size > 0:
                ax_pf.scatter(pf[:, 0], pf[:, 1], c=style['color'], marker=style['marker'], s=100, alpha=0.8,
                              label=f"{style['label']} (n={len(pf)})", edgecolors='black')

    ax_pf.set_title('Final Pareto Front Comparison', fontsize=16)
    ax_pf.set_xlabel('Makespan (Lower is Better)', fontsize=12)
    ax_pf.set_ylabel('Total Energy (Lower is Better)', fontsize=12)
    ax_pf.legend()
    ax_pf.grid(True, linestyle='--', alpha=0.7)

    fig_pf.tight_layout()
    pareto_plot_path = os.path.join(save_dir, "comparison_pareto_front.png")
    plt.savefig(pareto_plot_path, dpi=300)
    plt.close(fig_pf)
    logging.info(f"-> Pareto front plot saved to: {pareto_plot_path}")

    # --- 4. 绘制 Hypervolume 迭代对比图 ---
    logging.info("Generating Hypervolume comparison plot...")
    fig_hv, ax_hv = plt.subplots(figsize=(12, 8))

    for algo_name, result_data in all_results.items():
        # 确保数据存在
        if algo_name in styles and 'hv_history' in result_data:
            style = styles[algo_name]
            hv_data = result_data['hv_history']

            # 绘制曲线
            ax_hv.plot(hv_data, color=style['color'], linestyle=style['linestyle'],
                       linewidth=2, marker=style.get('marker', ''), markevery=max(1, len(hv_data) // 10),
                       label=style['label'])

    ax_hv.set_title('Hypervolume Convergence (Normalized)', fontsize=16)
    ax_hv.set_xlabel('Generation', fontsize=12)
    ax_hv.set_ylabel('Hypervolume (Higher is Better)', fontsize=12)
    ax_hv.legend(fontsize=12)
    ax_hv.grid(True, linestyle='--', alpha=0.7)

    fig_hv.tight_layout()
    hv_plot_path = os.path.join(save_dir, "comparison_hypervolume.png")
    plt.savefig(hv_plot_path, dpi=300)
    plt.close(fig_hv)
    logging.info(f"-> Hypervolume plot saved to: {hv_plot_path}")

    logging.info(f"✅ All comparison plots saved to directory: {save_dir}")

# --- DEAP 初始化函数 (为两个算法提供通用工具) ---
def initialize_run(pool: multiprocessing.Pool, jobShopEnv, **kwargs):
    toolbox = base.Toolbox()
    toolbox.register("map", pool.map, evaluate_on_worker)

    if hasattr(creator, "Fitness"):
        del creator.Fitness

    if hasattr(creator, "Individual"):
        del creator.Individual
    # -----------------------------------------------------

    creator.create("Fitness", base.Fitness, weights=(-1.0, -1.0))
    creator.create("Individual", list, fitness=creator.Fitness)

    # 注册带老化效应的评估函数
    toolbox.register("evaluate_individual_double", evaluate_individual_double, jobShopEnv=jobShopEnv)

    # 注册通用算子
    toolbox.register("init_individual", init_individual, creator.Individual, kwargs, jobShopEnv=jobShopEnv)
    toolbox.register("population", init_population, toolbox, kwargs['algorithm']['population_size'])
    toolbox.register("mate_POX", pox_crossover, nr_preserving_jobs=1)
    toolbox.register("mate_TwoPoint", tools.cxTwoPoint)
    toolbox.register("mate_Uniform", tools.cxUniform, indpb=0.5)
    toolbox.register("mutate_machine_selection", mutate_shortest_proc_time, jobShopEnv=jobShopEnv)
    toolbox.register("mutate_operation_sequence", mutate_sequence_exchange)

    # 注册选择算子
    toolbox.register("select_for_mating", tools.selNSGA2)  # MAB-MA 使用
    toolbox.register("select_tournament", tools.selTournament, tournsize=2)  # ETMA 使用
    toolbox.register("select_environmental", tools.selNSGA2)  # ETMA 使用

    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("std", np.std, axis=0)
    stats.register("min", np.min, axis=0)
    stats.register("max", np.max, axis=0)
    hof = tools.ParetoFront()

    algorithm_type = kwargs.get('algorithm_type', 'nsga3')

    logging.info("Using the unified general initialization method for all algorithms.")
    initial_population = toolbox.population()

    logging.info(f"Evaluating initial population of size {len(initial_population)}...")
    fitnesses = toolbox.map(initial_population)
    for ind, fit in zip(initial_population, fitnesses):
        ind.fitness.values = fit

    hof.update(initial_population)

    return initial_population, toolbox, stats, hof

def algo_run_nsga3_movns(jobShopEnv, population, toolbox, stats, hof, **kwargs):

    logging.info("==========================================================")
    logging.info("       Starting NSGA-III with MOVNS (Static Mode)         ")
    logging.info("==========================================================")

    gen = 0
    try:
        # --- 1. 初始化统计 ---
        logbook = tools.Logbook()
        min_makespans, min_energies, hv_history = [], [], []
        logbook.header = ["gen"] + (stats.fields if stats else [])
        log_file = kwargs.get('output', {}).get('logbook_file')

        # 【新增】AOS 权重初始化
        # movns_probs[0] 是 Makespan 算子的概率，[1] 是 Energy
        movns_probs = [0.5, 0.5]
        alpha = 0.1  # 学习率（更新步长）
        p_min = 0.1  # 防止某个算子概率降为 0 导致“饿死”

        # 初始种群评估
        population = [ind for ind in population if ind.fitness.valid]
        if not population:
            logging.error("No valid individuals in initial population.")
            return None, [], [], []

        hof.update(population)
        record_stats(0, population, logbook, stats, log_file, [], logging, header=True)

        # NSGA-III 参数
        pop_size = kwargs['algorithm']['population_size']
        num_ref_points = max(2, int(pop_size / 10))
        uniformPoint = uniformpoint(num_ref_points, 2)

        # --- 2. 算法主循环 ---
        for gen in range(1, kwargs['algorithm']['ngen'] + 1):
            gentime = time.time()

            # A. 变异阶段 (调用修复后的 variation_adaptive)
            mating_pool = toolbox.select_for_mating(population, k=pop_size)
            offspring = variation_adaptive(
                mating_pool, toolbox,
                kwargs['algorithm']['cr'],
                kwargs['algorithm']['indpb'],
                jobShopEnv
            )

            # B. 修复约束 (如有)
            if any(path in jobShopEnv.instance_name for path in ['/dafjs/', '/yfjs/']):
                offspring = repair_precedence_constraints(jobShopEnv, offspring)

            # C. 评估无效个体
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            if invalid_ind:
                fitnesses = toolbox.map(invalid_ind)
                for ind, fit in zip(invalid_ind, fitnesses):
                    ind.fitness.values = fit

            # D. 环境选择 (NSGA-III)
            combined_pop = [ind for ind in offspring if ind.fitness.valid] + population
            # 注意：此处使用你定义的 select_FL 逻辑
            population, FL_individuals, num_select = select_FL(
                pop_size,
                divide([ind.fitness.values for ind in combined_pop]),
                combined_pop
            )

            # --- 填充 population 到 pop_size (参考点关联逻辑) ---
            if num_select > 0 and FL_individuals:
                answer_pop = [ind.fitness.values for ind in population]
                ideal_point = np.min([ind.fitness.values for ind in (population + FL_individuals)], axis=0)

                # 理想点处理与关联逻辑
                if answer_pop:
                    ideal_answer_pop, _ = point_ideal1(answer_pop, ideal_point)
                    point_assoc_pop, _ = association(ideal_answer_pop, uniformPoint)
                else:
                    point_assoc_pop = []

                answer_fl = [ind.fitness.values for ind in FL_individuals]
                ideal_answer_fl, _ = point_ideal1(answer_fl, ideal_point)
                point_assoc_fl, d_min_fl = association(ideal_answer_fl, uniformPoint)
                sel_ind = select(num_select, point_assoc_fl, point_assoc_pop, d_min_fl)
                for indx in sel_ind:
                    population.append(FL_individuals[indx])

            # E. 更新 HOF
            hof.update(population)

            # F. 【自适应强化】代际精英强化 (每 5 代执行一次)
            if gen % 5 == 0 and len(hof) > 0:
                logging.info(
                    f"Gen {gen}: AOS-MOVNS Reinforcing Elites... Current Probs: M={movns_probs[0]:.2f}, E={movns_probs[1]:.2f}")

                elites = random.sample(list(hof), min(3, len(hof)))
                total_gen_credits = [0.0, 0.0]

                for elite in elites:
                    # 调用自适应版的 MOVNS
                    enhanced_ind, credits = Structured_MOVNS_PM(elite, toolbox, jobShopEnv, op_weights=movns_probs)

                    # 记录表现
                    total_gen_credits[0] += credits[0]
                    total_gen_credits[1] += credits[1]

                    # 替换种群
                    population[random.randint(0, len(population) - 1)] = enhanced_ind

                # --- 【核心】自适应更新概率 (Probability Matching) ---
                sum_credits = sum(total_gen_credits)
                if sum_credits > 0:
                    # 计算本次表现的目标分布
                    target_dist = [c / sum_credits for c in total_gen_credits]
                    # 滑动平均更新
                    movns_probs[0] = (1 - alpha) * movns_probs[0] + alpha * target_dist[0]
                    movns_probs[1] = (1 - alpha) * movns_probs[1] + alpha * target_dist[1]

                    # 归一化与边界修剪
                    movns_probs = [max(p_min, p) for p in movns_probs]
                    total_p = sum(movns_probs)
                    movns_probs = [p / total_p for p in movns_probs]

                hof.update(population)

            # G. 记录
            record_stats(gen, population, logbook, stats, log_file, [], logging, header=False)

            # === 【关键修正：采集每一代的收敛数据】 ===
            if hof:
                min_makespans.append(min(ind.fitness.values[0] for ind in hof))
                min_energies.append(min(ind.fitness.values[1] for ind in hof))
            else:
                min_makespans.append(min(ind.fitness.values[0] for ind in population))
                min_energies.append(min(ind.fitness.values[1] for ind in population))
            # ========================================

            logging.info(f"--- Gen {gen} Finish. Time: {time.time() - gentime:.2f}s, Best M: {min_makespans[-1]} ---")

        # --- 3. Stage 2: 最终右移节能 ---
        logging.info("\n--- Final Energy Saving Optimization ---")
        final_solutions = list(hof)
        for i in range(len(final_solutions)):
            temp_env = copy.deepcopy(jobShopEnv)
            _, _, sched_env = toolbox.evaluate_individual_double(final_solutions[i], jobShopEnv=temp_env)
            final_solutions[i] = energy_saving_right_shift(final_solutions[i], sched_env, toolbox)

        hof.clear()
        hof.update(final_solutions)
        return hof, min_makespans, min_energies, hv_history

    except Exception as e:
        logging.error(f"Critical error at gen {gen}: {e}", exc_info=True)
        return None, [], [], []


def run_rescheduling_experiments(best_individual, base_jobShopEnv, parameters, toolbox, stats, algo_exp_path):
    """
    执行动态重调度对比实验并保存三类甘特图：
    1. 静态最优方案 (在故障环境下的表现) -> Plan A
    2. 重新优化方案 (Plan B)
    3. 最终决策方案 (Final Adopted)
    """
    logging.info("\n" + "*" * 70)
    logging.info("    STARTING EVENT-DRIVEN DYNAMIC RESCHEDULING EXPERIMENTS    ")
    logging.info("*" * 70)

    # ==========================================================
    # 模拟突发故障场景 (T_bd: 故障时刻, R_k: 维修时长)
    # ==========================================================
    BREAKDOWN_MACHINE_ID = 2  # 设定 1 号机器故障
    BREAKDOWN_TIME = 150.0
    REPAIR_DURATION = 120.0

    logging.info(f"[Scenario] Machine {BREAKDOWN_MACHINE_ID} breaks at T={BREAKDOWN_TIME}, Repair={REPAIR_DURATION}")

    logging.info("\n--- Executing Plan A: Reactive Right-Shift ---")
    env_plan_A = copy.deepcopy(base_jobShopEnv)
    env_plan_A.machines[BREAKDOWN_MACHINE_ID].add_breakdown_window(BREAKDOWN_TIME, REPAIR_DURATION)

    # 评估旧解在故障环境下的表现
    makespan_A, energy_A, scheduled_env_A = evaluate_individual_double(best_individual, jobShopEnv=env_plan_A)
    logging.info(f"[Plan A] C_max: {makespan_A:.2f}, Energy: {energy_A:.2f}")

    # 【保存图 1】：方案 A (反应式右移) 的甘特图
    gantt_path_A = os.path.join(algo_exp_path, "gantt_PlanA_Reactive.png")
    draw_gantt_chart_ch5(scheduled_env_A, save_path=gantt_path_A)
    logging.info(f"Saved Plan A Gantt chart to {gantt_path_A}")

    logging.info("\n--- Executing Plan B: Complete Rescheduling ---")
    env_plan_B = copy.deepcopy(base_jobShopEnv)
    env_plan_B.machines[BREAKDOWN_MACHINE_ID].add_breakdown_window(BREAKDOWN_TIME, REPAIR_DURATION)

    with multiprocessing.Pool(processes=parameters['algorithm'].get('processes', 11),
                              initializer=init_worker,
                              initargs=(env_plan_B,)) as resched_pool:

        # 初始化重调度工具箱
        res_pop, res_toolbox, res_stats, res_hof = initialize_run(resched_pool, env_plan_B, **parameters)

        # 【机制：记忆热启动】 注入静态最优解种子
        elite_seed = res_toolbox.clone(best_individual)
        if hasattr(elite_seed.fitness, 'values'): del elite_seed.fitness.values
        res_pop[0] = elite_seed

        # 【机制：迭代次数缩减】 仅运行 50% 代数
        res_params = copy.deepcopy(parameters)
        res_params['algorithm']['ngen'] = max(10, int(parameters['algorithm']['ngen'] * 0.5))

        # 运行优化引擎
        result_B = algo_run_nsga3_movns(env_plan_B, res_pop, res_toolbox, res_stats, res_hof, **res_params)
        final_hof_B = result_B[0]

        if final_hof_B:
            # 找到 Plan B 帕累托前沿中 C_max 最小的候选解
            best_B_ind = min(final_hof_B, key=lambda ind: ind.fitness.values[0])
            m_B, e_B, env_B = evaluate_individual_double(best_B_ind, jobShopEnv=env_plan_B)

            # 【保存图 2】：方案 B (完全重排候选解) 的甘特图
            gantt_path_B = os.path.join(algo_exp_path, "gantt_PlanB_Complete.png")
            draw_gantt_chart_ch5(env_B, save_path=gantt_path_B)
            logging.info(f"[Plan B] C_max: {m_B:.2f}, Energy: {e_B:.2f}")
            logging.info(f"Saved Plan B Gantt chart to {gantt_path_B}")

            # ==========================================================
            # 方案对比与最终决策 (回退保护机制)
            # ==========================================================
            if m_B < makespan_A:
                logging.info(f"Plan B outperforms Plan A. Adopting re-optimized plan.")
                final_env = env_B
                adopted_plan_name = "PlanB_Re-optimized"
            else:
                logging.warning("Plan B is not better. Falling back to Plan A (Right-Shift).")
                final_env = scheduled_env_A
                adopted_plan_name = "PlanA_Fallback"

            # 【保存图 3】：最终采纳方案的甘特图 (以此作为最终结论)
            gantt_path_final = os.path.join(algo_exp_path, f"gantt_Final_{adopted_plan_name}.png")
            draw_gantt_chart_ch5(final_env, save_path=gantt_path_final)
            logging.info(f"Saved Final Adopted Gantt chart to {gantt_path_final}")

def main(param_file=PARAM_FILE):
    # 1. 解析命令行参数
    parser = argparse.ArgumentParser(description="Run Comparison for Job Shop Scheduling")
    parser.add_argument("config_file", metavar='-f', type=str, nargs="?", default=param_file)
    args = parser.parse_args()

    # 2. 加载参数和【原始】环境模板
    parameters = load_parameters(args.config_file)
    base_jobShopEnv = load_job_shop_env(parameters['instance']['problem_instance'])

    # 3. 构建一个通用的、本次对比实验的根目录
    # --- 【新修改】: 获取当前运行的脚本文件名作为一级目录 ---
    script_filename = os.path.basename(__file__)  # 获取 'run_comparison.py'
    script_name_str, _ = os.path.splitext(script_filename)  # 获取 'run_comparison'
    # 3. 【核心修改】：构建按数据集分类的目录结构
    instance_full_path = parameters['instance']['problem_instance']
    instance_basename = os.path.basename(instance_full_path)
    problem_name_str, _ = os.path.splitext(instance_basename)  # 如 0DAFJS05

    # 构造具体某一次运行的文件夹名称 (带参数和时间戳)
    params_str = f"ngen{parameters['algorithm']['ngen']}_pop{parameters['algorithm']['population_size']}"
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    run_folder_name = f"{params_str}_{timestamp}"

    # 构建最终路径：results/comparison_runs/0DAFJS05/ngen300_pop100_时间戳/
    comparison_base_path = os.path.abspath(os.path.join(DEFAULT_RESULTS_ROOT, problem_name_str, run_folder_name))

    os.makedirs(comparison_base_path, exist_ok=True)
    logging.info(f"All comparison results for this run will be saved under: {comparison_base_path}")

    # 定义要运行的算法及其对应的执行函数
    algorithms_to_run = {
        "nsga3": algo_run_nsga3_movns,
    }

    # --- 【修改点】: 这个字典现在要存储更多信息以供绘图函数使用 ---
    all_algorithm_results = {}

    # 4. 启动并行池
    with multiprocessing.Pool(processes=parameters['algorithm'].get('processes', 11),
                              initializer=init_worker,
                              initargs=(base_jobShopEnv,)) as pool:

        # 循环运行每个定义的算法
        for algo_name, algo_function in algorithms_to_run.items():
            logging.info("\n" + "=" * 80)
            logging.info(f"             STARTING ALGORITHM: {algo_name.upper()}             ")
            logging.info("=" * 80)

            algo_exp_path = os.path.join(comparison_base_path, algo_name)
            os.makedirs(algo_exp_path, exist_ok=True)
            log_file_path = os.path.join(algo_exp_path, "convergence_log.csv")
            if 'output' not in parameters: parameters['output'] = {}
            parameters['output']['logbook_file'] = log_file_path

            current_run_env = copy.deepcopy(base_jobShopEnv)
            current_run_params = copy.deepcopy(parameters)

            population, toolbox, stats, hof = initialize_run(pool, current_run_env, **current_run_params)

            # 调用算法
            result = algo_function(
                current_run_env, population, toolbox, stats, hof, **current_run_params)

            # 【修改】解包 4 个返回值
            final_pareto_front, min_makespans, min_energies, hv_history = result

            # 【新增：保存 HV 历史到文件】
            hv_file_path = os.path.join(algo_exp_path, "hv_history.csv")
            np.savetxt(hv_file_path, np.array(hv_history), delimiter=",", header="hv", comments="")
            logging.info(f"✅ ==> HV history saved to: {hv_file_path}")

            # 【修改】存储结果
            if final_pareto_front is not None:
                all_algorithm_results[algo_name] = {
                    'min_makespans': min_makespans,
                    'min_energies': min_energies,
                    'pareto_front': final_pareto_front
                }

            # --- 单个算法的结果处理（如保存PF数据和甘特图）保持不变 ---
            if not final_pareto_front:
                logging.warning(f"Algorithm '{algo_name}' finished with errors or empty HOF.")
                continue

            logging.info(f"\n--- Processing individual results for {algo_name.upper()} ---")
            pf_filename = f"{problem_name_str}_pareto_front.txt"
            output_path = os.path.join(algo_exp_path, pf_filename)
            try:
                final_pf_values = np.array([ind.fitness.values for ind in final_pareto_front])
                np.savetxt(output_path, final_pf_values, fmt='%.4f', header="Makespan Energy", comments="")
                logging.info(f"✅ ==> Individual Pareto front for {algo_name.upper()} saved to: {output_path}")
            except Exception as e:
                logging.error(f"Failed to save Pareto front data for {algo_name.upper()}: {e}")

            if parameters['output']['plotting']:
                best_makespan_ind = min(final_pareto_front, key=lambda ind: ind.fitness.values[0])
                final_clean_env_for_plot = copy.deepcopy(base_jobShopEnv)

                # 1. 生成初始的左移调度环境
                makespan, total_power, drawn_env = evaluate_individual_double(
                    best_makespan_ind, final_clean_env_for_plot
                )

                logging.info(
                    f"Initial (Left-Shift) Stats for {algo_name.upper()}: Makespan={makespan}, Energy={total_power}")

                logging.info(f"Applying Right-Shift to generate the final Gantt chart for {algo_name.upper()}...")
                try:

                    _ = energy_saving_right_shift(best_makespan_ind, drawn_env, toolbox)

                    final_makespan = drawn_env.makespan
                    final_power = drawn_env.total_machinepower
                    logging.info(f"Final (Right-Shift) Stats: Makespan={final_makespan}, Energy={final_power}")

                except Exception as e:
                    logging.warning(
                        f"Right-shift application failed during plotting: {e}. Plotting left-shift chart instead.")

                gantt_filename = f"gantt_chart_best_makespan.png"
                gantt_path = os.path.join(algo_exp_path, gantt_filename)

                draw_gantt_chart_ch5(drawn_env, save_path=gantt_path)

                if algo_name == "nsga3":
                    try:
                        # 运行我们在上面定义的重调度实验
                        run_rescheduling_experiments(
                            best_individual=best_makespan_ind,
                            base_jobShopEnv=base_jobShopEnv,
                            parameters=current_run_params,
                            toolbox=toolbox,
                            stats=stats,
                            algo_exp_path=algo_exp_path
                        )
                    except Exception as e:
                        logging.error(f"Failed to run rescheduling experiments: {e}", exc_info=True)

    if not all_algorithm_results:
        logging.error("All algorithm runs failed. No data available for comparison plotting. Exiting.")
        return

    # 将对比图保存在总的结果目录下
    generate_comparison_plots(all_algorithm_results, save_dir=comparison_base_path)

    logging.info("\nComparison run finished successfully.")


if __name__ == "__main__":
    main()
