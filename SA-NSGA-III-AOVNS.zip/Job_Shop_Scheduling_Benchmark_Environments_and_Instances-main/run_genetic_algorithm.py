import argparse
import logging
import multiprocessing
import numpy as np

import matplotlib.pyplot as plt
import pandas as pd
import os
from deap import base, creator, tools
from multiprocessing.pool import Pool


from plotting.drawer import draw_precedence_relations, draw_gantt_chart
from solutions.helper_functions import record_stats, load_parameters, load_job_shop_env, dict_to_excel
from solutions.genetic_algorithm.operators import (evaluate_population, evaluate_individual, variation,
                                                   init_individual, init_population, mutate_shortest_proc_time,
                                                   mutate_sequence_exchange, pox_crossover, repair_precedence_constraints)

logging.basicConfig(level=logging.INFO)

PARAM_FILE = "configs/genetic_algorithm.toml"
DEFAULT_RESULTS_ROOT = "./results/single_runs"


def initialize_run(pool: Pool, **kwargs):
    """Initializes the run by setting up the environment, toolbox, statistics, hall of fame, and initial population.

    Args:
        pool: Multiprocessing pool.
        kwargs: Additional keyword arguments.

    Returns:
        A tuple containing the initial population, toolbox, statistics, hall of fame, and environment.
    """
    try:
        jobShopEnv = load_job_shop_env(kwargs['instance']['problem_instance'])
    except FileNotFoundError:
        logging.error(f"Problem instance {kwargs['instance']['problem_instance']} not found.")
        return

    toolbox = base.Toolbox()
    toolbox.register("map", pool.map)
    creator.create("Fitness", base.Fitness, weights=(-1.0, -1.0))
    creator.create("Individual", list, fitness=creator.Fitness)

    toolbox.register("init_individual", init_individual, creator.Individual, kwargs, jobShopEnv=jobShopEnv)
    toolbox.register("mate_TwoPoint", tools.cxTwoPoint)
    toolbox.register("mate_Uniform", tools.cxUniform, indpb=0.5)
    toolbox.register("mate_POX", pox_crossover, nr_preserving_jobs=1)

    toolbox.register("mutate_machine_selection", mutate_shortest_proc_time, jobShopEnv=jobShopEnv)
    toolbox.register("mutate_operation_sequence", mutate_sequence_exchange)
    toolbox.register("select", tools.selTournament, k=kwargs['algorithm']['population_size'], tournsize=3)
    toolbox.register("evaluate_individual", evaluate_individual, jobShopEnv=jobShopEnv)

    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("std", np.std, axis=0)
    stats.register("min", np.min, axis=0)
    stats.register("max", np.max, axis=0)

    hof = tools.HallOfFame(1)

    initial_population = init_population(toolbox, kwargs['algorithm']['population_size'], )
    try:
        fitnesses = evaluate_population(toolbox, initial_population, logging)
    except Exception as e:
        logging.error(f"An error occurred during initial population evaluation: {e}")
        return

    for ind, fit in zip(initial_population, fitnesses):
        ind.fitness.values = fit

    return initial_population, toolbox, stats, hof, jobShopEnv


def algo_run(jobShopEnv, population, toolbox, folder, exp_name, stats=None, hof=None, **kwargs):
    """Executes the genetic algorithm and returns the best individual.

    Args:
        jobShopEnv: The problem environment.
        population: The initial population.
        toolbox: DEAP toolbox.
        folder: The folder to save results in.
        exp_name: The experiment name.
        stats: DEAP statistics (optional).
        hof: Hall of Fame (optional).
        kwargs: Additional keyword arguments.

    Returns:
        The best individual found by the genetic algorithm.
    """

    try:
        if kwargs['output']['plotting']:
            draw_precedence_relations(jobShopEnv)

        hof.update(population)

        gen = 0
        df_list = []
        logbook = tools.Logbook()
        logbook.header = ["gen"] + (stats.fields if stats else [])

        # Update the statistics with the new population
        record_stats(gen, population, logbook, stats, kwargs['output']['logbook'], df_list, logging)

        if kwargs['output']['logbook']:
            logging.info(logbook.stream)

        for gen in range(1, kwargs['algorithm']['ngen'] + 1):
            # Vary the population
            offspring = variation(population, toolbox, kwargs['algorithm']['population_size'], kwargs['algorithm']['cr'], kwargs['algorithm']['indpb'])

            # Ensure that precedence constraints between jobs are satisfied (only for assembly scheduling (fajsp))
            if '/dafjs/' or '/yfjs/' in jobShopEnv.instance_name:
                offspring = repair_precedence_constraints(jobShopEnv, offspring)

            # Evaluate the population
            fitnesses = evaluate_population(toolbox, offspring, logging)
            for ind, fit in zip(offspring, fitnesses):
                ind.fitness.values = fit

            # Update the hall of fame with the generated individuals
            hof.update(offspring)

            # Select next generation population
            population[:] = toolbox.select(population + offspring)
            # Update the statistics with the new population
            record_stats(gen, population, logbook, stats, kwargs['output']['logbook'], df_list, logging)
            make_span, total_machinepower = evaluate_individual(hof[0], jobShopEnv, reset=False)

        if kwargs['output']['plotting']:
            makespan, total_machinepower = evaluate_individual(hof[0], jobShopEnv, reset=False)
            logging.info('make_span: %s', jobShopEnv.makespan)
            # logging.info('total_workload: %s', jobShopEnv.total_workload)
            logging.info('total_machinepower: %s', jobShopEnv.total_machinepower)
            draw_gantt_chart(jobShopEnv)
            # 在算法循环结束后添加以下代码
        try:
            df = pd.DataFrame(df_list)
            df = df.sort_values("gen")  # 按代数排序

            # 确保 "gen" 列是连续的（修复可能的跳跃）
            df["gen"] = df["gen"].astype(int)
            df = df.set_index("gen").reindex(
                range(df["gen"].min(), df["gen"].max() + 1)
            ).reset_index()

            # 绘制连续曲线
            plt.figure(figsize=(12, 6))
            plt.plot(df["gen"], df["min_0"], "b-", linewidth=2, label="Makespan")
            plt.xlabel("Generation", fontsize=12)
            plt.ylabel("Makespan", fontsize=12)

            # plt.plot(df["gen"], df["min_0"], "r-", linewidth=2, label="total_machinepower")
            # plt.xlabel("Generation", fontsize=12)
            # plt.ylabel("total_machinepower", fontsize=12)
            plt.title(f"Convergence Curve ({jobShopEnv.instance_name})", fontsize=14)
            plt.legend()

            # 保存图像
            plot_path = f"{folder}{exp_name}/convergence_curve.png"
            plt.savefig(plot_path, dpi=300, bbox_inches="tight")
            plt.close()
            logging.info(f"Saved smooth convergence curve to: {plot_path}")
        except Exception as e:
            logging.error(f"Failed to plot smooth curve: {e}")

    except Exception as e:
        logging.error(f"An error occurred during the algorithm run: {e}")


def main(param_file=PARAM_FILE):
    try:
        parameters = load_parameters(param_file)
    except FileNotFoundError:
        logging.error(f"Parameter file {param_file} not found.")
        return

    pool = multiprocessing.Pool()  #进程池
    # 构建一个folder路径字符串，用于存储结果数据
    folder = (
            DEFAULT_RESULTS_ROOT
            + "/"
            + str(parameters['instance']['problem_instance']) # 问题实例
            + "/ngen"
            + str(parameters['algorithm']["ngen"])
            + "_pop"
            + str(parameters['algorithm']['population_size'])
            + "_cr"
            + str(parameters['algorithm']["cr"])  # 交叉概率
            + "_indpb"
            + str(parameters['algorithm']["indpb"])  # 变异概率
    )

    exp_name = ("/rseed" + str(parameters['algorithm']["rseed"]) + "/")  # 构造一个包含随机种子（rseed）的路径部分
    population, toolbox, stats, hof, jobShopEnv = initialize_run(pool, **parameters)
    best_individual = algo_run(jobShopEnv, population, toolbox, folder, exp_name, stats, hof, **parameters)
    return best_individual


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run GA")
    parser.add_argument(
        "config_file",
        metavar='-f',
        type=str,
        nargs="?",
        default=PARAM_FILE,
        help="path to config file",
    )

    args = parser.parse_args()
    main(param_file=args.config_file)
