import os
import tomli

import pandas as pd

from scheduling_environment.jobShop import JobShop
from data_parsers import parser_fajsp, parser_fjsp, parser_jsp_fsp, parser_fjsp_sdst


def load_parameters(config_toml):
    """Load parameters from a toml file"""
    with open(config_toml, "rb") as f:
        config_params = tomli.load(f)
    return config_params


def load_job_shop_env(problem_instance: str, from_absolute_path=False) -> JobShop:
    jobShopEnv = JobShop()
    if '/fsp/' in problem_instance or '/jsp/' in problem_instance:
        jobShopEnv = parser_jsp_fsp.parse(jobShopEnv, problem_instance, from_absolute_path)
    elif '/fjsp/' in problem_instance:
        jobShopEnv = parser_fjsp.parse(jobShopEnv, problem_instance, from_absolute_path)
    elif '/fjsp_sdst/' in problem_instance:
        jobShopEnv = parser_fjsp_sdst.parse(jobShopEnv, problem_instance, from_absolute_path)
    elif '/fajsp/' in problem_instance:
        jobShopEnv = parser_fajsp.parse(jobShopEnv, problem_instance, from_absolute_path)
    else:
        raise NotImplementedError(
            f"""Problem instance {
            problem_instance
            } not implemented"""
        )
    jobShopEnv._name = problem_instance
    return jobShopEnv


def create_stats_list(population, gen):
    stats_list = []
    for ind in population:
        tmp_dict = {}
        tmp_dict.update(
            {
                "Generation": gen,
                "obj1": ind.fitness.values[0]
            })
        if hasattr(ind, "objectives"):
            tmp_dict.update(
                {
                    "obj1": ind.objectives[0],
                }
            )
        tmp_dict = {**tmp_dict}
        stats_list.append(tmp_dict)
    return stats_list


# def record_stats(gen, population, logbook, stats, verbose, df_list, logging):
#     stats_list = create_stats_list(population, gen)
#     df_list.append(pd.DataFrame(stats_list))
#     record = stats.compile(population) if stats is not None else {}
#     logbook.record(gen=gen, **record)
#     if verbose:
#         logging.info(logbook.stream)

def record_stats(gen, population, logbook, stats, log_path, extra_stats, logging_module, header=False):
    """
    记录、打印并保存【当前代】的统计数据。

    【已更新】: 解决了日志文件内容重复累积的问题。

    Args:
        gen (int): 当前代数。
        population (list): 当前种群。
        logbook (tools.Logbook): DEAP 的日志本对象。
        stats (tools.Statistics): DEAP 的统计对象。
        log_path (str or None): 日志文件的保存路径。如果为 None，则不保存文件。
        extra_stats (list): 需要记录的额外统计数据列表, e.g., [('avg_makespan', 123)]。
        logging_module: 用于输出日志的 logging 模块实例。
        header (bool): 如果为 True, 则打印并写入日志的表头。
    """
    record = stats.compile(population) if stats else {}

    # 将额外的统计数据添加到记录中
    for key, value in extra_stats:
        record[key] = value

    logbook.record(gen=gen, **record)

    # --- 【核心修改】: 从 logbook 中获取最后一条（即当前这一代的）记录 ---
    # logbook.stream 在大多数情况下是正确的，但为了绝对保险，我们用 logbook[-1]
    # logbook[-1] 返回一个字典，例如 {'gen': 10, 'avg': [12.3, 45.6], ...}
    latest_entry_str = logbook.stream

    # --- 打印逻辑保持不变 ---
    # 打印表头
    if header:
        if hasattr(logbook, 'header') and logbook.header:
            # 格式化表头，使其更易读
            # 这里我们用 logbook.header 而不是 latest_entry_str 的键，因为顺序是固定的
            header_str = "\t".join(map(str, logbook.header))
            logging_module.info(header_str)
        else:
            logging_module.warning("请求打印日志表头，但未能找到。")

    # 打印当前代的统计数据
    logging_module.info(latest_entry_str)

    # --- 【核心修改】: 文件写入逻辑 ---
    if log_path:
        try:
            log_dir = os.path.dirname(log_path)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

            # 使用 'a' (追加) 模式打开文件。如果文件不存在，会自动创建。
            with open(log_path, "a", encoding='utf-8') as f:
                # 如果是第0代或明确要求写入表头，则先写入表头
                if gen == 0 or header:
                    # 确保只在文件为空或者gen=0时才写header，防止重复
                    f.seek(0, os.SEEK_END)  # 移动到文件末尾
                    if f.tell() == 0:  # 检查文件是否为空
                        header_line = "\t".join(map(str, logbook.header)) + "\n"
                        f.write(header_line)

                # 只写入当前这一代的记录，而不是整个logbook
                # 我们复用已经格式化好的 latest_entry_str
                f.write(latest_entry_str + "\n")

        except Exception as e:
            logging_module.error(f"写入日志文件 {log_path} 失败: {e}")

# def record_stats(gen, population, logbook, stats, log_path, extra_stats, logging_module, header=False):
#     """
#     【最终修正版】记录并打印统计数据，同时将格式化数据写入指定文件。
#     """
#     record = stats.compile(population) if stats else {}
#     for key, value in extra_stats:
#         record[key] = value
#
#     logbook.record(gen=gen, **record)
#
#     # 1. 打印到控制台 (保持不变，用于实时观察)
#     if header and gen == 0:
#         if hasattr(logbook, 'header') and logbook.header:
#             header_str = "gen\t" + "\t".join([f"{h:<32}" for h in logbook.header[1:]])
#             logging_module.info(header_str)
#     logging_module.info(logbook.stream)
#
#     # 2. 【核心】将数据写入文件
#     if log_path:
#         # 如果是第0代，并且要求写表头，就用 'w' (写入) 模式创建文件并写入表头
#         if gen == 0 and header:
#             try:
#                 with open(log_path, 'w') as f:
#                     # 我们只写入后续分析需要的列，格式清晰
#                     f.write("gen\tmin_makespan\tmin_energy\n")
#             except IOError as e:
#                 logging_module.error(f"无法写入日志文件表头 {log_path}: {e}")
#                 return
#
#         # 对于所有代，用 'a' (追加) 模式追加写入当前代的数据
#         try:
#             with open(log_path, 'a') as f:
#                 min_vals = record.get('min', [float('nan'), float('nan')])
#                 # 确保写入文件的数据也是制表符分隔
#                 f.write(f"{gen}\t{min_vals[0]}\t{min_vals[1]}\n")
#         except (IOError, IndexError) as e:
#             logging_module.error(f"无法追加日志到文件 {log_path}: {e}")

def update_operations_available_for_scheduling(env):
    scheduled_operations = set(env.scheduled_operations)
    precedence_relations = env.precedence_relations_operations
    operations_available = [
        operation
        for operation in env.operations
        if operation not in scheduled_operations and all(
            prec_operation in scheduled_operations
            for prec_operation in precedence_relations[operation.operation_id]
        )
    ]
    env.set_operations_available_for_scheduling(operations_available)


def dict_to_excel(dictionary, folder, filename):
    """Save outputs in files"""

    # Check if the folder exists, if not, create it
    if not os.path.exists(folder):
        os.makedirs(folder)

    # Check if the file exists, if so, give a warning
    full_path = os.path.join(folder, filename)
    if os.path.exists(full_path):
        print(f"Warning: {full_path} already exists. Overwriting file.")

    # Convert the dictionary to a DataFrame
    df = pd.DataFrame([dictionary])

    # Save the DataFrame to Excel
    df.to_excel(full_path, index=False, engine='openpyxl')
