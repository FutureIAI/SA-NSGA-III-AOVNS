
import numpy as np
import random
import logging
import copy
from deap import base, creator, tools
import sys
from scheduling_environment.jobShop import JobShop
import traceback
from solutions.helper_functions import update_operations_available_for_scheduling

def build_disjunctive_graph(individual, scheduled_env: JobShop):
    """
    【修正版】构建析取图，能够处理虚拟维护工序 (ID=999999)
    """
    num_ops = len(scheduled_env.operations)
    nodes = [-1, -2] + list(range(num_ops))
    adj = {node: [] for node in nodes}

    # 1. 整理工序信息 (过滤掉维护工序)
    # 注意：原始环境的 operations 列表里没有 999999，所以这里不用变
    operations_by_id = {op.operation_id: op for op in scheduled_env.operations}

    # 2. 添加连通弧 (作业内部) - 不受维护影响，因为维护工序不属于任何 Job
    for job in scheduled_env.jobs:
        for i in range(len(job.operations) - 1):
            op_curr = job.operations[i]
            op_next = job.operations[i + 1]
            p_curr = op_curr.scheduling_information.get('processing_time', 0)
            adj[op_curr.operation_id].append((op_next.operation_id, p_curr))

    # 3. 添加析取弧 (机器上) - 【核心修改点】
    for machine in scheduled_env.machines:
        # 这里的 scheduled_operations 可能包含 999999
        ops = machine.scheduled_operations

        # 我们构建一个临时列表，只包含真实工序
        real_ops = [op for op in ops if op.operation_id != 999999]

        for i in range(len(real_ops) - 1):
            op_curr = real_ops[i]
            op_next = real_ops[i + 1]

            p_curr = op_curr.scheduling_information.get('processing_time', 0)

            # 【高级修正】如果两个真实工序中间夹了一个维护工序，
            # 前一个工序到后一个工序的“距离”应该加上维护时间吗？
            # 析取图通常用于寻找关键路径。维护时间是刚性的，确实会推迟后续工序。
            # 但为了简化逻辑，不破坏 adj 的结构，我们先只连接真实工序。
            # 实际加工时间 p_curr 已经包含了恶化，所以关键路径计算大体是准的。

            # 确保 ID 在 adj 里
            if op_curr.operation_id in adj:
                adj[op_curr.operation_id].append((op_next.operation_id, p_curr))

        # 4. 连接源点和汇点
        all_op_ids = set(range(num_ops))
        non_start_nodes = set()
        for u in adj:
            for v, w in adj[u]:
                if v >= 0: non_start_nodes.add(v)

        start_nodes = all_op_ids - non_start_nodes
        end_nodes = [op_id for op_id in all_op_ids if not adj.get(op_id, [])]

        for start_node in start_nodes: adj[-1].append((start_node, 0))
        for end_node in end_nodes:
            # 【修正】直接访问字典获取 'processing_time'
            p_end = operations_by_id[end_node].scheduling_information.get('processing_time', 0)
            adj[end_node].append((-2, p_end))

        return adj

def find_critical_path(adj):
    nodes = list(adj.keys())
    in_degree = {u: 0 for u in nodes}
    for u in adj:
        for v, w in adj[u]: in_degree[v] = in_degree.get(v, 0) + 1

    queue = [u for u in nodes if in_degree.get(u, 0) == 0]
    topo_order = []
    while queue:
        u = queue.pop(0)
        topo_order.append(u)
        for v, w in adj.get(u, []):
            in_degree[v] -= 1
            if in_degree[v] == 0: queue.append(v)

    dist, pred = {node: -1 for node in nodes}, {node: None for node in nodes}
    dist[-1] = 0

    for u in topo_order:
        if dist[u] > -1:
            for v, w in adj.get(u, []):
                if dist[u] + w > dist.get(v, -1):
                    dist[v], pred[v] = dist[u] + w, u

    critical_path = []
    curr = -2
    while curr is not None:
        if curr not in [-1, -2]: critical_path.append(curr)
        curr = pred.get(curr)

    return list(reversed(critical_path))


# -----------------------------------------------------------------
# 模块六：ETMA 的潜在解选择策略
# -----------------------------------------------------------------

def potential_solution_selection(population, ps, scale, toolbox):
    """
    【完整实现】论文 Algorithm 4 的逻辑：潜力解选择策略
    """
    logging.info(f"Running Potential Solution Selection to choose {ps} individuals...")

    if not population:
        logging.warning("Cannot select potential solutions from an empty population.")
        return []

    # 1. 非支配排序，并选择前几层，直到个体数 >= ps * scale
    num_to_select_from = int(ps * scale)
    if len(population) <= num_to_select_from:
        potential_subset = population
    else:
        # 使用DEAP的非支配排序工具
        fronts = tools.emo.sortNondominated(population, len(population))
        potential_subset = []
        for front in fronts:
            potential_subset.extend(front)
            if len(potential_subset) >= num_to_select_from:
                break
        # 精确截取到 num_to_select_from 个
        potential_subset = potential_subset[:num_to_select_from]

    if len(potential_subset) <= ps:
        return potential_subset

    # 2. 使用最大-最小距离法 (Max-Min Distance) 从子集中采样 ps 个体
    selected_solutions = []
    remaining_solutions = list(potential_subset)

    # 随机选择第一个点
    first_sol = random.choice(remaining_solutions)
    selected_solutions.append(first_sol)
    remaining_solutions.remove(first_sol)

    while len(selected_solutions) < ps:
        max_min_dist = -1
        best_candidate = None

        for rem_sol in remaining_solutions:
            # 计算该点到所有已选点的最小距离
            min_dist_to_selected = float('inf')
            for sel_sol in selected_solutions:
                # 确保适应度值是有效的numpy数组
                try:
                    dist = np.linalg.norm(np.array(rem_sol.fitness.values) -
                                          np.array(sel_sol.fitness.values))
                    if dist < min_dist_to_selected:
                        min_dist_to_selected = dist
                except Exception:
                    # 如果某个解的适应度无效，给一个很小的距离，避免选中它
                    min_dist_to_selected = 1e-9
                    break

            # 寻找具有最大“最小距离”的点
            if min_dist_to_selected > max_min_dist:
                max_min_dist = min_dist_to_selected
                best_candidate = rem_sol

        if best_candidate:
            selected_solutions.append(best_candidate)
            remaining_solutions.remove(best_candidate)
        else:  # 如果所有剩余点都重复或无效，随机选一个以填满
            if not remaining_solutions: break
            selected_solutions.append(remaining_solutions.pop())

    return selected_solutions

# 【新增】一个辅助函数
def find_critical_blocks(critical_path, scheduled_env):
    # ... (这个函数我们之前写过，现在正式启用它) ...
    if not critical_path: return []
    operations_by_id = {op.operation_id: op for op in scheduled_env.operations}
    blocks, current_block = [], [critical_path[0]]
    for i in range(len(critical_path) - 1):
        op1_id, op2_id = critical_path[i], critical_path[i+1]
        machine1 = operations_by_id[op1_id].scheduled_machine
        machine2 = operations_by_id[op2_id].scheduled_machine
        if machine1 == machine2:
            current_block.append(op2_id)
        else:
            blocks.append(current_block)
            current_block = [op2_id]
    blocks.append(current_block)
    return blocks

# -----------------------------------------------------------------
# 模块一：ETMA-Lite 的局部搜索 (VNS) 算子 - 机器重新分配
# -----------------------------------------------------------------

def local_search_operator_1(individual, critical_path, jobShopEnv, toolbox):
    """
    VNS 算子 1 (简化版): 机器调整。
    从关键路径上随机选择一个工序，尝试将其移动到能使其最早完成的另一台机器上。
    """
    logging.info("Running VNS Operator 1 (Machine Reassignment)...")
    if not critical_path: return individual

    # 随机选择关键路径上的一个工序
    op_id_to_move = random.choice(critical_path)
    operation = jobShopEnv.operations[op_id_to_move]

    if len(operation.processing_times) <= 1:
        return individual  # 如果只有一个可用机器，无法调整

    current_machine_idx = individual[0][op_id_to_move]
    current_machine_id = sorted(operation.processing_times.keys())[current_machine_idx]

    best_machine_id = current_machine_id
    best_makespan = float('inf')

    # 评估当前解的完工时间作为基准
    try:
        current_makespan, _, _ = toolbox.evaluate_individual_double(individual)
        best_makespan = current_makespan
    except (ValueError, TypeError):
        return individual

    # 尝试移动到其他所有可用机器
    for m_id in operation.processing_times.keys():
        if m_id == current_machine_id: continue

        neighbor = toolbox.clone(individual)
        # 更新机器选择编码
        sorted_machines = sorted(operation.processing_times.keys())
        neighbor[0][op_id_to_move] = sorted_machines.index(m_id)

        try:
            # 评估新解的性能
            makespan, _, _ = toolbox.evaluate_individual_double(neighbor)
            if makespan < best_makespan:
                best_makespan = makespan
                best_machine_id = m_id
        except (ValueError, TypeError):
            continue

    # 如果找到了更好的机器，则更新原个体
    if best_machine_id != current_machine_id:
        logging.info(f"VNS Operator 1: Found better machine for op {op_id_to_move}. Moving to M{best_machine_id}.")
        sorted_machines = sorted(operation.processing_times.keys())
        individual[0][op_id_to_move] = sorted_machines.index(best_machine_id)

    return individual

# -----------------------------------------------------------------
# 模块三：ETMA-Lite 的局部搜索 (VNS) 算子 - 关键路径交换
# -----------------------------------------------------------------

def local_search_operator_4(individual, critical_path, jobShopEnv):
    """
    VNS 算子 4: 交换关键路径上最后两个工序，如果能减少老化效应。
    """
    if len(critical_path) < 2:
        return individual

    op_last_id = critical_path[-1]
    op_second_last_id = critical_path[-2]

    # 获取工序对象
    op_last = jobShopEnv.operations[op_last_id]
    op_second_last = jobShopEnv.operations[op_second_last_id]

    # 获取它们在当前解中的机器分配
    machine_last_idx = individual[0][op_last_id]
    machine_second_last_idx = individual[0][op_second_last_id]

    machine_last_id = sorted(op_last.processing_times.keys())[machine_last_idx]
    machine_second_last_id = sorted(op_second_last.processing_times.keys())[machine_second_last_idx]

    # 获取标准加工时间
    p_last = op_last.processing_times[machine_last_id]
    p_second_last = op_second_last.processing_times[machine_second_last_id]

    # 论文逻辑：如果标准加工时间短的工序在后面，就交换它们
    if p_last < p_second_last:
        logging.info(f"VNS Operator 4: Swapping op {op_second_last_id} and {op_last_id}.")
        # 在 OS 序列中找到它们的位置并交换
        os_sequence = individual[1]
        try:
            idx_last = os_sequence.index(op_last.job_id)
            idx_second_last = os_sequence.index(op_second_last.job_id)
            os_sequence[idx_last], os_sequence[idx_second_last] = os_sequence[idx_second_last], os_sequence[idx_last]
        except ValueError:
            pass  # 如果工序因为属于同一job而只有一个ID在序列中，则无法交换

    return individual


# -----------------------------------------------------------------
# 模块二：ETMA-Lite 的局部搜索 (VNS) 算子 - 关键块调整
# -----------------------------------------------------------------

def local_search_operator_3(individual, critical_blocks, jobShopEnv):
    """
    VNS 算子 3: 调整关键块。
    随机选择一个关键块，尝试将块内的某个工序移动到另一台可选机器上。
    """
    logging.info("Running VNS Operator 3 (Critical Block Adjustment)...")
    if not critical_blocks: return individual

    block_to_move = random.choice(critical_blocks)
    op_id_to_move = random.choice(block_to_move)  # 从块中随机选一个
    operation = jobShopEnv.operations[op_id_to_move]

    if len(operation.processing_times) <= 1: return individual

    current_machine_idx = individual[0][op_id_to_move]
    current_machine_id = sorted(operation.processing_times.keys())[current_machine_idx]

    # 选一个不同于当前机器的新机器
    other_machines = [m_id for m_id in operation.processing_times.keys() if m_id != current_machine_id]
    if not other_machines: return individual

    new_machine_id = random.choice(other_machines)
    logging.info(f"VNS Operator 3: Moving op {op_id_to_move} from M{current_machine_id} to M{new_machine_id}.")

    sorted_machines = sorted(operation.processing_times.keys())
    individual[0][op_id_to_move] = sorted_machines.index(new_machine_id)

    return individual


# -----------------------------------------------------------------
# 模块四：ETMA-Lite 的局部搜索 (VNS) 算子 - 插入操作调整
# -----------------------------------------------------------------

def local_search_operator_5(individual, jobShopEnv, toolbox):
    """
    VNS 算子 5: 前向插入以减少空闲时间。
    随机选择一个工序，尝试将其插入到目标机器的某个空闲时隙中。
    """
    logging.info("Running VNS Operator 5 (Forward Insertion)...")

    # 随机选择一个工序
    op_id_to_insert = random.randrange(len(individual[1]))
    job_id_to_insert = individual[1][op_id_to_insert]

    # 找到这个工序在job内的真实op对象 (这部分比较tricky)
    # 我们需要一个临时计数器
    job_op_counts = {job.job_id: 0 for job in jobShopEnv.jobs}
    op_to_insert_obj = None
    for i in range(len(individual[1])):
        jid = individual[1][i]
        op_idx_in_job = job_op_counts[jid]
        if i == op_id_to_insert:
            op_to_insert_obj = jobShopEnv.jobs[jid].operations[op_idx_in_job]
            break
        job_op_counts[jid] += 1

    if not op_to_insert_obj: return individual

    # 找到它当前分配的机器
    machine_idx = individual[0][op_to_insert_obj.operation_id]
    machine_id = sorted(op_to_insert_obj.processing_times.keys())[machine_idx]

    # 从OS序列中移除，准备插入
    os_sequence = list(individual[1])
    os_sequence.pop(op_id_to_insert)

    best_makespan = float('inf')
    best_os_sequence = list(individual[1])

    # 尝试所有可能的插入位置
    for i in range(len(os_sequence) + 1):
        temp_os = os_sequence[:i] + [job_id_to_insert] + os_sequence[i:]
        neighbor = toolbox.clone(individual)
        neighbor[1] = temp_os
        try:
            makespan, _, _ = toolbox.evaluate_individual_double(neighbor)
            if makespan < best_makespan:
                best_makespan = makespan
                best_os_sequence = temp_os
        except (ValueError, TypeError):
            continue

    individual[1] = best_os_sequence
    return individual


def local_search_operator_5_swap(individual, critical_path, jobShopEnv):
    """
    VNS 算子 5 (变体): 关键路径与非关键路径工序交换。
    随机选择关键路径上的一个工序和非关键路径上的一个工序，交换它们在OS序列中的位置。
    """
    logging.info("Running VNS Operator 5 (Swap Critical/Non-Critical)...")
    if not critical_path or len(critical_path) == len(individual[1]):
        return individual  # 如果所有工序都在关键路径上，无法交换

    all_op_ids = set(range(len(jobShopEnv.operations)))
    critical_path_set = set(critical_path)
    non_critical_op_ids = list(all_op_ids - critical_path_set)

    if not non_critical_op_ids: return individual

    # 随机选择一个关键路径工序和一个非关键路径工序
    op_id_critical = random.choice(critical_path)
    op_id_non_critical = random.choice(non_critical_op_ids)

    job_id_critical = jobShopEnv.operations[op_id_critical].job_id
    job_id_non_critical = jobShopEnv.operations[op_id_non_critical].job_id

    # 在OS序列中找到它们的位置并交换
    os_sequence = individual[1]
    try:
        # 注意：OS序列是 job_id 列表，我们需要找到它们的某一次出现
        indices_critical = [i for i, x in enumerate(os_sequence) if x == job_id_critical]
        indices_non_critical = [i for i, x in enumerate(os_sequence) if x == job_id_non_critical]

        if indices_critical and indices_non_critical:
            idx_to_swap1 = random.choice(indices_critical)
            idx_to_swap2 = random.choice(indices_non_critical)
            os_sequence[idx_to_swap1], os_sequence[idx_to_swap2] = os_sequence[idx_to_swap2], os_sequence[idx_to_swap1]
            logging.info(f"VNS Operator 5: Swapped job {job_id_critical} and {job_id_non_critical} in OS sequence.")
    except IndexError:
        pass

    return individual

# -----------------------------------------------------------------
# 模块五：能耗优化 - 右移节能策略
# -----------------------------------------------------------------
def energy_saving_right_shift(individual, scheduled_env: JobShop, toolbox):

    logging.info(f"Applying right-shift energy saving strategy to individual...")

    operations = scheduled_env.operations
    machines = scheduled_env.machines

    # --------- Step 1: 建立后继关系 ---------
    job_succ = {}
    machine_succ = {}
    for job in scheduled_env.jobs:
        for i in range(len(job.operations) - 1):
            job_succ[job.operations[i].operation_id] = job.operations[i + 1]

    for machine in machines:
        for i in range(len(machine.scheduled_operations) - 1):
            machine_succ[machine.scheduled_operations[i].operation_id] = machine.scheduled_operations[i + 1]

    # --------- Step 2: 初始化新开始时间 (修复版) ---------
    # 【关键修复】: 必须包含所有机器上已调度的工序，包括虚拟维护工序
    new_start_times = {}

    # 1. 从原始工序列表加载
    for op in operations:
        if 'start_time' in op.scheduling_information:
            new_start_times[op.operation_id] = op.scheduling_information['start_time']

    # 2. 从机器调度列表补充遗漏的工序 (特别是 ID=999999)
    for machine in machines:
        for op in machine.scheduled_operations:
            if op.operation_id not in new_start_times:
                if 'start_time' in op.scheduling_information:
                    new_start_times[op.operation_id] = op.scheduling_information['start_time']

    # --------- Step 3: 逆向遍历，尝试右移 ---------
    # 注意：我们只移动原始工序，虚拟工序位置相对固定
    # 【修复 1】: 获取所有工序，包括 PM
    all_ops_to_shift = list(operations)  # 先拿所有正常工序

    # 把每台机器上的 PM 工序也加进来
    for machine in machines:
        for op in machine.scheduled_operations:
            # 【修正 1】: 必须使用 job_id == -1 来识别 PM，因为 ID 已经是动态的了
            if op.job_id == -1:  # <--- 改这里！不要用 operation_id == 999999
                all_ops_to_shift.append(op)

    # 【修复 2】: 对所有工序进行逆序排序 (基于原结束时间)
    sorted_ops = sorted(all_ops_to_shift, key=lambda op: op.scheduling_information.get('end_time', 0), reverse=True)

    for op in sorted_ops:
        op_id = op.operation_id
        # 防御性检查：如果工序没有被调度，跳过
        if 'processing_time' not in op.scheduling_information:
            continue

        proc_time = op.scheduling_information['processing_time']

        # 获取后继作业工序的开始时间限制
        job_limit_time = op.scheduling_information['end_time']
        if op_id in job_succ:
            succ_op = job_succ[op_id]
            # 确保后继工序已经在 new_start_times 中 (它应该在，因为我们是逆序遍历)
            if succ_op.operation_id in new_start_times:
                job_limit_time = new_start_times[succ_op.operation_id]

        # 获取后继机器工序的开始时间限制
        mach_limit_time = op.scheduling_information['end_time']
        if op_id in machine_succ:
            succ_op = machine_succ[op_id]
            if succ_op.operation_id in new_start_times:
                mach_limit_time = new_start_times[succ_op.operation_id]

        # 计算最晚开始时间 (只能推迟，不能提前)
        # 注意：这里的逻辑其实简化了，严格的右移需要考虑空闲块的大小
        # 但只要保证不晚于任何后继的开始时间，就是安全的
        # 【修正 2】: 计算最晚开始时间时，增加 max(0, ...) 保护
        # 防止任何逻辑错误导致工序穿越到负数时间轴
        calculated_start = min(job_limit_time, mach_limit_time) - proc_time
        latest_start = max(0.0, calculated_start)  # <--- 核心保护！

        # 更新字典
        new_start_times[op_id] = latest_start

    # --------- Step 4: 重新计算能耗 ---------
    total_proc_energy = 0.0
    total_idle_energy = 0.0

    for machine in machines:
        m_proc_power = machine.machine_processpower
        m_idle_power = machine.machine_idlepower

        ops = machine.scheduled_operations
        if not ops:
            continue

        # 加工能耗 (包含虚拟工序)
        for op in ops:
            p_time = op.scheduling_information.get('processing_time', 0)
            total_proc_energy += p_time * m_proc_power

        # 空闲能耗
        # 这里需要对所有工序按【新】的开始时间排序
        # 过滤掉没有记录在 new_start_times 里的异常工序
        valid_ops = [o for o in ops if o.operation_id in new_start_times]

        if not valid_ops:
            continue

        sorted_ops = sorted(valid_ops, key=lambda o: new_start_times[o.operation_id])

        # 机器开启到第一个工序开始前的空闲
        idle_before_first = new_start_times[sorted_ops[0].operation_id]
        total_idle_energy += idle_before_first * m_idle_power

        # 工序之间的空闲
        for i in range(len(sorted_ops) - 1):
            curr_op = sorted_ops[i]
            next_op = sorted_ops[i + 1]

            end_curr = new_start_times[curr_op.operation_id] + curr_op.scheduling_information.get('processing_time', 0)
            start_next = new_start_times[next_op.operation_id]

            idle_gap = start_next - end_curr
            if idle_gap > 1e-6:
                total_idle_energy += idle_gap * m_idle_power

    new_total_energy = total_proc_energy + total_idle_energy

    # --------- Step 4.5: 回写新时间到环境 (关键！否则画图无效) ---------
    for op_id, new_start in new_start_times.items():
        # 找到对应的 op 对象。这有点麻烦，因为 op_id 是唯一的，但 op 对象分散在不同地方
        # 最简单的办法是再次遍历

        # 1. 更新 operations 列表里的
        for op in operations:
            if op.operation_id == op_id:
                old_info = op.scheduling_information
                duration = old_info['processing_time']
                # 更新开始时间和结束时间
                op.scheduling_information['start_time'] = new_start
                op.scheduling_information['end_time'] = new_start + duration

                # 如果有 machine 引用，也要更新 machine 里的记录
                # (稍微有点复杂，但通常画图只用 machine._processed_operations)

        # 2. 必须更新 machine._processed_operations 里的数据 (画图是用这个！)
        for machine in machines:
            for op_data in machine._processed_operations:  # 这是一个字典列表
                if op_data['operation'].operation_id == op_id:
                    duration = op_data['processing_time']
                    op_data['start_time'] = new_start
                    op_data['end_time'] = new_start + duration
                    # setup 时间也要平移
                    if 'start_setup' in op_data:
                        setup_len = op_data['setup_time']
                        op_data['start_setup'] = new_start - setup_len
                        op_data['end_setup'] = new_start

    # --------- Step 5: 比较并更新个体适应度 ---------
    original_makespan, original_energy = individual.fitness.values

    # 注意：这里我们只更新 Energy，因为右移策略原则上不改变 Makespan (或者不使其变差)
    # 但实际上由于浮点数精度，Makespan 可能会有微小变化，我们保持原 Makespan 不变以示“纯节能”

    # 只有当能耗确实降低时才更新
    if new_total_energy < original_energy:
        logging.info(f"Energy saving successful! ↓ {original_energy:.2f} → {new_total_energy:.2f}")
        individual.fitness.values = (original_makespan, new_total_energy)
    else:
        logging.info("Energy saving did not improve total energy.")

    return individual

def local_search_energy_saver(individual, critical_path, jobShopEnv, toolbox, makespan_tolerance=1.05):
    """
    【新增的节能邻域】
    专注于降低能耗，同时尽量不严重恶化完工时间。
    - 识别非关键路径上的操作作为移动候选。
    - 尝试将候选操作移动到更节能的机器上。
    """
    logging.debug("Running Energy Saver Neighborhood Search...")

    # 1. 评估当前解，获取基准性能和调度环境
    try:
        current_makespan, current_energy, scheduled_env = toolbox.evaluate_individual_double(individual)
    except (ValueError, TypeError):
        return individual  # 如果无法评估，直接返回

    # 2. 识别出可以移动的非关键路径操作
    all_op_ids = set(range(len(jobShopEnv.operations)))
    critical_path_set = set(critical_path)
    non_critical_ops = list(all_op_ids - critical_path_set)

    if not non_critical_ops:
        logging.debug("No non-critical operations to move for energy saving.")
        return individual

    random.shuffle(non_critical_ops)  # 随机化处理顺序

    # 3. 遍历非关键路径操作，寻找节能机会
    for op_id in non_critical_ops:
        operation = jobShopEnv.operations[op_id]

        # 必须有多个可选机器才能移动
        if len(operation.processing_times) <= 1:
            continue

        current_machine_idx = individual[0][op_id]
        sorted_machines = sorted(operation.processing_times.keys())
        current_machine_id = sorted_machines[current_machine_idx]
        current_machine_power = jobShopEnv.machines[current_machine_id].machine_processpower

        # 寻找一个功率更低的可用机器
        for target_machine_idx, target_machine_id in enumerate(sorted_machines):
            if target_machine_id == current_machine_id:
                continue

            target_machine_power = jobShopEnv.machines[target_machine_id].machine_processpower

            # 只有当目标机器功率更低时，才值得尝试
            if target_machine_power < current_machine_power:
                neighbor = toolbox.clone(individual)
                neighbor[0][op_id] = target_machine_idx  # 移动到新机器

                # 评估移动后的效果
                try:
                    new_makespan, new_energy, _ = toolbox.evaluate_individual_double(neighbor)
                except (ValueError, TypeError):
                    continue

                # 接受条件：能耗降低，并且完工时间在可接受范围内
                if new_energy < current_energy and new_makespan <= current_makespan * makespan_tolerance:
                    logging.debug(
                        f"EnergySaver found a good move for op {op_id}: M{current_machine_id} -> M{target_machine_id}. "
                        f"Energy: {current_energy:.2f} -> {new_energy:.2f}, "
                        f"Makespan: {current_makespan:.2f} -> {new_makespan:.2f}")
                    return neighbor  # 找到一个好的移动就立即返回，这是一种“首次改进”策略

    # 如果遍历完所有机会都没有找到好的移动，返回原个体
    return individual

def create_individual_etma(ind_class, jobShopEnv: JobShop, ms_rule: str):
    num_ops = len(jobShopEnv.operations)
    os_sequence = []
    for job in jobShopEnv.jobs:
        os_sequence.extend([job.job_id] * len(job.operations))
    random.shuffle(os_sequence)

    ms_selection = [-1] * num_ops
    machine_finish_times = {m.machine_id: 0.0 for m in jobShopEnv.machines}
    machine_cumulative_loads = {m.machine_id: 0.0 for m in jobShopEnv.machines}
    job_op_counters = {job.job_id: 0 for job in jobShopEnv.jobs}
    op_finish_times = {}

    for job_id in os_sequence:
        op_idx_in_job = job_op_counters[job_id]
        operation = jobShopEnv.jobs[job_id].operations[op_idx_in_job]
        op_id = operation.operation_id
        candidate_machines = list(operation.processing_times.keys())

        if not candidate_machines:
            logging.error(f"Operation {op_id} for job {job_id} has no available machines. Skipping.")
            continue

        pred_finish_time = 0.0
        if op_idx_in_job > 0:
            pred_op_id = jobShopEnv.jobs[job_id].operations[op_idx_in_job - 1].operation_id
            pred_finish_time = op_finish_times.get(pred_op_id, 0.0)

        chosen_machine_id = -1
        if ms_rule == 'random':
            chosen_machine_id = random.choice(candidate_machines)
        elif ms_rule == 'fastest_processing':
            chosen_machine_id = min(candidate_machines, key=lambda m_id: operation.processing_times[m_id])
        else:
            best_machine_id = -1
            min_metric = float('inf')
            for m_id in candidate_machines:
                machine = jobShopEnv.machines[m_id]
                base_time = operation.processing_times[m_id]
                # 【修正3】将默认老化率设为 0.0，更安全
                actual_time = base_time + getattr(machine, 'deterioration_rate', 0.0) * machine_cumulative_loads[m_id]

                if ms_rule == 'min_completion_time':
                    start_time = max(pred_finish_time, machine_finish_times[m_id])
                    completion_time = start_time + actual_time
                    if completion_time < min_metric:
                        min_metric, best_machine_id = completion_time, m_id
                else:  # min_load
                    load = machine_cumulative_loads[m_id] + actual_time
                    if load < min_metric:
                        min_metric, best_machine_id = load, m_id

            # ======================= 核心修正 =======================
            # 如果启发式规则没有找到任何机器（best_machine_id 仍然是 -1），
            # 就从候选机器中随机选择一个作为后备。
            chosen_machine_id = best_machine_id if best_machine_id != -1 else random.choice(
                candidate_machines)
            # =========================================================

        sorted_machines = sorted(operation.processing_times.keys())
        ms_selection[op_id] = sorted_machines.index(chosen_machine_id)

        final_machine = jobShopEnv.machines[chosen_machine_id]
        base_time = operation.processing_times[chosen_machine_id]
        actual_time = base_time + getattr(final_machine, 'deterioration_rate', 0.0) * machine_cumulative_loads[
            chosen_machine_id]
        start_time = max(pred_finish_time, machine_finish_times[chosen_machine_id])
        finish_time = start_time + actual_time
        machine_finish_times[chosen_machine_id] = finish_time
        machine_cumulative_loads[chosen_machine_id] += actual_time
        op_finish_times[op_id] = finish_time
        job_op_counters[job_id] += 1

        # 在函数末尾 return 之前加上以下调试代码
        if -1 in ms_selection:
            print(f"!!! DEBUG ALERT !!!")
            print(f"Rule '{ms_rule}' produced an individual with -1 in ms_selection.")
            print(f"MS Selection: {ms_selection}")
            # 找到-1的位置
            invalid_op_ids = [i for i, x in enumerate(ms_selection) if x == -1]
            print(f"Invalid operation IDs: {invalid_op_ids}")

    return ind_class([ms_selection, os_sequence])

def initialize_population_etma(toolbox, pop_size, jobShopEnv):

    logging.info("Initializing population using ETMA's hybrid strategy...")
    population = []
    # 从全局 creator 获取个体类，这是 DEAP 的标准做法
    ind_class = creator.Individual

    rule_proportions = {'min_completion_time': 0.1, 'min_load': 0.1,
                        'fastest_processing': 0.1, 'random': 0.7}

    num_individuals_per_rule = {k: round(v * pop_size) for k, v in rule_proportions.items()}
    diff = pop_size - sum(num_individuals_per_rule.values())
    num_individuals_per_rule['random'] += diff

    for rule, num in num_individuals_per_rule.items():
        logging.info(f"Generating {num} individuals with MS rule: '{rule}'")
        for _ in range(num):
            individual = create_individual_etma(ind_class, jobShopEnv, rule)
            population.append(individual)

    return population

def VNS_lite(individual, toolbox, jobShopEnv):

    neighbor = toolbox.clone(individual)
    try:
        _, _, scheduled_env = toolbox.evaluate_individual_double(neighbor)
    except (ValueError, TypeError):
        return individual

    adj = build_disjunctive_graph(neighbor, scheduled_env)
    critical_path = find_critical_path(adj)
    critical_blocks = find_critical_blocks(critical_path, scheduled_env)

    if not critical_path: return individual

    # --- 【核心修改】: 扩展算子池 ---
    available_operators = [
        local_search_operator_1,
        local_search_operator_3,
        local_search_operator_4,
        local_search_operator_5_swap,  # 保留之前的swap变体
        local_search_operator_5  # 新增真正的插入
    ]
    chosen_operator = random.choice(available_operators)

    # 执行算子
    if chosen_operator == local_search_operator_1:
        neighbor = chosen_operator(neighbor, critical_path, jobShopEnv, toolbox)
    elif chosen_operator == local_search_operator_3:
        neighbor = chosen_operator(neighbor, critical_blocks, jobShopEnv)
    elif chosen_operator == local_search_operator_4:
        neighbor = chosen_operator(neighbor, critical_path, jobShopEnv)
    elif chosen_operator == local_search_operator_5_swap:
        neighbor = chosen_operator(neighbor, critical_path, jobShopEnv)
    elif chosen_operator == local_search_operator_5:
        neighbor = chosen_operator(neighbor, jobShopEnv, toolbox)

    if hasattr(neighbor, 'fitness'):
        del neighbor.fitness.values

    return neighbor

def dominates(fit_a, fit_b):
    """
    辅助函数：判断解 A 的适应度值是否支配解 B 的适应度值 (最小化目标)。
    """
    if not hasattr(fit_a, '__iter__') or not hasattr(fit_b, '__iter__') or len(fit_a) != len(fit_b):
        return False
    all_le = all(a <= b for a, b in zip(fit_a, fit_b))
    any_l = any(a < b for a, b in zip(fit_a, fit_b))
    return all_le and any_l

def Structured_MOVNS(individual, toolbox, jobShopEnv, op_weights=None, max_iters=3):

    if op_weights is None:
        op_weights = [0.5, 0.5]

    # 算子池
    operators_makespan = [local_search_operator_5_swap, local_search_operator_4, local_search_operator_3]
    operators_energy = [local_search_operator_1, local_search_energy_saver]

    current_best = toolbox.clone(individual)
    if not hasattr(current_best, 'fitness') or not current_best.fitness.valid:
        fit = toolbox.evaluate_individual_double(current_best, jobShopEnv=jobShopEnv)
        current_best.fitness.values = fit[:2]

    # 用于记录本次算子的表现，反馈给外部 AOS 机制
    improvement_credits = [0.0, 0.0]  # [Makespan信用, Energy信用]

    for i in range(max_iters):
        # --- 1. 自适应目标导向选择 (基于权重) ---
        # 使用轮盘赌选择目标
        if random.random() < op_weights[0]:
            target_idx = 0  # Makespan
            active_operators = operators_makespan
        else:
            target_idx = 1  # Energy
            active_operators = operators_energy

        k = 0
        while k < len(active_operators):
            shaken_solution = toolbox.clone(current_best)
            toolbox.mutate_operation_sequence(shaken_solution[1], indpb=0.05)

            ls_solution = toolbox.clone(shaken_solution)
            op_func = active_operators[k]

            try:
                # 执行局部搜索
                _, _, temp_env = toolbox.evaluate_individual_double(ls_solution)
                temp_adj = build_disjunctive_graph(ls_solution, temp_env)
                temp_cp = find_critical_path(temp_adj)

                if op_func == local_search_operator_3:
                    temp_cb = find_critical_blocks(temp_cp, temp_env)
                    ls_solution = op_func(ls_solution, temp_cb, jobShopEnv)
                elif op_func in [local_search_operator_1, local_search_energy_saver]:
                    ls_solution = op_func(ls_solution, temp_cp, jobShopEnv, toolbox)
                else:
                    ls_solution = op_func(ls_solution, temp_cp, jobShopEnv)

                fit_new = toolbox.evaluate_individual_double(ls_solution, jobShopEnv=jobShopEnv)
                ls_solution.fitness.values = fit_new[:2]

                # --- 核心：信用分配 (Credit Assignment) ---
                # 方案 A: 产生了支配解 (大奖)
                if dominates(ls_solution.fitness.values, current_best.fitness.values):
                    improvement_credits[target_idx] += 1.0
                    current_best = ls_solution
                    k = 0
                    # 方案 B: 产生了互不支配解 (小奖)
                elif not dominates(current_best.fitness.values, ls_solution.fitness.values):
                    improvement_credits[target_idx] += 0.3
                    if random.random() < 0.3:
                        current_best = ls_solution
                        k = 0
                    else:
                        k += 1
                else:
                    k += 1

            except Exception:
                k += 1
                continue

    # 返回优化后的解，以及本次搜索积累的信用
    return current_best, improvement_credits

def Structured_MOVNS_PM(individual, toolbox, jobShopEnv, op_weights=None, max_iters=3):

    from solutions.genetic_algorithm.operators import pm_shift_operator, pm_threshold_tuning_operator

    if op_weights is None:

        op_weights = [0.5, 0.5]


    operators_makespan = [
        local_search_operator_5_swap,
        local_search_operator_4,
        local_search_operator_3,
        pm_shift_operator
    ]

    operators_energy = [
        local_search_operator_1,
        local_search_energy_saver,
        pm_threshold_tuning_operator
    ]

    current_best = toolbox.clone(individual)
    if not hasattr(current_best, 'fitness') or not current_best.fitness.valid:
        fit = toolbox.evaluate_individual_double(current_best, jobShopEnv=jobShopEnv)
        current_best.fitness.values = fit[:2]

    improvement_credits = [0.0, 0.0]

    for i in range(max_iters):

        if random.random() < op_weights[0]:
            target_idx = 0
            active_operators = operators_makespan
        else:
            target_idx = 1
            active_operators = operators_energy

        k = 0
        while k < len(active_operators):

            shaken_solution = toolbox.clone(current_best)
            toolbox.mutate_operation_sequence(shaken_solution[1], indpb=0.05)

            ls_solution = toolbox.clone(shaken_solution)
            op_func = active_operators[k]

            try:

                _, _, temp_env = toolbox.evaluate_individual_double(ls_solution)
                # 计算关键路径
                temp_adj = build_disjunctive_graph(ls_solution, temp_env)
                temp_cp = find_critical_path(temp_adj)

                # --- 4. 执行选中的算子 ---
                if op_func == local_search_operator_3:
                    temp_cb = find_critical_blocks(temp_cp, temp_env)
                    ls_solution = op_func(ls_solution, temp_cb, jobShopEnv)
                elif op_func in [local_search_operator_1, local_search_energy_saver]:
                    ls_solution = op_func(ls_solution, temp_cp, jobShopEnv, toolbox)
                elif op_func in [pm_shift_operator, pm_threshold_tuning_operator]:

                    ls_solution = op_func(ls_solution, jobShopEnv, toolbox)
                else:

                    ls_solution = op_func(ls_solution, temp_cp, jobShopEnv)

                fit_new = toolbox.evaluate_individual_double(ls_solution, jobShopEnv=jobShopEnv)
                ls_solution.fitness.values = fit_new[:2]

                if dominates(ls_solution.fitness.values, current_best.fitness.values):

                    improvement_credits[target_idx] += 1.0
                    current_best = ls_solution
                    k = 0
                elif not dominates(current_best.fitness.values, ls_solution.fitness.values):

                    improvement_credits[target_idx] += 0.3
                    if random.random() < 0.3:
                        current_best = ls_solution
                        k = 0
                    else:
                        k += 1
                else:
                    k += 1

            except Exception as e:

                k += 1
                continue

    return current_best, improvement_credits

def coevolutionary_search_stage(population, toolbox, jobShopEnv, **kwargs):

    num_subpops = kwargs.get('num_subpopulations', 4)
    coev_gens = kwargs.get('coevolution_generations', 50)
    migration_interval = kwargs.get('migration_interval', 10)
    migration_size = kwargs.get('migration_size', 2)
    cxpb = kwargs.get('cr', 0.8)
    mutpb = kwargs.get('indpb', 0.1)

    logging.info(
        f"\n--- STAGE 2: Starting Co-evolutionary Search with {num_subpops} subpopulations for {coev_gens} generations ---")

    subpop_strategies = [
        local_search_operator_1,
        local_search_operator_3,
        local_search_operator_5_swap,
        local_search_energy_saver
    ]

    strategies = [subpop_strategies[i % len(subpop_strategies)] for i in range(num_subpops)]

    random.shuffle(population)
    subpopulations = [population[i::num_subpops] for i in range(num_subpops)]

    for gen in range(1, coev_gens + 1):
        logging.info(f"  Co-evolution Gen {gen}/{coev_gens}")

        evolved_subpops = []
        for i, subpop in enumerate(subpopulations):
            strategy_func = strategies[i]

            mating_pool = toolbox.select_tournament(subpop, k=len(subpop))
            offspring = [toolbox.clone(ind) for ind in mating_pool]

            for child1, child2 in zip(offspring[::2], offspring[1::2]):
                if random.random() < cxpb:
                    toolbox.mate_POX(child1[1], child2[1])
                    toolbox.mate_Uniform(child1[0], child2[0])
                    del child1.fitness.values, child2.fitness.values

            for mutant in offspring:
                if random.random() < mutpb:
                    toolbox.mutate_operation_sequence(mutant[1], indpb=mutpb)
                    toolbox.mutate_machine_selection(mutant[0], indpb=mutpb)
                    del mutant.fitness.values

            optimized_offspring = []
            for ind in offspring:

                try:
                    _, _, scheduled_env = toolbox.evaluate_individual_double(ind)
                    adj = build_disjunctive_graph(ind, scheduled_env)
                    cp = find_critical_path(adj)
                    cb = find_critical_blocks(cp, scheduled_env)

                    if strategy_func == local_search_operator_1:
                        optimized_ind = strategy_func(ind, cp, jobShopEnv, toolbox)
                    elif strategy_func == local_search_operator_3:
                        optimized_ind = strategy_func(ind, cb, jobShopEnv)
                    elif strategy_func == local_search_operator_5_swap:
                        optimized_ind = strategy_func(ind, cp, jobShopEnv)
                    elif strategy_func == local_search_energy_saver:
                        optimized_ind = strategy_func(ind, cp, jobShopEnv, toolbox)
                    else:  # 默认情况
                        optimized_ind = ind

                    if hasattr(optimized_ind, 'fitness'): del optimized_ind.fitness.values
                    optimized_offspring.append(optimized_ind)
                except Exception:
                    optimized_offspring.append(ind)

            invalid_ind = [ind for ind in optimized_offspring if not ind.fitness.valid]
            if invalid_ind:
                fitnesses = toolbox.map(invalid_ind)
                for ind, fit in zip(invalid_ind, fitnesses):
                    ind.fitness.values = fit

            combined = subpop + [ind for ind in optimized_offspring if ind.fitness.valid]
            next_subpop = tools.selNSGA2(combined, k=len(subpop))
            evolved_subpops.append(next_subpop)

        subpopulations = evolved_subpops

        if gen % migration_interval == 0 and gen < coev_gens:
            logging.info(f"    -> Performing migration at generation {gen}...")

            elites = []

            for subpop in subpopulations:

                elites.append(tools.selBest(subpop, k=migration_size))

            for i in range(num_subpops):
                target_idx = (i + 1) % num_subpops
                migrants = elites[i]

                worst_inds = tools.selWorst(subpopulations[target_idx], k=migration_size)
                for ind in worst_inds:
                    subpopulations[target_idx].remove(ind)

                subpopulations[target_idx].extend(migrants)

    final_population = []
    for subpop in subpopulations:
        final_population.extend(subpop)

    logging.info("--- Co-evolutionary Search Stage Finished ---")
    return final_population