from itertools import combinations
from math import comb
import time
import numpy as np
import random


#关联操作
# association函数：计算每个个体到参考点的距离，确定个体关联的参考点，用于选择时的多样性保持
def association(a, w):
    """
    将每个个体关联到一个最近的参考点。

    Args:
        a (np.array): (N, M) 形状的归一化后的个体目标值数组，N是个体数，M是目标数。
        w (np.array): (H, M) 形状的参考点数组，H是参考点数。

    Returns:
        tuple: (point_assoc, d_min)
            - point_assoc (list): 一个长度为 N 的一维列表。
                                  point_assoc[i] 的值是第 i 个个体所关联的参考点的索引。
            - d_min (list): 一个长度为 N 的一维列表。
                            d_min[i] 的值是第 i 个个体到其关联参考点的距离。
    """
    # 计算每个个体到每个参考点的余弦距离
    # a 的形状 (N, M), w.T 的形状 (M, H) -> cos_dist 形状 (N, H)
    # 每一行代表一个个体，每一列代表一个参考点
    """
    将每个个体关联到一个最近的参考点。
    """
    # 【核心修复】：强制将 a 和 w 转换为至少二维的数组
    # 这样即使只有一个个体，形状也会是 (1, M) 而不是 (M,)
    a = np.atleast_2d(a)
    w = np.atleast_2d(w)

    # 计算范数
    norm_a = np.linalg.norm(a, axis=1, keepdims=True)
    norm_w = np.linalg.norm(w, axis=1, keepdims=True)

    # 避免除以零
    norm_a[norm_a == 0] = 1e-6
    norm_w[norm_w == 0] = 1e-6

    # 计算余弦距离
    # a/norm_a 形状 (N, M), (w/norm_w).T 形状 (M, H) -> cos_dist (N, H)
    cos_dist = 1 - np.dot(a / norm_a, (w / norm_w).T)

    # 对每个个体（每一行），找到距离最小的参考点（列）的索引
    point_assoc = np.argmin(cos_dist, axis=1).tolist()

    # 获取每个个体到其关联参考点的最小距离
    d_min = np.min(cos_dist, axis=1).tolist()

    return point_assoc, d_min

#非支配排序 两个方法 输出的就是多个 Front Layers
def fast_non_dominated_sort(values):
    """
    优化问题一般是求最小值
    :param values: 解集【目标函数1解集，目标函数2解集...】
    :return:返回解的各层分布集合序号。类似[[1], [9], [0, 8], [7, 6], [3, 5], [2, 4]] 其中[1]表示Pareto 最优解对应的序号
    """
    values11 = values[0]  # 函数1解集
    S = [[] for i in range(0, len(values11))]  # 存放 每个个体支配解的集合。
    front = [[]]  # 存放群体的级别集合，一个级别对应一个[]
    n = [0 for i in range(0, len(values11))]  # 每个个体被支配解的个数 。即针对每个解，存放有多少好于这个解的个数
    rank = [np.inf for i in range(0, len(values11))]  # 存放每个个体的级别

    for p in range(0, len(values11)):  # 遍历每一个个体
        # ====得到各个个体 的被支配解个数 和支配解集合====
        S[p] = []  # 该个体支配解的集合 。即存放差于该解的解
        n[p] = 0  # 该个体被支配的解的个数初始化为0  即找到有多少好于该解的 解的个数
        for q in range(0, len(values11)):  # 遍历每一个个体
            less = 0  # 的目标函数值小于p个体的目标函数值数目
            equal = 0  # 的目标函数值等于p个体的目标函数值数目
            greater = 0  # 的目标函数值大于p个体的目标函数值数目
            for k in range(len(values)):  # 遍历每一个目标函数
                if values[k][p] > values[k][q]:  # 目标函数k时，q个体值 小于p个体
                    less = less + 1  # q比p 好
                if values[k][p] == values[k][q]:  # 目标函数k时，p个体值 等于于q个体
                    equal = equal + 1
                if values[k][p] < values[k][q]:  # 目标函数k时，q个体值 大于p个体
                    greater = greater + 1  # q比p 差

            if (less + equal == len(values)) and (equal != len(values)):
                n[p] = n[p] + 1  # q比p,  比p好的个体个数加1

            elif (greater + equal == len(values)) and (equal != len(values)):
                S[p].append(q)  # q比p差，存放比p差的个体解序号

        # =====找出Pareto 最优解，即n[p]===0 的 个体p序号。=====
        if n[p] == 0:
            rank[p] = 0  # 序号为p的个体，等级为0即最优
            if p not in front[0]:
                # 如果p不在第0层中
                # 将其追加到第0层中
                front[0].append(p)  # 存放Pareto 最优解序号
    i = 0
    while (front[i] != []):  # 如果分层集合为不为空
        Q = []
        for p in front[i]:  # 遍历当前分层集合的各个个体p
            for q in S[p]:  # 遍历p 个体 的每个支配解q
                n[q] = n[q] - 1  # 则将fk中所有给对应的个体np-1
                if (n[q] == 0):
                    # 如果nq==0
                    rank[q] = i + 1
                    if q not in Q:
                        Q.append(q)  # 存放front=i+1 的个体序号

        i = i + 1  # front 等级+1
        front.append(Q)

    del front[len(front) - 1]  # 删除循环退出 时 i+1产生的[]

    return front  # 返回各层 的解序号集合 # 类似[[1], [9], [0, 8], [7, 6], [3, 5], [2, 4]]

# divide函数：实现快速非支配排序，将种群分为不同的 Pareto 前沿层
def divide(answer):
    S = [[] for i in range(len(answer))]
    front = [[]]
    n = [0 for i in range(len(answer))]
    rank = [0 for i in range(len(answer))]
    for p in range(len(answer)):
        for q in range(len(answer)):
            # 如果p支配q
            if (np.array(answer[p]) <= np.array(answer[q])).all() and (answer[p] != answer[q]):
                if q not in S[p]:
                    S[p].append(q)  # 同时如果q不属于sp将其添加到sp中
            # 如果q支配p
            elif (np.array(answer[p]) >= np.array(answer[q])).all() and (answer[p] != answer[q]):
                n[p] = n[p] + 1  # 则将np+1
        if n[p] == 0:
            rank[p] = 0
            if p not in front[0]:
                front[0].append(p)
    i = 0
    while (front[i] != []):
        Q = []
        for p in front[i]:
            for q in S[p]:
                n[q] = n[q] - 1  # 则将fk中所有给对应的个体np-1
                if (n[q] == 0):  # 如果nq==0
                    rank[q] = i + 1
                    if q not in Q:
                        Q.append(q)
        i = i + 1
        front.append(Q)
    del front[len(front) - 1]

    return front
#自适应归一化
def point_ideal(answer):
    point = np.array(answer)
    ideal_point = point.min(0)          # 理想点（理想点是每个目标的最好值，Nadir 是最差）
    change = point - ideal_point        # 原点

    # x = [1, 1e-6, 1e-6]                 # 单位向量
    # y = [1e-6, 1, 1e-6]
    # z = [1e-6, 1e-6, 1]
    x = [1, 0]  # 目标1方向的单位向量
    y = [0, 1]  # 目标2方向的单位向量

    # 计算每个目标方向上的极值点
    point_1 = (change / np.array(x)).max(1).tolist()
    point_x = change[point_1.index(min(point_1))]   # x轴极值点

    point_2 = (change / np.array(y)).max(1).tolist()
    point_y = change[point_2.index(min(point_2))]  # y轴极值点

    # point_3 = (change / np.array(z)).max(1).tolist()
    # point_z = change[point_3.index(min(point_3))]  # z轴极值点

    # w = np.array([point_x, point_y, point_z])
    w = np.array([point_x, point_y])  # 由极值点构成的矩阵
    try:
        w_ = np.linalg.inv(w)                           # 逆矩阵
        # intercept = 1 / np.dot(w_, np.array([1, 1, 1]))  # 截距
        intercept = 1 / np.dot(w_, np.array([1, 1]))  # 计算超平面截距
    except:
        intercept = 0
    norm = change / (intercept - ideal_point)       # 将所有点归一化到超平面内
    return norm,ideal_point


def point_ideal1(answer, ideal_point):
    """
    计算理想点并对目标值进行归一化。
    此版本修复了对 NumPy 数组的布尔判断错误，并增强了逻辑健壮性。

    Args:
        answer (list of lists): 种群中个体的目标值列表。
        ideal_point (np.ndarray or int): 当前已知的理想点或初始值(0)。

    Returns:
        tuple: (归一化后的目标值数组, 更新后的理想点数组)
    """
    # 确保 answer 是一个 NumPy 数组
    point = np.array(answer)

    # 如果种群为空，则不进行任何操作，直接返回
    if point.shape[0] == 0:
        return point, np.array(ideal_point)  # 确保返回的是数组

    ### --- 核心修正区域 --- ###
    # 1. 找到当前种群的最小目标值向量
    min_point_in_pop = np.min(point, axis=0)

    # 2. 检查传入的 ideal_point 是否是有效的（非零向量）
    #    np.isscalar() 检查是否为标量 (如整数 0)
    #    np.all() 检查是否为全零向量 (如 [0., 0.])
    if np.isscalar(ideal_point) or not np.all(ideal_point):
        # 如果是初始状态（0 或全零向量），直接用当前种群的最小值初始化
        ideal_point = min_point_in_pop
    else:
        # 如果是有效的理想点，则逐元素比较，取更小的值来更新
        ideal_point = np.minimum(ideal_point, min_point_in_pop)

    # 计算相对于新理想点的平移
    change = point - ideal_point

    # 找到极值点以构建超平面
    # (这部分逻辑在原版中略有不同，这里采用更标准的NSGA-III做法)
    # 寻找在每个轴上具有最小ASF(Achievement Scalarization Function)值的点
    # 为简化，我们直接使用截距法
    try:
        # 寻找每个轴上的最大值，作为构建超平面的点
        # 注意：这里我们是在平移后的空间(change)中操作
        extreme_points = np.zeros((point.shape[1], point.shape[1]))
        for i in range(point.shape[1]):
            # 找到在第 i 轴上值最小的那个解的索引
            idx = np.argmin(change[:, i])
            extreme_points[i] = change[idx]

        # 解线性方程组 A*x = b, 其中 A=extreme_points, b=1向量
        # (如果矩阵是奇异的，此方法会失败)
        b = np.ones(point.shape[1])
        w = np.linalg.solve(extreme_points, b)

        # 计算截距，避免除以零
        intercepts = 1.0 / (w + 1e-9)  # 加一个小量避免除零

    except np.linalg.LinAlgError:
        # 如果矩阵奇异，无法求解，使用一个备用方案：直接用平移后空间的最大值作为截距
        intercepts = np.max(change, axis=0)

    # 归一化目标值
    # 保护分母，防止除以零或负数
    denominator = intercepts
    denominator[denominator < 1e-6] = 1e-6  # 避免极小的或负的分母

    norm = change / denominator

    return norm, ideal_point


#生成参考点
def reference_point(h, m):            # 参考点函数
    begin = [round((1 / h) * i, 1) for i in range(h + m - 1)]
    x1, x2 = [], []
    width = len(begin)
    for i in range(width - 1):
        x1 += [begin[i] for j in range(width - i - 1)]
        x2 += begin[i + 1:]

    a = np.array(x1)
    b = np.array(x2) - 1/h

    s1 = a                            # x坐标
    s2 = b - a                        # y坐标
    # s3 = 1 - b                        # z坐标
    # w = np.array([s1, s2, s3]).T      # 转置
    w = np.array([s1, s2]).T  # 转置
    print(w.size)
    return w

# uniformpoint函数：生成均匀分布的参考点，用于 NSGA-III 风格的选择策略，确保解集的多样性
def uniformpoint(N, M):
    """
    生成均匀分布的参考点。
    【已修复】增加了对 N < M 边缘情况的处理，防止 H1 变为 0 导致除零错误。
    """
    H1 = 1
    # 计算满足组合数不大于 N 的最大 H1
    while comb(H1 + M - 1, M - 1) <= N:
        H1 = H1 + 1
    H1 = H1 - 1

    # --- 【核心修复】 ---
    # 当 N < M 时 (例如 N=1, M=2)，H1 会被计算为 0，导致除零错误。
    # 在这种情况下，我们将其强制设置为 1，生成最基础的参考点（坐标轴向量）。
    # 这是一个安全且合理的后备方案。
    if H1 == 0:
        H1 = 1
    # --- 【修复结束】 ---

    # 生成参考点
    W = np.array(list(combinations(range(H1 + M - 1), M - 1))) - \
        np.tile(np.array(list(range(M - 1))), (int(comb(H1 + M - 1, M - 1)), 1))

    W = (np.hstack((W, H1 + np.zeros((W.shape[0], 1)))) - \
         np.hstack((np.zeros((W.shape[0], 1)), W))) / H1

    if H1 < M:
        H2 = 0
        while comb(H1 + M - 1, M - 1) + comb(H2 + M - 1, M - 1) <= N:
            H2 = H2 + 1
        H2 = H2 - 1
        if H2 > 0:
            W2 = np.array(list(combinations(range(H2 + M - 1), M - 1))) - \
                 np.tile(np.array(list(range(M - 1))), (int(comb(H2 + M - 1, M - 1)), 1))
            W2 = (np.hstack((W2, H2 + np.zeros((W2.shape[0], 1)))) - \
                  np.hstack((np.zeros((W2.shape[0], 1)), W2))) / H2
            W2 = W2 / 2 + 1 / (2 * M)
            W = np.vstack((W, W2))  # 按列合并

    W[W < 1e-6] = 1e-6
    return W

# # 实现了标准的NSGA-III小生境选择（niching）过程。
# def select(num_select, point_assoc_fl, point_assoc_pop, d_min_fl):
#     # num_select: 需要选择的个体数量
#     # point_assoc_fl: FL层（待选层）中每个个体关联的参考点索引列表
#     # point_assoc_pop: 已选入下一代的个体关联的参考点索引列表
#     # d_min_fl: FL层中每个个体到其关联参考点的距离列表
#
#     # 找到所有参考点的索引。即使 point_assoc_pop 为空，也需要从 point_assoc_fl 获取
#     all_ref_indices = set(point_assoc_fl)
#     if point_assoc_pop:  # 只有在不为空时才合并
#         all_ref_indices.update(point_assoc_pop)
#
#     if not all_ref_indices:  # 如果没有任何关联点，无法选择
#         # 这种情况很少见，但作为保护，随机选择
#         return random.sample(range(len(point_assoc_fl)), num_select)
#
#     # 确定参考点的总数，取最大索引+1
#     num_ref_points = max(all_ref_indices) + 1
#
#     # 1. 计算每个参考点的拥挤度 (niche count)
#     # numer_former 记录了已选种群中每个参考点的拥挤度
#     numer_former = [0] * num_ref_points
#     for ra in point_assoc_pop:
#         if ra < num_ref_points:  # 安全检查
#             numer_former[ra] += 1
#
#     sel_ind = []
#     fl_indices = list(range(len(point_assoc_fl)))  # 创建FL层个体的原始索引
#
#     while len(sel_ind) < num_select:
#         # 找出当前拥挤度最小的参考点
#         min_numer = min(numer_former)
#
#         # 找到所有拥挤度最小的参考点对应的索引
#         min_numer_rps = [i for i, count in enumerate(numer_former) if count == min_numer]
#
#         # 从这些参考点中随机选一个
#         k = random.choice(min_numer_rps)
#
#         # 找到FL层中所有关联到这个最不拥挤参考点k的个体
#         get_ind = [i for i in fl_indices if point_assoc_fl[i] == k]
#
#         if get_ind:  # 如果找到了关联到该参考点的个体
#             # 如果这个参考点之前的拥挤度为0，说明它是第一次被选中
#             if numer_former[k] == 0:
#                 # 在所有关联到该点的个体中，选择离参考点最近的那个
#                 min_dist_idx = -1
#                 min_dist = float('inf')
#                 for i in get_ind:
#                     if d_min_fl[i] < min_dist:
#                         min_dist = d_min_fl[i]
#                         min_dist_idx = i
#
#                 sel_ind.append(min_dist_idx)
#                 fl_indices.remove(min_dist_idx)
#             else:
#                 # 如果这个参考点已经被选过，就从关联到它的个体中随机选一个
#                 rand_choice_idx = random.choice(get_ind)
#                 sel_ind.append(rand_choice_idx)
#                 fl_indices.remove(rand_choice_idx)
#
#             # 更新该参考点的拥挤度
#             numer_former[k] += 1
#         else:
#             # 如果在FL层中找不到任何关联到这个最不拥挤参考点的个体
#             # (这可能发生在所有关联到该点的个体都已被选走的情况下)
#             # 为了避免死循环，我们将这个参考点的拥挤度设为无穷大，下次不再选择它
#             numer_former[k] = float('inf')
#
#             # 如果所有参考点都变成inf，说明FL层已经选空，但仍未满足num_select
#             if all(n == float('inf') for n in numer_former):
#                 # 从剩下未选的个体中随机补足
#                 remaining_needed = num_select - len(sel_ind)
#                 if remaining_needed > 0 and fl_indices:
#                     sel_ind.extend(random.sample(fl_indices, min(remaining_needed, len(fl_indices))))
#                 break  # 跳出循环
#
#     return sel_ind

#工序的POX交叉

def select(num_select, point_assoc_fl, point_assoc_pop, d_min_fl):
    """
    【最终健壮版】在最后一个前沿中选择个体。
    能处理一维和二维的 point_assoc_fl 输入。
    """
    sel_ind = []
    if not point_assoc_fl:  # 如果最后一个前沿为空，直接返回
        return sel_ind

    fl_indices = list(range(len(point_assoc_fl)))

    # --- 【核心修正】: 检查 point_assoc_fl 的格式 ---
    is_2d_list = hasattr(point_assoc_fl[0], '__len__')  # 检查第一个元素是否有长度

    # 确定参考点的数量
    if is_2d_list:
        num_ref_points = len(point_assoc_fl[0])
    else:
        # 如果是一维列表，参考点数量需要从 uniformPoint 推断，
        # 但这里没有 uniformPoint，一个安全的做法是找到最大的参考点索引+1
        max_ref_point_index = max(point_assoc_fl)
        num_ref_points = max_ref_point_index + 1
    # --- 结束修正 ---

    for _ in range(num_select):
        if not fl_indices:
            break

        min_num = float('inf')
        min_point_index = -1

        for i in range(num_ref_points):  # 使用修正后的参考点数量
            # 计算已选种群中与该参考点关联的个体数
            num_in_pop = point_assoc_pop.count(i)

            # 【核心修正】: 根据输入格式，用不同方式统计FL中的关联个体
            if is_2d_list:
                num_in_fl = [idx for idx, p in enumerate(point_assoc_fl) if p[0] == i and idx in fl_indices]
            else:  # 一维列表
                num_in_fl = [idx for idx, p in enumerate(point_assoc_fl) if p == i and idx in fl_indices]

            if len(num_in_fl) > 0:
                total_num = num_in_pop + len(num_in_fl)
                if total_num < min_num:
                    min_num = total_num
                    min_point_index = i

        if min_point_index == -1:  # 如果所有参考点都没有待选个体关联
            if fl_indices:
                fallback_pick = random.choice(fl_indices)
                fl_indices.remove(fallback_pick)
                sel_ind.append(fallback_pick)
            continue

        # 从该参考点关联的待选个体中选择一个
        if is_2d_list:
            sel_point_indices = [idx for idx, p in enumerate(point_assoc_fl) if
                                 p[0] == min_point_index and idx in fl_indices]
        else:  # 一维列表
            sel_point_indices = [idx for idx, p in enumerate(point_assoc_fl) if
                                 p == min_point_index and idx in fl_indices]

        min_dist_idx = -1
        if sel_point_indices:
            if min_num == 0:
                min_dist_idx = random.choice(sel_point_indices)
            else:
                min_dist = float('inf')
                for idx in sel_point_indices:
                    if d_min_fl[idx] < min_dist:
                        min_dist, min_dist_idx = d_min_fl[idx], idx

        # 使用我们之前加固的、防止重复移除的逻辑
        if min_dist_idx != -1 and min_dist_idx in fl_indices:
            fl_indices.remove(min_dist_idx)
            sel_ind.append(min_dist_idx)
        else:
            if fl_indices:
                fallback_pick = random.choice(fl_indices)
                fl_indices.remove(fallback_pick)
                sel_ind.append(fallback_pick)

    return sel_ind

def job_cross(self, chrom_L1, chrom_L2):  # 工序的pox交叉
    num = list(set(chrom_L1[0]))
    np.random.shuffle(num)
    index = np.random.randint(0, len(num), 1)[0]
    jpb_set1 = num[:index + 1]  # 固定不变的工件
    jpb_set2 = num[index + 1:]  # 按顺序读取的工件
    C1, C2 = np.zeros((1, chrom_L1.shape[1])) - 1, np.zeros((1, chrom_L1.shape[1])) - 1
    sig, svg = [], []
    for i in range(chrom_L1.shape[1]):  # 固定位置的工序不变
        ii, iii = 0, 0
        for j in range(len(jpb_set1)):
            if (chrom_L1[0, i] == jpb_set1[j]):
                C1[0, i] = chrom_L1[0, i]
            else:
                ii += 1
            if (chrom_L2[0, i] == jpb_set1[j]):
                C2[0, i] = chrom_L2[0, i]
            else:
                iii += 1
        if (ii == len(jpb_set1)):
            sig.append(chrom_L1[0, i])
        if (iii == len(jpb_set1)):
            svg.append(chrom_L2[0, i])
    signal1, signal2 = 0, 0  # 为-1的地方按顺序添加工序编码
    for i in range(chrom_L1.shape[1]):
        if (C1[0, i] == -1):
            C1[0, i] = svg[signal1]
            signal1 += 1
        if (C2[0, i] == -1):
            C2[0, i] = sig[signal2]
            signal2 += 1
    return C1, C2

#机器的均匀交叉
def ma_cross(self, m1, t1, m2, t2):  # 机器均匀交叉
    MC1, MC2, TC1, TC2 = [], [], [], []
    for i in range(m1.shape[0]):
        index = np.random.randint(0, 2, 1)[0]
        if (index == 0):  # 为0时继承继承父代的机器选择
            MC1.append(m1[i]), MC2.append(m2[i]), TC1.append(t1[i]), TC2.append(t2[i]);
        else:  # 为1时另一个父代的加工机器选择
            MC2.append(m1[i]), MC1.append(m2[i]), TC2.append(t1[i]), TC1.append(t2[i]);
    return MC1, TC1, MC2, TC2

#工序变异
def var(job):
    mul = random.sample(range(job.shape[0]), 2)  # 变异的位置
    job[mul[0]], job[mul[1]] = job[mul[1]], job[mul[0]]
    return job

# 选择策略 select_FL 功能：从合并种群中选择个体，分为两阶段：
# 1.FL 层前选择：优先保留低前沿层（非支配性强）的个体。
# 2.FL 层选择：对剩余名额，从 FL 层（当前前沿层）中基于参考点关联和距离选择个体，确保多样性。
#非支配层 FL / Front Layer

# def select_FL(n, fronts,population):
#     count = n
#     count1 = 0
#     num_select=0
#
#     w1, w2 = [], []
#     while count > 0:
#         if len(fronts[count1]) <= count:  # Fl层以前个体
#             w1 += fronts[count1]
#             count -= len(fronts[count1])
#             count1 += 1
#         else:  # Fl层个体
#             w2 += fronts[count1]
#             num_select=count
#             count = 0
#     selected_individuals = [population[idx] for idx in w1 ]
#     FL_individuals = [population[idx] for idx in w2]
#
#     return selected_individuals, FL_individuals,num_select


# 找到 solutions/NSGA3/nsga3.py 中的 select_FL 函数，修改如下：
def select_FL(n, fronts, population):
    count = n
    count1 = 0
    num_select = 0

    w1, w2 = [], []
    while count > 0:
        # --- 【关键修复】: 添加越界检查 ---
        if count1 >= len(fronts):
            break
            # -------------------------------

        if len(fronts[count1]) <= count:  # FL层以前个体
            w1 += fronts[count1]
            count -= len(fronts[count1])
            count1 += 1
        else:  # FL层个体
            w2 += fronts[count1]
            num_select = count
            count = 0

    selected_individuals = [population[idx] for idx in w1]
    FL_individuals = [population[idx] for idx in w2]

    return selected_individuals, FL_individuals, num_select

if __name__ == "__main__":
    w,n=uniformpoint(10,2)#按种群数平方取H
    print(w)


