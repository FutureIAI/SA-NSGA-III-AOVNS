# =================================================================
# 文件: solutions/metrics.py
# 描述: 用于计算多目标优化算法性能指标 (GD, IGD, HV) 的函数。
# =================================================================

import numpy as np
from deap import tools
from scipy.spatial.distance import cdist


def calculate_gd(front, reference_front):
    """
    计算 Generational Distance (GD)。
    衡量收敛性：找到的解集离参考前沿有多近。值越小越好。
    :param front: 当前算法找到的帕累to前沿 (numpy array of shape [n_solutions, n_objectives])
    :param reference_front: 参考帕累托前沿 (真实或近似的PF)
    :return: GD 值
    """
    if front is None or front.shape[0] == 0:
        return np.inf
    distances = cdist(front, reference_front)
    min_distances = np.min(distances, axis=1)
    return np.sqrt(np.sum(min_distances ** 2)) / front.shape[0]


def calculate_igd(front, reference_front):
    """
    计算 Inverted Generational Distance (IGD)。
    衡量收敛性和多样性：参考前沿的每个点离找到的解集有多远。值越小越好。
    :param front: 当前算法找到的帕累to前沿 (numpy array of shape [n_solutions, n_objectives])
    :param reference_front: 参考帕累托前沿 (真实或近似的PF)
    :return: IGD 值
    """
    if front is None or front.shape[0] == 0:
        return np.inf
    distances = cdist(reference_front, front)
    min_distances = np.min(distances, axis=1)
    return np.sqrt(np.sum(min_distances ** 2)) / reference_front.shape[0]


def calculate_hv(front, reference_point):
    """
    计算 Hypervolume (HV)。
    衡量收敛性和多样性：解集与参考点围成的空间体积。值越大越好。
    :param front: 当前算法找到的帕累to前沿 (numpy array of shape [n_solutions, n_objectives])
    :param reference_point: 参考点 (必须被所有解支配)
    :return: HV 值
    """
    if front is None or front.shape[0] == 0:
        return 0.0
    # DEAP的hypervolume函数需要一个fitness值的列表
    fitness_values = [list(p) for p in front]
    return tools.hypervolume(fitness_values, ref=reference_point)


def create_reference_front(all_final_fronts):
    """
    从所有算法、所有运行的最终帕累托前沿中，构建一个统一的参考前沿 (P*)。
    这个参考前沿是所有找到的非支配解的集合。
    :param all_final_fronts: 一个包含所有最终帕reto前沿解的列表。
    :return: 一个 numpy array, 代表参考前沿。
    """
    if not all_final_fronts:
        return np.array([[]])

    # 使用DEAP的ParetoFront工具来筛选出所有非支配解
    combined_front = tools.ParetoFront()
    combined_front.update(all_final_fronts)

    # 转换为numpy array并排序，便于查看
    ref_front_points = np.array([ind.fitness.values for ind in combined_front])
    ref_front_points = ref_front_points[np.argsort(ref_front_points[:, 0])]

    return ref_front_points