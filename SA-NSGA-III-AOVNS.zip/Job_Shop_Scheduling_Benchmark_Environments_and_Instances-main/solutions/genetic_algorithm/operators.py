# =================================================================
# solutions/genetic_algorithm/operators.py (最终增强版)
# =================================================================

import time
import random
import copy
import math
import numpy as np
import logging

from scheduling_environment.jobShop import JobShop
from scheduling_environment.operation import Operation
from solutions.heuristics_scheduler.heuristics import global_selection_scheduler, local_selection_scheduler, \
    random_scheduler
from solutions.helper_functions import update_operations_available_for_scheduling
# 导入新的混合代理
from .q_learning_hybrid_agent import QLearningHybridAgent
from solutions.ETMA.etma_operators import VNS_lite, Structured_MOVNS, Structured_MOVNS_PM


# --- 基础辅助函数 (无变化) ---
def select_next_operation_from_job(jobShopEnv: JobShop, job_id) -> Operation:
    for operation in jobShopEnv.operations_available_for_scheduling:
        if operation.job_id == job_id:
            return operation


# --- 遗传算子 (无变化) ---
def pox_crossover(ind1, ind2, nr_preserving_jobs):
    unique_jobs = list(set(ind1))
    if len(unique_jobs) < nr_preserving_jobs:
        nr_preserving_jobs = len(unique_jobs)
    preserving_jobs = random.sample(unique_jobs, nr_preserving_jobs)
    new_sequence_ind1 = list(filter(lambda a: a not in preserving_jobs, ind2))
    for i in range(len(ind1)):
        if ind1[i] in preserving_jobs:
            new_sequence_ind1.insert(i, ind1[i])
    new_sequence_ind2 = list(filter(lambda a: a not in preserving_jobs, ind1))
    for i in range(len(ind2)):
        if ind2[i] in preserving_jobs:
            new_sequence_ind2.insert(i, ind2[i])
    return new_sequence_ind1, new_sequence_ind2


def mutate_shortest_proc_time(individual, indpb, jobShopEnv: JobShop):
    for i, _ in enumerate(individual):
        if random.random() < indpb:
            operation = jobShopEnv.operations[i]
            # 【修复】确保操作有可选机器，避免在没有可选机器的操作上出错
            if operation.processing_times:
                # 使用 np.argmin 在字典的值上找到最小值的索引，但这不直接适用
                # 正确做法是找到值最小的键，再找到这个键在排序后键列表中的索引
                min_time = float('inf')
                best_machine_id = -1
                for machine_id, time in operation.processing_times.items():
                    if time < min_time:
                        min_time = time
                        best_machine_id = machine_id

                if best_machine_id != -1:
                    sorted_machines = sorted(operation.processing_times.keys())
                    individual[i] = sorted_machines.index(best_machine_id)
    return individual


def mutate_sequence_exchange(individual, indpb):
    for i in range(len(individual)):
        if random.random() < indpb:
            j = random.choice([index for index in range(len(individual)) if index != i])
            individual[i], individual[j] = individual[j], individual[i]
    return individual


# --- 新增的 Scramble Mutation 算子 ---
def scramble_mutation(sequence, indpb):
    """
    对序列应用乱序变异 (Scramble Mutation)。
    该变异算子有 `indpb` 的概率被触发。一旦触发，
    它会随机选择序列中的一个子段，并将该子段内的元素随机打乱。
    这是一种比简单交换更具破坏性的变异，有助于跳出局部最优。

    :param sequence: 需要变异的个体序列部分 (e.g., individual[1])
    :param indpb: 触发此变异操作的概率
    :return: 变异后的序列 (以元组形式，符合DEAP规范)
    """
    if random.random() < indpb:
        size = len(sequence)

        # 确保序列长度足够进行有意义的乱序
        if size < 2:
            return sequence,

        # 随机选择一个子段的起点和终点
        # 为了保证子段长度至少为2，我们这样选择
        point1 = random.randint(0, size - 2)
        point2 = random.randint(point1 + 1, size - 1)

        # 如果随机选的两个点相同，则重新选直到不同
        while point2 == point1:
            point2 = random.randint(point1 + 1, size - 1)

        start = min(point1, point2)
        end = max(point1, point2)

        # 提取子序列
        sub_sequence = sequence[start:end + 1]

        # 对子序列进行乱序 (in-place shuffle)
        random.shuffle(sub_sequence)

        # 将乱序后的子序列放回原位置
        sequence[start:end + 1] = sub_sequence

    return sequence,  # DEAP要求返回一个元组

def init_individual(ind_class, params, jobShopEnv):
    """
    混合初始化策略 (Hybrid Initialization)
    创新点：结合随机规则与启发式规则，平衡初始种群的多样性与质量。
    """
    # 【核心修复】: 在使用环境之前，总是先创建一个深拷贝。
    env_copy = copy.deepcopy(jobShopEnv)

    # 【核心修复 2】：强制重置拷贝后的环境状态
    env_copy.reset()


    rand = random.random()

    # --- 修改比例分配 (50% 随机 / 30% GS / 20% LS) ---
    if rand <= 0.5:
        # 50% 概率：随机调度 (Random)
        # 作用：最大化种群多样性，防止算法开局就陷入局部最优
        scheduled_env = random_scheduler(env_copy)
    elif rand <= 0.8:
        # 30% 概率 (0.5~0.8)：全局选择 (Global Selection)
        # 作用：优先选择累积负载最小的机器，保证初始解的负载均衡
        scheduled_env = global_selection_scheduler(env_copy)
    else:
        # 20% 概率 (0.8~1.0)：局部选择 (Local Selection)
        # 作用：优先选择当前工序加工时间最短的机器，优化 Makespan
        scheduled_env = local_selection_scheduler(env_copy)
    # -----------------------------------------------------

    # 从调度完成的【副本】中提取编码 (Encoding)

    # 1. 提取工序序列 (OS)
    operation_sequence = [operation.job_id for operation in scheduled_env.scheduled_operations]

    # 2. 提取机器选择 (MS)
    # 需要按照 (Job, Op) 的原始顺序排序，提取对应的机器索引
    machine_selection_list = []
    for op in scheduled_env.scheduled_operations:
        # 找到这台机器在可选机器列表中的 index (从 0 开始)
        # 注意：这里假设 op.processing_times 是 {machine_id: time, ...} 字典
        available_machines = sorted(list(op.processing_times.keys()))
        if op.scheduled_machine in available_machines:
            m_idx = available_machines.index(op.scheduled_machine)
        else:
            # 防御性代码：万一调度器出错了，随机选一个
            m_idx = random.randint(0, len(available_machines) - 1)

        machine_selection_list.append((op.operation_id, m_idx))

    # 这一步很关键：必须按 operation_id 排序，因为染色体的 MS 部分是按 ID 顺序排列的
    machine_selection_list.sort(key=lambda x: x[0])

    # 只保留机器索引
    machine_selection = [alloc for _, alloc in machine_selection_list]

    # 返回个体
    return ind_class([machine_selection, operation_sequence])

def init_population(toolbox, population_size):
    return [toolbox.init_individual() for _ in range(population_size)]

def evaluate_individual(individual, jobShopEnv: JobShop, reset=True, makespan_weight=1):  # 用于评估个体在作业车间环境中的适应度
    jobShopEnv.reset()
    # 更新作业车间环境中的可调度操作集合
    update_operations_available_for_scheduling(jobShopEnv)
    for i in range(len(individual[0])):
        job_id = individual[1][i]
        # 选择该作业的下一个操作
        operation = select_next_operation_from_job(jobShopEnv, job_id)
        operation_option_index = individual[0][operation.operation_id]
        # 确定操作对应的机器选择和加工时间
        machine_id = sorted(operation.processing_times.keys())[operation_option_index]
        duration = operation.processing_times[machine_id]
        # 安排操作到机器上并再次更新可调度操作集合
        jobShopEnv.schedule_operation_with_backfilling(operation, machine_id, duration)
        update_operations_available_for_scheduling(jobShopEnv)
    # 获取完工时间并根据reset决定是否重置环境
    makespan = jobShopEnv.makespan

    if reset:
        jobShopEnv.reset()
    return makespan,jobShopEnv

# 第三章
# def evaluate_individual_double(individual, jobShopEnv: JobShop, reset=True, **kwargs):
#     """
#     第三章专用评估函数：仅考虑设备退化效应，不包含维护逻辑。
#     """
#     # 1. 重置环境
#     jobShopEnv.reset()
#     update_operations_available_for_scheduling(jobShopEnv)
#
#     if jobShopEnv.operations_available_for_scheduling:
#         jobShopEnv.operations_available_for_scheduling.sort(key=lambda op: (op.job_id, op.operation_id))
#
#     # 2. 遍历个体的编码进行调度
#     for i in range(len(individual[0])):
#         job_id = individual[1][i]
#         operation = select_next_operation_from_job(jobShopEnv, job_id)
#
#         if operation is None: return float('inf'), float('inf'), jobShopEnv
#
#         # 解码机器选择
#         machine_choice_encoded = individual[0][operation.operation_id]
#         sorted_machines = sorted(operation.processing_times.keys())
#         if not sorted_machines: return float('inf'), float('inf'), jobShopEnv
#         machine_id = sorted_machines[machine_choice_encoded % len(sorted_machines)]
#
#         # 3. 正常调度 & 老化计算
#         # 这里的关键是：jobShopEnv.schedule_operation_with_backfilling 内部会调用
#         # Machine 类的 get_actual_processing_time，它会基于累积 WT 自动处理老化。
#         # 我们不需要在这里进行任何 PM 操作。
#
#         # 获取基础加工时长
#         base_duration = operation.processing_times[machine_id]
#
#         # 执行调度 (此时 Machine 内部的 get_actual_processing_time 会自动基于当前 wt 修正时长)
#         jobShopEnv.schedule_operation_with_backfilling(operation, machine_id, base_duration)
#
#         # 4. 更新可用工序
#         update_operations_available_for_scheduling(jobShopEnv)
#         if jobShopEnv.operations_available_for_scheduling:
#             jobShopEnv.operations_available_for_scheduling.sort(key=lambda op: (op.job_id, op.operation_id))
#
#     makespan = jobShopEnv.makespan
#     total_power = jobShopEnv.total_machinepower
#
#     return makespan, total_power, jobShopEnv


def evaluate_individual_double(individual, jobShopEnv, reset=True, **kwargs):
    """
    【OM + CBM 双重隐式维护评估函数】
    """
    # 1. 环境重置与初始化
    pm_counter = 1
    jobShopEnv.reset()
    update_operations_available_for_scheduling(jobShopEnv)

    if jobShopEnv.operations_available_for_scheduling:
        jobShopEnv.operations_available_for_scheduling.sort(key=lambda op: (op.job_id, op.operation_id))

    # --- 参数读取 ---
    BASE_PM_THRESHOLD = kwargs.get('pm_threshold', 260.0)
    OM_RATIO = kwargs.get('om_ratio', 0.8)  # 对应 \omega
    PM_K = kwargs.get('pm_restore_factor_k', 0.1)  # 对应 \kappa_k
    PM_M1 = kwargs.get('pm_time_base_m1', 4.0)  # 对应 M1_k
    PM_M2 = kwargs.get('pm_time_factor_m2', 0.05)  # 对应 M2_k

    # 初始化机器状态 (WT_ijk 初始值)
    machine_cumulative_work = {
        m.machine_id: random.uniform(0, BASE_PM_THRESHOLD * 0.3)
        for m in jobShopEnv.machines
    }

    # 2. 遍历个体的编码进行调度
    for i in range(len(individual[0])):
        job_id = individual[1][i]
        operation = select_next_operation_from_job(jobShopEnv, job_id)

        if operation is None:
            return float('inf'), float('inf'), jobShopEnv

        # 解码机器选择
        machine_choice_encoded = individual[0][operation.operation_id]
        sorted_machines = sorted(operation.processing_times.keys())
        if not sorted_machines:
            return float('inf'), float('inf'), jobShopEnv

        machine_id = sorted_machines[machine_choice_encoded % len(sorted_machines)]

        # 获取机器对象、当前状态 (WT_ijk) 与基准时间 (p_ijk)
        target_machine = jobShopEnv.machines[machine_id]
        base_duration = operation.processing_times[machine_id]
        current_wt = machine_cumulative_work[machine_id]

        # 动态获取当前机器的安全阈值 (T_k^PM)
        threshold_multiplier = individual.machine_threshold_multipliers.get(machine_id, 1.0) if hasattr(individual,
                                                                                                        'machine_threshold_multipliers') else 1.0
        T_PM = BASE_PM_THRESHOLD * threshold_multiplier

        # =========================================================
        # 数学模型对齐区：式 (4-6) ~ (4-11)
        # =========================================================

        # 式(4-6)：计算空闲窗口 Idle_ijk = max(0, E_ij - C_prev)
        E_ij = operation.finishing_time_predecessors if hasattr(operation, 'finishing_time_predecessors') else 0.0
        C_prev = target_machine.current_end_time
        idle_time = max(0, E_ij - C_prev)

        # 式(4-7)：预计维护时长 d_expected = M1 + M2 * WT_ijk
        d_expected = PM_M1 + PM_M2 * max(0, current_wt)

        is_pm_triggered = False  # 标志位：记录是否触发了维护

        # 式(4-8)：机会维护 (OM) 触发判定
        if (current_wt > OM_RATIO * T_PM) and (idle_time >= d_expected):
            pm_type = 'OM'
            is_pm_triggered = True

        # 式(4-9)：强制维护 (CBM) 触发判定 (前提是未触发OM)
        elif current_wt + base_duration > T_PM:
            pm_type = 'CBM'
            is_pm_triggered = True

        # 式(4-10) & 式(4-11)：实际执行维护与状态演化
        if is_pm_triggered:
            unique_pm_id = 900000 + pm_counter
            pm_counter += 1

            # 创建维护任务 (耗时即为 d_expected)
            pm_op = Operation(None, -1, unique_pm_id)
            pm_op.is_opportunity = (pm_type == 'OM')
            pm_op.pm_type = pm_type
            pm_op.add_operation_option(machine_id, d_expected)

            # 插入维护任务 (紧接在机器当前完工时间之后)
            target_machine.append_operation_sequentially(pm_op, d_expected)

            # 役龄回退: WT_ijk 变为 \kappa_k * WT_ijk
            current_wt = current_wt * PM_K
            machine_cumulative_work[machine_id] = current_wt

        # =========================================================
        # 常规工序调度：式 (4-12) ~ (4-13)
        # =========================================================

        # 注意：这里的 schedule_operation_with_backfilling 内部需要实现
        # S_ij = max(E_ij, target_machine.current_end_time) 的逻辑
        jobShopEnv.schedule_operation_with_backfilling(operation, machine_id, base_duration)

        # 状态演化: 加上基准时间 p_ijk (对应式 4-11 结尾的 + p_ijk)
        machine_cumulative_work[machine_id] += base_duration

        # 更新环境可用工序
        update_operations_available_for_scheduling(jobShopEnv)
        if jobShopEnv.operations_available_for_scheduling:
            jobShopEnv.operations_available_for_scheduling.sort(key=lambda op: (op.job_id, op.operation_id))

    # =========================================================
    # 目标函数计算：式 (4-1) ~ (4-5)
    # =========================================================
    makespan = jobShopEnv.makespan

    # 获取总能耗 (假设底层 jobShopEnv.total_machinepower 的计算逻辑中，
    # 已经排除了 job_id == -1 (维护工序) 的空载和加工能耗)
    total_power = jobShopEnv.total_machinepower

    return makespan, total_power, jobShopEnv

def evaluate_population(toolbox, population, logging):  #用于评估种群中个体的适应度
    start_time = time.time()

    # sequential evaluation of population

    # population = [[ind[0], ind[1]] for ind in population]
    # fitnesses = [toolbox.evaluate_individual(ind) for ind in population]
    # fitnesses = [(fit[0],) for fit in fitnesses]

    # parallel evaluation of population并行人口评估
    population = [[ind[0], ind[1]] for ind in population]
    # 并行评估种群个体适应度
    fitnesses = toolbox.map(toolbox.evaluate_individual, population)
    # 处理适应度结果格式 种群个体适应度值列表，每个元素对应种群中一个个体的适应度
    fitnesses = [(fit[0],) for fit in fitnesses]
    logging.info("--- %.4s seconds ---" % (time.time() - start_time))
    return fitnesses

def evaluate_population_double(toolbox, population, logging):
    start_time = time.time()
    population = [[ind[0], ind[1]] for ind in population]
    fitnesses = toolbox.map(toolbox.evaluate_individual_double, population)
    fitnesses = [(fit[0], fit[1]) for fit in fitnesses]
    logging.info("---evaluate_population %.4s seconds ---" % (time.time() - start_time))
    return fitnesses

def decode_with_offsets(individual, jobShopEnv, machine_ready_times=None, task_offsets=None):
    """
    machine_ready_times: 数组，记录每台机器的起始可用时间（故障修复后的时间）
    task_offsets: 字典，记录每个 Job 已经完成到了第几个工序
    """
    num_machines = len(jobShopEnv.machines)

    # 如果是正常调度，就全是0；如果是重调度，就传入故障后的就绪时间
    if machine_ready_times is None:
        machine_available_time = np.zeros(num_machines)
    else:
        machine_available_time = np.array(machine_ready_times)

    # ... 剩下的解码逻辑 (Machine Selection + Operation Sequencing) ...
    # 在计算 StartTime 时：
    # start_time = max(machine_available_time[m], prev_op_end_time)

def get_levy_flight_step(beta=1.5):
    """
    生成一个莱维飞行步长，用于模拟退火中的扰动幅度。
    """
    sigma = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
             (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = np.random.normal(0, sigma)
    v = np.random.normal(0, 1)
    step = u / abs(v) ** (1 / beta)
    return step

def simulated_annealing_double(individual, toolbox, jobShopEnv, max_iter=50, init_temp=100, cooling_rate=0.95):
    current_sol = copy.deepcopy(individual)
    try:
        current_makespan, current_power, _ = toolbox.evaluate_individual_double(current_sol)
        w1, w2 = 0.5, 0.5
        current_score = w1 * current_makespan + w2 * current_power
    except (ValueError, TypeError):
        return individual
    best_sol = copy.deepcopy(current_sol)
    best_score = current_score
    temp = init_temp
    for _ in range(max_iter):
        neighbor_sol = copy.deepcopy(current_sol)
        levy_step = get_levy_flight_step()
        alpha = 0.1
        num_to_change = int(round(abs(alpha * levy_step)))
        num_to_change = np.clip(num_to_change, 1, len(jobShopEnv.operations) // 2)
        changeable_op_indices = [i for i, op in enumerate(jobShopEnv.operations) if len(op.processing_times) > 1]
        if not changeable_op_indices: continue
        if len(changeable_op_indices) < num_to_change:
            op_indices_to_change = changeable_op_indices
        else:
            op_indices_to_change = random.sample(changeable_op_indices, num_to_change)
        for op_idx in op_indices_to_change:
            operation = jobShopEnv.operations[op_idx]
            num_machine_options = len(operation.processing_times)
            current_machine_choice = neighbor_sol[0][op_idx]
            possible_choices = list(range(num_machine_options))
            possible_choices.remove(current_machine_choice)
            if not possible_choices: continue
            new_machine_choice = random.choice(possible_choices)
            neighbor_sol[0][op_idx] = new_machine_choice
        try:
            neighbor_makespan, neighbor_power, _ = toolbox.evaluate_individual_double(neighbor_sol)
            neighbor_score = w1 * neighbor_makespan + w2 * neighbor_power
        except (ValueError, TypeError):
            continue
        delta = neighbor_score - current_score
        if delta < 0 or random.random() < math.exp(-delta / temp):
            current_sol = neighbor_sol
            current_score = neighbor_score
            if current_score < best_score:
                best_sol = copy.deepcopy(current_sol)
                best_score = current_score
        temp *= cooling_rate
        if temp < 1e-3:
            break
    return best_sol

def insertion_search(individual, toolbox):
    """工序排序的局部搜索算子：插入搜索。"""
    current_sol = toolbox.clone(individual)
    if not current_sol.fitness.valid:
        try:
            makespan, power, _ = toolbox.evaluate_individual_double(current_sol)
            current_sol.fitness.values = (makespan, power)
        except (ValueError, TypeError):
            return individual
    best_sol = toolbox.clone(current_sol)
    source_idx = random.randint(0, len(current_sol[1]) - 1)
    item_to_move = current_sol[1][source_idx]
    temp_sequence = list(current_sol[1])
    temp_sequence.pop(source_idx)
    for target_idx in range(len(current_sol[1])):
        neighbor_sol = toolbox.clone(current_sol)
        new_sequence = list(temp_sequence)
        new_sequence.insert(target_idx, item_to_move)
        neighbor_sol[1] = new_sequence
        try:
            neighbor_makespan, neighbor_power, _ = toolbox.evaluate_individual_double(neighbor_sol)
            neighbor_sol.fitness.values = (neighbor_makespan, neighbor_power)
        except (ValueError, TypeError):
            continue
        if neighbor_sol.fitness.dominates(best_sol.fitness):
            best_sol = toolbox.clone(neighbor_sol)
    return best_sol

def inversion_search(individual, toolbox):
    """工序排序的局部搜索算子：逆序搜索。"""
    current_sol = toolbox.clone(individual)
    if not current_sol.fitness.valid:
        try:
            makespan, power, _ = toolbox.evaluate_individual_double(current_sol)
            current_sol.fitness.values = (makespan, power)
        except (ValueError, TypeError):
            return current_sol
    neighbor_sol = toolbox.clone(current_sol)
    i, j = sorted(random.sample(range(len(neighbor_sol[1])), 2))
    sub_sequence = neighbor_sol[1][i:j + 1]
    sub_sequence.reverse()
    neighbor_sol[1][i:j + 1] = sub_sequence
    try:
        neighbor_makespan, neighbor_power, _ = toolbox.evaluate_individual_double(neighbor_sol)
        neighbor_sol.fitness.values = (neighbor_makespan, neighbor_power)
    except (ValueError, TypeError):
        return current_sol
    if neighbor_sol.fitness.dominates(current_sol.fitness):
        return neighbor_sol
    else:
        return current_sol

def pm_shift_operator(individual, toolbox, jobShopEnv):

    # 1. 评估以定位 PM
    try:
        _, _, scheduled_env = toolbox.evaluate_individual_double(individual, jobShopEnv=jobShopEnv)
    except Exception:
        return individual

    # 2. 找到所有触发了强制维护的机器和对应的上下文
    target_machine_events = []

    for machine in scheduled_env.machines:
        ops = machine.scheduled_operations
        for i, op in enumerate(ops):
            if op.operation_id >= 900000:  # 发现 PM
                # 找到 PM 前面那个工序 (Trigger Op) 和后面那个工序
                # 注意：这里 op 是 PM，op[i-1] 是触发者，op[i+1] 是维护后第一个
                if i > 0 and ops[i - 1].job_id != -1:
                    target_machine_events.append(ops[i - 1].job_id)

    if not target_machine_events:
        return individual

    # 3. 在 OS 序列中操作
    new_individual = toolbox.clone(individual)
    os_seq = new_individual[1]

    # 随机选一个触发了 PM 的 Job
    target_job_id = random.choice(target_machine_events)

    # 找到这个 Job 在 OS 序列中的所有位置
    indices = [i for i, x in enumerate(os_seq) if x == target_job_id]
    if not indices: return individual

    # 随机选一个位置进行交换
    idx = random.choice(indices)

    # 尝试与左边或右边交换 (前提是不越界)
    swap_candidates = []
    if idx > 0: swap_candidates.append(idx - 1)
    if idx < len(os_seq) - 1: swap_candidates.append(idx + 1)

    if swap_candidates:
        swap_idx = random.choice(swap_candidates)
        # 执行交换
        os_seq[idx], os_seq[swap_idx] = os_seq[swap_idx], os_seq[idx]

    if hasattr(new_individual, 'fitness'):
        del new_individual.fitness.values
    return new_individual

def pm_threshold_tuning_operator(individual, toolbox, jobShopEnv):

    # 必须先 clone，否则会修改原个体
    new_individual = toolbox.clone(individual)

    # 确保属性存在
    if not hasattr(new_individual, 'machine_threshold_multipliers'):
        new_individual.machine_threshold_multipliers = {m.machine_id: 1.0 for m in jobShopEnv.machines}

    # 随机选一台机器
    target_machine_id = random.choice(list(new_individual.machine_threshold_multipliers.keys()))

    # 获取当前系数
    current_mult = new_individual.machine_threshold_multipliers[target_machine_id]

    # 变异：乘以 0.9 ~ 1.1 的因子
    mutation_factor = random.uniform(0.9, 1.1)
    new_mult = current_mult * mutation_factor

    # 限制范围 (0.5 ~ 1.5 倍基础阈值)
    new_mult = max(0.5, min(1.5, new_mult))

    new_individual.machine_threshold_multipliers[target_machine_id] = new_mult

    if hasattr(new_individual, 'fitness'):
        del new_individual.fitness.values

    return new_individual

def pm_avoidance_search(individual, toolbox, jobShopEnv):

    # 1. 获取当前的详细调度结果
    # 注意：reset=True 保证不污染外部环境，但我们需要返回 env 查看状态
    original_fitness = individual.fitness.values if individual.fitness.valid else None

    # 这里的 evaluate 需要返回 env。假设你的 evaluate_individual_double 返回 (mk, pw, env)
    try:
        _, _, scheduled_env = toolbox.evaluate_individual_double(individual, jobShopEnv=jobShopEnv)
    except Exception:
        return individual

    # 2. 识别“受害者” (Victims)
    # 受害者定义：在某台机器上，直接排在 PM 操作之后的普通工序
    victim_ops_info = []  # 存元组 (op_object, current_machine_id)

    for machine in scheduled_env.machines:
        # 检查该机器的时间线上是否有 PM 操作 (假设 PM 的 job_id 为 -1 或 ID > 900000)
        scheduled_ops = machine.scheduled_operations
        for i in range(len(scheduled_ops) - 1):
            current_op = scheduled_ops[i]
            next_op = scheduled_ops[i + 1]

            # 判定条件：当前是 PM，下一个是普通工序
            is_pm = (current_op.job_id == -1) or (current_op.operation_id >= 900000)
            if is_pm and next_op.job_id != -1:
                victim_ops_info.append((next_op, machine.machine_id))

    if not victim_ops_info:
        return individual  # 没有受害者，无需优化

    # 3. 针对受害者进行变异
    new_individual = toolbox.clone(individual)
    has_changed = False

    # 限制尝试次数，避免修改过多破坏结构
    attempts = min(len(victim_ops_info), 3)
    targets = random.sample(victim_ops_info, attempts)

    for target_op, current_m_id in targets:
        op_id = target_op.operation_id

        # 获取该工序的所有可选机器
        # 注意：需通过原始环境获取 processing_times，因为 target_op 可能是克隆对象
        original_op = jobShopEnv.operations[op_id]
        available_machines = sorted(list(original_op.processing_times.keys()))

        if len(available_machines) <= 1:
            continue

        # 策略：选择一个除了当前机器外，加工时间最短 或 随机 的机器
        # 这里使用随机选择以保持探索性，也可以改为贪婪选择
        candidates = [m for m in available_machines if m != current_m_id]
        if not candidates:
            continue

        new_machine_id = random.choice(candidates)

        # 将机器 ID 转换回 machine_selection 编码的索引
        # 编码逻辑是：individual[0][op_id] = index in sorted_machines
        new_m_idx = available_machines.index(new_machine_id)

        new_individual[0][op_id] = new_m_idx
        has_changed = True

    # 4. 评估与返回
    if has_changed:
        if hasattr(new_individual, 'fitness'):
            del new_individual.fitness.values
        return new_individual

    return individual

# 辅助函数，用于应用特定的算子组合
def apply_operator(action_name, parent1, parent2, toolbox, jobShopEnv, indpb):
    """根据动作名称应用特定的算子组合。"""
    offspring = toolbox.clone(parent1)

    if action_name == "Crossover_Mutation":
        # 动作1：交叉和变异（探索）
        child1_seq, _ = toolbox.mate_POX(parent1[1], parent2[1])
        offspring[1] = child1_seq
        offspring[0], _ = toolbox.mate_Uniform(parent1[0], parent2[0])
        offspring[0] = toolbox.mutate_machine_selection(offspring[0], indpb)
        offspring[1] = toolbox.mutate_operation_sequence(offspring[1], indpb)

    elif action_name == "SA_Search":
        # 动作2：模拟退火（机器选择的利用）
        offspring = simulated_annealing_double(offspring, toolbox, jobShopEnv)

    elif action_name == "Insertion_Search":
        # 动作3：插入搜索（工序排序的利用）
        offspring = insertion_search(offspring, toolbox)

    elif action_name == "Inversion_Search":
        # 动作4：逆序搜索（工序排序的另一种利用）
        offspring = inversion_search(offspring, toolbox)

    # ================= [新增] =================
    elif action_name == "PM_Search":
        # 调用上面定义的新函数
        offspring = pm_avoidance_search(offspring, toolbox, jobShopEnv)
    # ==========================================

    else:  # 默认/备用动作
        offspring[0] = toolbox.mutate_machine_selection(offspring[0], indpb)
        offspring[1] = toolbox.mutate_operation_sequence(offspring[1], indpb)

    # 必须删除适应度，以便后续可以重新评估或正确处理
    if hasattr(offspring, 'fitness'):
        del offspring.fitness.values
    return offspring

def dominates(fit_a, fit_b):
    """判断解 A 的适应度值是否支配解 B 的适应度值 (最小化目标)。"""
    # 检查 fit_a 和 fit_b 是否是有效的元组或列表
    if not hasattr(fit_a, '__iter__') or not hasattr(fit_b, '__iter__'):
        return False
    # 确保维度相同
    if len(fit_a) != len(fit_b):
        return False

    all_le = all(a <= b for a, b in zip(fit_a, fit_b))
    any_l = any(a < b for a, b in zip(fit_a, fit_b))
    return all_le and any_l

def variation_adaptive(mating_pool, toolbox, cxpb, mutpb, jobShopEnv):

    offspring = []
    ref_pool = [toolbox.clone(ind) for ind in mating_pool]

    for ind in mating_pool:
        child = toolbox.clone(ind)
        is_modified = False

        # 1. 交叉
        if random.random() < cxpb:
            partner = random.choice(ref_pool)
            toolbox.mate_POX(child[1], partner[1])
            toolbox.mate_Uniform(child[0], partner[0])
            is_modified = True

        # 2. 变异
        if random.random() < mutpb:
            toolbox.mutate_operation_sequence(child[1], indpb=0.1)
            toolbox.mutate_machine_selection(child[0], indpb=0.1)
            is_modified = True

        # 3. 局部搜索 (修复报错位置)
        if random.random() < 0.1:  # 固定的触发概率
            try:
                # 【修改点】：直接调用，不传 sa_prob 关键字参数
                child = simulated_annealing_double(child, toolbox, jobShopEnv)
                is_modified = True
            except Exception as e:
                logging.debug(f"Simulated Annealing skip: {e}")

        # 如果被修改，标记 fitness 无效
        if is_modified and hasattr(child, 'fitness'):
            del child.fitness.values

        offspring.append(child)

    return offspring

def variation(population, toolbox, lambda_, cr, indpb, jobShopEnv=None):

    offspring = []

    mutpb_individual = 0.1

    for _ in range(int(lambda_)):
        # --- 1. 标准交叉 (Crossover) ---
        if random.random() < cr:
            # 随机选择两个父代
            ind1, ind2 = list(map(toolbox.clone, random.sample(population, 2)))

            # 机器位交叉：移除 Uniform 交叉（Uniform 破坏力强，容易跳出局部最优）
            # 退化为仅使用最基础的 TwoPoint 两点交叉
            ind1[0], ind2[0] = toolbox.mate_TwoPoint(ind1[0], ind2[0])

            # 工序位交叉 (POX 是 JSSP 的标准交叉算子)
            ind1[1], ind2[1] = toolbox.mate_POX(ind1[1], ind2[1])

            # 交叉后适应度失效
            if hasattr(ind1, 'fitness'): del ind1.fitness.values
        else:
            # 不交叉则直接克隆
            ind1 = toolbox.clone(random.choice(population))

        # --- 2. 标准变异 (Mutation) ---
        # 【核心削弱点】：不再是 100% 变异，而是按 20% 的概率触发
        if random.random() < mutpb_individual:
            # 机器选择变异
            toolbox.mutate_machine_selection(ind1[0], indpb, jobShopEnv=jobShopEnv)
            # 工序排序变异
            toolbox.mutate_operation_sequence(ind1[1], indpb)

            # 变异后适应度失效
            if hasattr(ind1, 'fitness'):
                del ind1.fitness.values

        offspring.append(ind1)

    return offspring

# --- 约束修复 (无变化) ---
def repair_precedence_constraints(env, offspring):
    precedence_relations = env.precedence_relations_jobs
    if not precedence_relations:
        return offspring
    for ind in offspring:
        lst = ind[1]
        while True:
            repaired_in_this_pass = False
            i = 0
            while i < len(lst):
                current_job_id = lst[i]
                if current_job_id in precedence_relations:
                    predecessors = precedence_relations[current_job_id]
                    max_pred_idx = -1
                    for pred_job in predecessors:
                        try:
                            pred_idx = len(lst) - 1 - lst[::-1].index(pred_job)
                            if pred_idx > max_pred_idx:
                                max_pred_idx = pred_idx
                        except ValueError:
                            continue
                    if max_pred_idx != -1 and i < max_pred_idx:
                        item_to_move = lst.pop(i)
                        lst.insert(max_pred_idx, item_to_move)
                        repaired_in_this_pass = True
                        break
                i += 1
            if not repaired_in_this_pass:
                break
    return offspring