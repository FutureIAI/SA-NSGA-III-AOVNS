import copy
import random
import logging
import os
import networkx as nx
from statistics import mean
from scheduling_environment.jobShop import JobShop
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.ticker import MultipleLocator, FormatStrFormatter



def create_colormap():
    colors = [
        '#1f77b4', '#aec7e8', '#ff7f0e', '#ffbb78', '#2ca02c',
        '#98df8a', '#d62728', '#ff9896', '#9467bd', '#c5b0d5',
        '#8c564b', '#c49c94', '#e377c2', '#f7b6d2', '#7f7f7f',
        '#c7c7c7', '#bcbd22', '#dbdb8d', '#17becf', '#9edae5',
        '#393b79', '#637939', '#8c6d31', '#843c39', '#5254a3',
        '#6b4c9a', '#8ca252', '#bd9e39', '#ad494a', '#636363',
        '#8c6d8c', '#9c9ede', '#cedb9c', '#e7ba52', '#e7cb94',
        '#843c39', '#ad494a', '#d6616b', '#e7969c', '#7b4173',
        '#a55194', '#ce6dbd', '#de9ed6', '#f1b6da', '#fde0ef',
        '#636363', '#969696', '#bdbdbd', '#d9d9d9', '#f0f0f0',
        '#3182bd', '#6baed6', '#9ecae1', '#c6dbef', '#e6550d',
        '#fd8d3c', '#fdae6b', '#fdd0a2', '#31a354', '#74c476',
        '#a1d99b', '#c7e9c0', '#756bb1', '#9e9ac8', '#bcbddc',
        '#dadaeb', '#636363', '#969696', '#bdbdbd', '#d9d9d9',
        '#f0f0f0', '#a63603', '#e6550d', '#fd8d3c', '#fdae6b',
        '#fdd0a2', '#31a354', '#74c476', '#a1d99b', '#c7e9c0',
        '#756bb1', '#9e9ac8', '#bcbddc', '#dadaeb', '#636363',
        '#969696', '#bdbdbd', '#d9d9d9', '#f0f0f0', '#6a3d9a',
        '#8e7cc3', '#b5a0d8', '#ce6dbd', '#de9ed6', '#f1b6da',
        '#fde0ef', '#3182bd', '#6baed6', '#9ecae1', '#c6dbef'
    ]
    return mcolors.ListedColormap(colors)

def draw_gantt_chart_ch3(JobShop, save_path=None):
    """
    第三章专用甘特图绘制函数（仅包含普通工序，无维护与故障）
    矩形上的数字依次表示：工件号-工序号 (例如: 1-1, 2-3)
    """
    fig, ax = plt.subplots(figsize=(16, 8))
    # 使用 tab20 颜色映射，最多支持 20 种高辨识度颜色，同一个工件使用同一种颜色
    colormap = plt.cm.get_cmap('tab20')

    machine_ids_plotted = [] # 用于记录Y轴刻度

    for machine in JobShop.machines:
        m_id = machine.machine_id
        machine_ids_plotted.append(m_id)

        # 检查该机器是否有已加工的工序
        if not hasattr(machine, '_processed_operations') or not machine._processed_operations:
            continue

        for operation_data in machine._processed_operations:
            start = operation_data['start_time']
            end = operation_data['end_time']
            duration = end - start
            op_obj = operation_data['operation']

            # 1. 获取颜色：根据工件ID分配颜色，保证同一工件块颜色一致
            color = colormap(op_obj.job_id % 20)

            # 2. 绘制普通工序矩形块
            ax.broken_barh([(start, duration)], (m_id - 0.4, 0.8),
                           facecolors=color, edgecolor='black', alpha=0.8)

            # 3. 添加文字标签：工件号-工序号 (例如: 1-1, 2-3)
            # 为了防止方块太小字挤在一起，可以加一个简单的宽度判断
            # 3. 添加文字标签：工件号-工序号 (例如: 1-1, 2-3)
            if duration > 1:
                label_text = f"{op_obj.job_id + 1}-{op_obj.operation_id + 1}"  # 从1开始编号
                ax.text(start + duration / 2, m_id, label_text,
                        ha='center', va='center', fontsize=9, color='black', fontweight='bold')

    # --- 样式设置 ---
    ax.set_yticks(machine_ids_plotted)
    ax.set_yticklabels([f'M{m_id}' for m_id in machine_ids_plotted])
    ax.set_xlabel('Time', fontsize=12, fontweight='bold')
    ax.set_ylabel('Machine', fontsize=12, fontweight='bold')

    # 添加网格线辅助对齐时间
    ax.grid(axis='x', linestyle='--', alpha=0.5)

    if save_path:
        plt.savefig(save_path, bbox_inches='tight', dpi=300)
    plt.close(fig)

def draw_gantt_chart_ch4(JobShop, save_path=None):
    """
    第四章专用：优化了颜色冲突、窄块标签显示以及维护任务辨识度
    """
    fig, ax = plt.subplots(figsize=(16, 8))

    # 获取 tab20 颜色并过滤掉接近灰色的颜色（索引 14, 15, 18, 19 通常是灰色系）
    base_colors = plt.cm.tab20.colors
    filtered_colors = [c for i, c in enumerate(base_colors) if i not in [14, 15, 17, 18, 19]]
    num_colors = len(filtered_colors)

    for machine in JobShop.machines:
        m_id = machine.machine_id
        if not hasattr(machine, '_processed_operations') or not machine._processed_operations:
            continue

        for operation_data in machine._processed_operations:
            start = operation_data['start_time']
            end = operation_data['end_time']
            duration = end - start
            op_obj = operation_data['operation']

            # --- 1. 识别并绘制维护任务 (OM / CBM) ---
            if hasattr(op_obj, 'pm_type') and op_obj.pm_type:
                is_cbm = (op_obj.pm_type == 'CBM')
                # CBM深灰+白色斜纹，OM浅灰+黑色点纹
                pm_color = '#4d4d4d' if is_cbm else '#e0e0e0'
                hatch_pattern = '///' if is_cbm else '...'

                ax.broken_barh([(start, duration)], (m_id - 0.4, 0.8),
                               facecolors=pm_color, edgecolor='black',
                               hatch=hatch_pattern, alpha=1.0, zorder=3)

                # 维护块文字显示策略
                if duration > 8:
                    ax.text(start + duration / 2, m_id, op_obj.pm_type,
                            ha='center', va='center', fontsize=9,
                            color='white' if is_cbm else 'black', fontweight='bold')
                elif duration > 4:
                    ax.text(start + duration / 2, m_id, op_obj.pm_type,
                            ha='center', va='center', fontsize=7,
                            color='white' if is_cbm else 'black')
                continue

            # --- 2. 绘制普通工序 ---
            # 使用过滤后的颜色，确保不与灰色冲突
            color = filtered_colors[op_obj.job_id % num_colors]
            ax.broken_barh([(start, duration)], (m_id - 0.4, 0.8),
                           facecolors=color, edgecolor='black', alpha=0.85)

            # --- 3. 标签显示策略（解决挤在一起的问题） ---
            label_text = f"{op_obj.job_id + 1}-{op_obj.operation_id + 1}"

            if duration > 12:
                # 宽块：正常显示
                ax.text(start + duration / 2, m_id, label_text,
                        ha='center', va='center', fontsize=9, color='black', fontweight='bold')
            elif duration > 6:
                # 中等块：缩减字号
                ax.text(start + duration / 2, m_id, label_text,
                        ha='center', va='center', fontsize=7, color='black')
            elif duration > 3:
                # 窄块：仅显示 Job ID 以节省空间
                ax.text(start + duration / 2, m_id, f"{op_obj.job_id + 1}",
                        ha='center', va='center', fontsize=6, color='black')
            # 持续时间 <= 3 的块不显示文字，避免重叠

    # 样式设置
    ax.set_yticks([m.machine_id for m in JobShop.machines])
    ax.set_yticklabels([f'M{m.machine_id}' for m in JobShop.machines])
    ax.set_xlabel('Time', fontweight='bold', fontsize=12)
    ax.set_ylabel('Machine', fontsize=12, fontweight='bold')
    ax.grid(axis='x', linestyle='--', alpha=0.3)


    # 设置 X 轴范围留出一点空白
    ax.set_axisbelow(True)

    # # --- 4. 优化图例 ---
    # # 增加工序样例图例和维护图例
    # legend_elements = [
    #     mpatches.Patch(facecolor='#e0e0e0', edgecolor='black', hatch='...', label='Opportunity Maint. (OM)'),
    #     mpatches.Patch(facecolor='#4d4d4d', edgecolor='black', hatch='///', label='Condition-based Maint. (CBM)')
    # ]
    # ax.legend(handles=legend_elements, loc='upper right', frameon=True, shadow=True, fontsize=10)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight', dpi=600)  # 提高DPI使小字清晰
    plt.close(fig)


def draw_gantt_chart_ch5(JobShop, save_path=None):
    """
    第五章专用：修复了故障遮挡工序和标签显示不全的问题。
    """
    fig, ax = plt.subplots(figsize=(16, 8))

    # 1. 颜色配置：过滤掉灰色系和红色系，确保生产工序颜色鲜明
    base_colors = plt.cm.tab20.colors
    # 过滤掉 tab20 中的红色(6,7)和灰色/杂色(14-19)
    filtered_colors = [c for i, c in enumerate(base_colors) if i not in [6, 7, 14, 15, 17, 18, 19]]
    num_colors = len(filtered_colors)

    for machine in JobShop.machines:
        m_id = machine.machine_id

        # --- 1. 绘制突发故障 (Machine Breakdown) ---
        # 【关键修复】：确保数据解析为 (开始时间, 结束时间) 并计算时长
        if hasattr(machine, 'breakdown_windows') and machine.breakdown_windows:
            for bd_window in machine.breakdown_windows:
                bd_start, bd_end = bd_window  # 假设数据格式是 (start, end)
                bd_duration = bd_end - bd_start

                # 绘制红色故障块
                # zorder=5 确保它在最上层，但正确的 bd_duration 保证它不会错误遮挡后面的工序
                ax.broken_barh([(bd_start, bd_duration)], (m_id - 0.4, 0.8),
                               facecolors='#ff4d4d', edgecolor='darkred',
                               hatch='///', alpha=0.7, zorder=5)

                # 故障标签显示
                if bd_duration > 2:
                    ax.text(bd_start + bd_duration / 2, m_id, 'BREAKDOWN',
                            ha='center', va='center', fontsize=9,
                            color='white', fontweight='bold', zorder=10)

        # --- 2. 遍历已处理的工序 (含维护和普通工序) ---
        if not hasattr(machine, '_processed_operations') or not machine._processed_operations:
            continue

        for operation_data in machine._processed_operations:
            start = operation_data['start_time']
            end = operation_data['end_time']
            duration = end - start
            op_obj = operation_data['operation']

            # --- A. 识别并绘制维护任务 (OM / CBM) ---
            if hasattr(op_obj, 'pm_type') and op_obj.pm_type:
                is_cbm = (op_obj.pm_type == 'CBM')
                pm_color = '#4d4d4d' if is_cbm else '#e0e0e0'
                hatch_pattern = '\\\\' if is_cbm else '...'

                ax.broken_barh([(start, duration)], (m_id - 0.4, 0.8),
                               facecolors=pm_color, edgecolor='black',
                               hatch=hatch_pattern, alpha=1.0, zorder=3)

                # 维护标签显示门槛降低到 1
                if duration > 1:
                    ax.text(start + duration / 2, m_id, op_obj.pm_type,
                            ha='center', va='center', fontsize=8,
                            color='white' if is_cbm else 'black', fontweight='bold', zorder=4)
                continue

            # --- B. 绘制普通生产工序 ---
            color = filtered_colors[op_obj.job_id % num_colors]
            ax.broken_barh([(start, duration)], (m_id - 0.4, 0.8),
                           facecolors=color, edgecolor='black', alpha=0.8, zorder=2)

            # --- 标签显示策略修复 ---
            # 【关键修改】：大幅降低显示门槛，确保小工序也能看到编号
            label_text = f"{op_obj.job_id + 1}-{op_obj.operation_id + 1}"
            if duration > 5:
                ax.text(start + duration / 2, m_id, label_text,
                        ha='center', va='center', fontsize=9, color='black', fontweight='bold', zorder=4)
            elif duration > 1:
                ax.text(start + duration / 2, m_id, label_text,
                        ha='center', va='center', fontsize=7, color='black', zorder=4)

    # 样式美化
    ax.set_yticks([m.machine_id for m in JobShop.machines])
    ax.set_yticklabels([f'M{m.machine_id}' for m in JobShop.machines])
    ax.set_xlabel('Time', fontweight='bold', fontsize=12)
    ax.set_ylabel('Machine', fontsize=12, fontweight='bold')
    ax.grid(axis='x', linestyle='--', alpha=0.3)

    # # 3. 建立图例
    # legend_elements = [
    #     mpatches.Patch(facecolor='#ff4d4d', edgecolor='darkred', hatch='///', label='Machine Breakdown'),
    #     mpatches.Patch(facecolor='#4d4d4d', edgecolor='black', label='Maintenance (CBM/OM)'),
    #     mpatches.Patch(facecolor='white', edgecolor='black', label='Production Job')
    # ]
    # ax.legend(handles=legend_elements, loc='upper right')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight', dpi=300)
    plt.close(fig)

def draw_precedence_relations(JobShop: JobShop):
    colormap = create_colormap()

    precedence_relations = copy.deepcopy(JobShop.precedence_relations_operations)
    G = nx.DiGraph()

    for key, value in precedence_relations.items():
        value = [i.operation_id for i in value]
        precedence_relations.update({key: value})

    for key, value in precedence_relations.items():
        for i in range(len(value)):
            G.add_edge(value[i], key)

    left_nodes, right_nodes, middle_nodes = [], [], {}

    for node in G.nodes:
        if precedence_relations[node] == []:
            left_nodes.append(node)

    for node in G.nodes:
        final = True
        for key, value in precedence_relations.items():
            if node in value:
                final = False
        if final:
            right_nodes.append(node)

    max_length = 0
    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))
            middle_nodes[length] = []
            if length > max_length:
                max_length = length

    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))
            middle_nodes[length].append(node)

    # set the position of nodes with no predecessor (x-coord)
    pos = {n: (0, i) for i, n in enumerate(left_nodes)}

    # set position of nodes with no successor
    if (max_length + 1 % 2) == 0:
        pos.update({n: (max_length + 1, i) for i, n in enumerate(right_nodes)})
    else:
        pos.update({n: (max_length + 1, i + 0.5)
                    for i, n in enumerate(right_nodes)})

    # set position of all 'middle' nodes (according to number of predecessors)
    for key, value in middle_nodes.items():
        if (key % 2) == 0:
            pos.update({n: (max_length - key + 1, i)
                        for i, n in enumerate(value)})
        else:
            pos.update({n: (max_length - key + 1, i + 0.5)
                        for i, n in enumerate(value)})

    options = {
        "font_size": 8,
        "node_size": 500,
        "node_color": [],
        "edgecolors": "black",
        "linewidths": 1,
        "width": 1,
    }

    # Assign colors to nodes based on their properties
    for node in G.nodes:
        options["node_color"].append(colormap(JobShop.get_operation(node).job_id % colormap.N))

    nx.draw_networkx(G, pos, **options)

    ax = plt.gca()
    ax.margins(0.20)

    fig = ax.figure
    fig.set_size_inches(16, 8)

    plt.axis("off")
    plt.close(fig)
