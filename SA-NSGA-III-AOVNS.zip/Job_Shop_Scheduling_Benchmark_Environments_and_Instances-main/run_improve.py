import argparse
import logging
import multiprocessing
import time
import os

os.environ['MKL_NUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import copy
import random

import numpy as np
import matplotlib.pyplot as plt
from deap import base, creator, tools


# --- 导入你的 AOS-NSGA-III 相关的算子 ---
from solutions.genetic_algorithm.operators import (
    init_individual, init_population, repair_precedence_constraints,
    mutate_shortest_proc_time, mutate_sequence_exchange, pox_crossover,
    simulated_annealing_double, insertion_search, inversion_search, variation_adaptive,
    variation, pm_avoidance_search,
    pm_threshold_tuning_operator
)

# --- 导入新创建的 ETMA-Lite 算法组件 ---
from solutions.ETMA.etma_operators import (
    VNS_lite, potential_solution_selection, energy_saving_right_shift,
    Structured_MOVNS, initialize_population_etma
)
# --- 导入新的带老化效应的评估函数 ---
from solutions.genetic_algorithm.operators import evaluate_individual_double

# --- 其他通用导入 ---
from solutions.NSGA3.nsga3 import divide, select_FL, point_ideal1, association, select, uniformpoint
from plotting.drawer import draw_gantt_chart_ch3, draw_precedence_relations
from solutions.helper_functions import record_stats, load_parameters, load_job_shop_env

logging.basicConfig(level=logging.INFO)
# logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

PARAM_FILE = "configs/genetic_algorithm.toml"
DEFAULT_RESULTS_ROOT = os.path.join(".", "results", "comparison_runs")

base_worker_env_template = None  #


def init_worker(base_env_to_copy):
    """每个工作进程启动时调用一次，用来接收并存储一个干净的环境模板。"""
    global base_worker_env_template
    # 直接存储传入的模板对象，它本身是干净的
    base_worker_env_template = base_env_to_copy

def evaluate_on_worker(individual):
    # 直接使用全局的环境模板（不用拷贝）
    global base_worker_env_template

    # 瞬间重置状态（毫秒级），代替耗时的深拷贝（秒级）
    base_worker_env_template.reset()

    makespan, total_power, _ = evaluate_individual_double(individual, base_worker_env_template)
    return makespan, total_power

def generate_comparison_plots(all_results, save_dir):

    logging.info("\n" + "=" * 25 + " Generating All Comparison Plots " + "=" * 25)
    os.makedirs(save_dir, exist_ok=True)

    # --- 1. 定义所有算法的绘图样式 ---
    # 您可以根据实际运行的算法名称修改这里的键
    styles = {
        'nsga3': {'color': 'blue', 'linestyle': '-', 'marker': 'o', 'label': 'MOVNS-NSGA-III'},
    }

    # --- 2. 绘制收敛曲线对比图 (双子图) ---
    logging.info("Generating convergence comparison plot...")
    fig_conv, (ax1_conv, ax2_conv) = plt.subplots(2, 1, figsize=(14, 12), sharex=True)

    for algo_name, result_data in all_results.items():
        # 确保算法在样式定义中，并且有收敛数据
        if algo_name in styles and 'min_makespans' in result_data and 'min_energies' in result_data:
            style = styles[algo_name]
            # 绘制 Makespan 收敛曲线
            ax1_conv.plot(result_data['min_makespans'], color=style['color'], linestyle=style['linestyle'],
                          label=style['label'])
            # 绘制 Energy 收敛曲线
            ax2_conv.plot(result_data['min_energies'], color=style['color'], linestyle=style['linestyle'],
                          label=style['label'])

    ax1_conv.set_title('Makespan Convergence Comparison', fontsize=14)
    ax1_conv.set_ylabel('Best Makespan')
    ax1_conv.legend()
    ax1_conv.grid(True, linestyle='--', alpha=0.7)

    ax2_conv.set_title('Energy Convergence Comparison', fontsize=14)
    ax2_conv.set_xlabel('Generation', fontsize=12)
    ax2_conv.set_ylabel('Best Energy')
    ax2_conv.legend()
    ax2_conv.grid(True, linestyle='--', alpha=0.7)

    fig_conv.tight_layout()
    convergence_plot_path = os.path.join(save_dir, "comparison_convergence_subplots.png")
    plt.savefig(convergence_plot_path, dpi=300)
    plt.close(fig_conv)
    logging.info(f"-> Convergence plot saved to: {convergence_plot_path}")

    # --- 3. 绘制帕累托前沿对比图 (散点图) ---
    logging.info("Generating Pareto front comparison plot...")
    fig_pf, ax_pf = plt.subplots(figsize=(12, 9))

    for algo_name, result_data in all_results.items():
        if algo_name in styles and 'pareto_front' in result_data:
            style = styles[algo_name]
            # 从 DEAP 的 ParetoFront 对象中提取适应度值
            pf = np.array([ind.fitness.values for ind in result_data['pareto_front']])
            if pf.size > 0:
                ax_pf.scatter(pf[:, 0], pf[:, 1], c=style['color'], marker=style['marker'], s=100, alpha=0.8,
                              label=f"{style['label']} (n={len(pf)})", edgecolors='black')

    ax_pf.set_title('Final Pareto Front Comparison', fontsize=16)
    ax_pf.set_xlabel('Makespan (Lower is Better)', fontsize=12)
    ax_pf.set_ylabel('Total Energy (Lower is Better)', fontsize=12)
    ax_pf.legend()
    ax_pf.grid(True, linestyle='--', alpha=0.7)

    fig_pf.tight_layout()
    pareto_plot_path = os.path.join(save_dir, "comparison_pareto_front.png")
    plt.savefig(pareto_plot_path, dpi=300)
    plt.close(fig_pf)
    logging.info(f"-> Pareto front plot saved to: {pareto_plot_path}")

    # --- 4. 绘制 Hypervolume 迭代对比图 ---
    logging.info("Generating Hypervolume comparison plot...")
    fig_hv, ax_hv = plt.subplots(figsize=(12, 8))

    for algo_name, result_data in all_results.items():
        # 确保数据存在
        if algo_name in styles and 'hv_history' in result_data:
            style = styles[algo_name]
            hv_data = result_data['hv_history']

            # 绘制曲线
            ax_hv.plot(hv_data, color=style['color'], linestyle=style['linestyle'],
                       linewidth=2, marker=style.get('marker', ''), markevery=max(1, len(hv_data) // 10),
                       label=style['label'])

    ax_hv.set_title('Hypervolume Convergence (Normalized)', fontsize=16)
    ax_hv.set_xlabel('Generation', fontsize=12)
    ax_hv.set_ylabel('Hypervolume (Higher is Better)', fontsize=12)
    ax_hv.legend(fontsize=12)
    ax_hv.grid(True, linestyle='--', alpha=0.7)

    fig_hv.tight_layout()
    hv_plot_path = os.path.join(save_dir, "comparison_hypervolume.png")
    plt.savefig(hv_plot_path, dpi=300)
    plt.close(fig_hv)
    logging.info(f"-> Hypervolume plot saved to: {hv_plot_path}")

    logging.info(f"✅ All comparison plots saved to directory: {save_dir}")

# --- DEAP 初始化函数 (为两个算法提供通用工具) ---
def initialize_run(pool: multiprocessing.Pool, jobShopEnv, **kwargs):
    toolbox = base.Toolbox()
    toolbox.register("map", pool.map, evaluate_on_worker)

    # --- 【修改】: 在创建前删除旧的定义以消除警告 ---
    # 检查 creator 中是否已经有名为 'Fitness' 的属性
    if hasattr(creator, "Fitness"):
        del creator.Fitness
    # 检查 creator 中是否已经有名为 'Individual' 的属性
    if hasattr(creator, "Individual"):
        del creator.Individual
    # -----------------------------------------------------

    creator.create("Fitness", base.Fitness, weights=(-1.0, -1.0))
    creator.create("Individual", list, fitness=creator.Fitness)

    # 注册带老化效应的评估函数
    toolbox.register("evaluate_individual_double", evaluate_individual_double, jobShopEnv=jobShopEnv)

    # 注册通用算子
    toolbox.register("init_individual", init_individual, creator.Individual, kwargs, jobShopEnv=jobShopEnv)
    toolbox.register("population", init_population, toolbox, kwargs['algorithm']['population_size'])
    toolbox.register("mate_POX", pox_crossover, nr_preserving_jobs=1)
    toolbox.register("mate_TwoPoint", tools.cxTwoPoint)
    toolbox.register("mate_Uniform", tools.cxUniform, indpb=0.5)
    toolbox.register("mutate_machine_selection", mutate_shortest_proc_time, jobShopEnv=jobShopEnv)
    toolbox.register("mutate_operation_sequence", mutate_sequence_exchange)

    # 注册选择算子
    toolbox.register("select_for_mating", tools.selNSGA2)  # MAB-MA 使用
    toolbox.register("select_tournament", tools.selTournament, tournsize=2)  # ETMA 使用
    toolbox.register("select_environmental", tools.selNSGA2)  # ETMA 使用

    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("std", np.std, axis=0)
    stats.register("min", np.min, axis=0)
    stats.register("max", np.max, axis=0)
    hof = tools.ParetoFront()

    # --- 【核心修正】: 移除ETMA的专属初始化，让所有算法使用统一的、可靠的初始化方法 ---
    algorithm_type = kwargs.get('algorithm_type', 'nsga3')

    # if algorithm_type == 'etma_lite':
    #     logging.info("Using ETMA's specific initialization method.")
    #     initial_population = initialize_population_etma(...)
    # else:
    #     logging.info("Using the general initialization method.")
    #     initial_population = toolbox.population()

    # 统一使用你的通用初始化方法
    logging.info("Using the unified general initialization method for all algorithms.")
    initial_population = toolbox.population()

    logging.info(f"Evaluating initial population of size {len(initial_population)}...")
    fitnesses = toolbox.map(initial_population)
    for ind, fit in zip(initial_population, fitnesses):
        ind.fitness.values = fit

    hof.update(initial_population)

    return initial_population, toolbox, stats, hof

def algo_run_nsga3_movns(jobShopEnv, population, toolbox, stats, hof, **kwargs):

    logging.info("==========================================================")
    logging.info("       Starting NSGA-III with MOVNS (Static Mode)         ")
    logging.info("==========================================================")

    gen = 0
    try:
        # --- 1. 初始化统计 ---
        logbook = tools.Logbook()
        min_makespans, min_energies, hv_history = [], [], []
        logbook.header = ["gen"] + (stats.fields if stats else [])
        log_file = kwargs.get('output', {}).get('logbook_file')

        # 初始种群评估
        population = [ind for ind in population if ind.fitness.valid]
        if not population:
            logging.error("No valid individuals in initial population.")
            return None, [], [], []

        hof.update(population)
        record_stats(0, population, logbook, stats, log_file, [], logging, header=True)

        # NSGA-III 参数
        pop_size = kwargs['algorithm']['population_size']
        num_ref_points = max(2, int(pop_size / 10))
        uniformPoint = uniformpoint(num_ref_points, 2)

        # --- 2. 算法主循环 ---
        for gen in range(1, kwargs['algorithm']['ngen'] + 1):
            gentime = time.time()

            # A. 变异阶段 (调用修复后的 variation_adaptive)
            mating_pool = toolbox.select_for_mating(population, k=pop_size)
            offspring = variation_adaptive(
                mating_pool, toolbox,
                kwargs['algorithm']['cr'],
                kwargs['algorithm']['indpb'],
                jobShopEnv
            )

            # B. 修复约束 (如有)
            if any(path in jobShopEnv.instance_name for path in ['/dafjs/', '/yfjs/']):
                offspring = repair_precedence_constraints(jobShopEnv, offspring)

            # C. 评估无效个体
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            if invalid_ind:
                fitnesses = toolbox.map(invalid_ind)
                for ind, fit in zip(invalid_ind, fitnesses):
                    ind.fitness.values = fit

            # D. 环境选择 (NSGA-III)
            combined_pop = [ind for ind in offspring if ind.fitness.valid] + population
            # 注意：此处使用你定义的 select_FL 逻辑
            population, FL_individuals, num_select = select_FL(
                pop_size,
                divide([ind.fitness.values for ind in combined_pop]),
                combined_pop
            )

            # --- 填充 population 到 pop_size (参考点关联逻辑) ---
            if num_select > 0 and FL_individuals:
                answer_pop = [ind.fitness.values for ind in population]
                ideal_point = np.min([ind.fitness.values for ind in (population + FL_individuals)], axis=0)

                # 理想点处理与关联逻辑
                if answer_pop:
                    ideal_answer_pop, _ = point_ideal1(answer_pop, ideal_point)
                    point_assoc_pop, _ = association(ideal_answer_pop, uniformPoint)
                else:
                    point_assoc_pop = []

                answer_fl = [ind.fitness.values for ind in FL_individuals]
                ideal_answer_fl, _ = point_ideal1(answer_fl, ideal_point)
                point_assoc_fl, d_min_fl = association(ideal_answer_fl, uniformPoint)
                sel_ind = select(num_select, point_assoc_fl, point_assoc_pop, d_min_fl)
                for indx in sel_ind:
                    population.append(FL_individuals[indx])

            # E. 更新 HOF
            hof.update(population)

            # F. 代际精英强化
            if gen % 5 == 0 and len(hof) > 0:
                logging.info(f"Gen {gen}: MOVNS Reinforcing Elites...")
                elites = random.sample(list(hof), min(3, len(hof)))
                for elite in elites:
                    # 这里的 Structured_MOVNS 必须返回个体对象
                    result = Structured_MOVNS(elite, toolbox, jobShopEnv)

                    # 【关键修复】：判断返回的是个体还是 (个体, 适应度) 元组
                    if isinstance(result, tuple):
                        enhanced_ind = result[0]  # 取得个体
                        # 如果元组里有适应度，顺便更新它
                        if len(result) > 1 and isinstance(result[1], tuple):
                            enhanced_ind.fitness.values = result[1]
                    else:
                        enhanced_ind = result

                    # 确保 fitness 是有效的，如果无效则重新评估
                    if not enhanced_ind.fitness.valid:
                        enhanced_ind.fitness.values = toolbox.evaluate(enhanced_ind)

                    # 替换种群中的个体
                    population[random.randint(0, pop_size - 1)] = enhanced_ind

                # 强化后立即更新一次 HOF
                hof.update(population)

            # G. 记录
            record_stats(gen, population, logbook, stats, log_file, [], logging, header=False)

            # === 【关键修正：采集每一代的收敛数据】 ===
            if hof:
                min_makespans.append(min(ind.fitness.values[0] for ind in hof))
                min_energies.append(min(ind.fitness.values[1] for ind in hof))
            else:
                min_makespans.append(min(ind.fitness.values[0] for ind in population))
                min_energies.append(min(ind.fitness.values[1] for ind in population))
            # ========================================

            logging.info(f"--- Gen {gen} Finish. Time: {time.time() - gentime:.2f}s, Best M: {min_makespans[-1]} ---")

        # --- 3. Stage 2: 最终右移节能 ---
        logging.info("\n--- Final Energy Saving Optimization ---")
        final_solutions = list(hof)
        for i in range(len(final_solutions)):
            temp_env = copy.deepcopy(jobShopEnv)
            _, _, sched_env = toolbox.evaluate_individual_double(final_solutions[i], jobShopEnv=temp_env)
            final_solutions[i] = energy_saving_right_shift(final_solutions[i], sched_env, toolbox)

        hof.clear()
        hof.update(final_solutions)
        return hof, min_makespans, min_energies, hv_history

    except Exception as e:
        logging.error(f"Critical error at gen {gen}: {e}", exc_info=True)
        return None, [], [], []

# =================================================================
# 主函数和启动器 (最终重构版)【使用统一绘图函数】
# =================================================================
def main(param_file=PARAM_FILE):
    # 1. 解析命令行参数
    parser = argparse.ArgumentParser(description="Run Comparison for Job Shop Scheduling")
    parser.add_argument("config_file", metavar='-f', type=str, nargs="?", default=param_file)
    args = parser.parse_args()

    # 2. 加载参数和【原始】环境模板
    parameters = load_parameters(args.config_file)
    base_jobShopEnv = load_job_shop_env(parameters['instance']['problem_instance'])

    # 3. 构建一个通用的、本次对比实验的根目录
    # --- 【新修改】: 获取当前运行的脚本文件名作为一级目录 ---
    script_filename = os.path.basename(__file__)  # 获取 'run_comparison.py'
    script_name_str, _ = os.path.splitext(script_filename)  # 获取 'run_comparison'
    # 3. 【核心修改】：构建按数据集分类的目录结构
    instance_full_path = parameters['instance']['problem_instance']
    instance_basename = os.path.basename(instance_full_path)
    problem_name_str, _ = os.path.splitext(instance_basename)  # 如 0DAFJS05

    # 构造具体某一次运行的文件夹名称 (带参数和时间戳)
    params_str = f"ngen{parameters['algorithm']['ngen']}_pop{parameters['algorithm']['population_size']}"
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    run_folder_name = f"{params_str}_{timestamp}"

    # 构建最终路径：results/comparison_runs/0DAFJS05/ngen300_pop100_时间戳/
    comparison_base_path = os.path.abspath(os.path.join(DEFAULT_RESULTS_ROOT, problem_name_str, run_folder_name))

    os.makedirs(comparison_base_path, exist_ok=True)
    logging.info(f"All comparison results for this run will be saved under: {comparison_base_path}")

    # 定义要运行的算法及其对应的执行函数
    algorithms_to_run = {
        "nsga3": algo_run_nsga3_movns,
    }

    # --- 【修改点】: 这个字典现在要存储更多信息以供绘图函数使用 ---
    all_algorithm_results = {}

    # 4. 启动并行池
    with multiprocessing.Pool(processes=parameters['algorithm'].get('processes', 11),
                              initializer=init_worker,
                              initargs=(base_jobShopEnv,)) as pool:

        # 循环运行每个定义的算法
        for algo_name, algo_function in algorithms_to_run.items():
            logging.info("\n" + "=" * 80)
            logging.info(f"             STARTING ALGORITHM: {algo_name.upper()}             ")
            logging.info("=" * 80)

            algo_exp_path = os.path.join(comparison_base_path, algo_name)
            os.makedirs(algo_exp_path, exist_ok=True)
            log_file_path = os.path.join(algo_exp_path, "convergence_log.csv")
            if 'output' not in parameters: parameters['output'] = {}
            parameters['output']['logbook_file'] = log_file_path

            current_run_env = copy.deepcopy(base_jobShopEnv)
            current_run_params = copy.deepcopy(parameters)

            population, toolbox, stats, hof = initialize_run(pool, current_run_env, **current_run_params)

            # 调用算法
            result = algo_function(
                current_run_env, population, toolbox, stats, hof, **current_run_params)

            # 【修改】解包 4 个返回值
            final_pareto_front, min_makespans, min_energies, hv_history = result

            # 【新增：保存 HV 历史到文件】
            hv_file_path = os.path.join(algo_exp_path, "hv_history.csv")
            np.savetxt(hv_file_path, np.array(hv_history), delimiter=",", header="hv", comments="")
            logging.info(f"✅ ==> HV history saved to: {hv_file_path}")

            # 【修改】存储结果
            if final_pareto_front is not None:
                all_algorithm_results[algo_name] = {
                    'min_makespans': min_makespans,
                    'min_energies': min_energies,
                    'hv_history': hv_history,  # <--- 保存 HV 数据
                    'pareto_front': final_pareto_front
                }

            # --- 单个算法的结果处理（如保存PF数据和甘特图）保持不变 ---
            if not final_pareto_front:
                logging.warning(f"Algorithm '{algo_name}' finished with errors or empty HOF.")
                continue

            logging.info(f"\n--- Processing individual results for {algo_name.upper()} ---")
            pf_filename = f"{problem_name_str}_pareto_front.txt"
            output_path = os.path.join(algo_exp_path, pf_filename)
            try:
                final_pf_values = np.array([ind.fitness.values for ind in final_pareto_front])
                np.savetxt(output_path, final_pf_values, fmt='%.4f', header="Makespan Energy", comments="")
                logging.info(f"✅ ==> Individual Pareto front for {algo_name.upper()} saved to: {output_path}")
            except Exception as e:
                logging.error(f"Failed to save Pareto front data for {algo_name.upper()}: {e}")

            if parameters['output']['plotting']:
                best_makespan_ind = min(final_pareto_front, key=lambda ind: ind.fitness.values[0])
                final_clean_env_for_plot = copy.deepcopy(base_jobShopEnv)

                # 1. 生成初始的左移调度环境
                makespan, total_power, drawn_env = evaluate_individual_double(
                    best_makespan_ind, final_clean_env_for_plot
                )

                logging.info(
                    f"Initial (Left-Shift) Stats for {algo_name.upper()}: Makespan={makespan}, Energy={total_power}")

                logging.info(f"Applying Right-Shift to generate the final Gantt chart for {algo_name.upper()}...")
                try:

                    _ = energy_saving_right_shift(best_makespan_ind, drawn_env, toolbox)

                    final_makespan = drawn_env.makespan
                    final_power = drawn_env.total_machinepower
                    logging.info(f"Final (Right-Shift) Stats: Makespan={final_makespan}, Energy={final_power}")

                except Exception as e:
                    logging.warning(
                        f"Right-shift application failed during plotting: {e}. Plotting left-shift chart instead.")

                gantt_filename = f"gantt_chart_best_makespan.png"
                gantt_path = os.path.join(algo_exp_path, gantt_filename)

                draw_gantt_chart_ch3(drawn_env, save_path=gantt_path)

    if not all_algorithm_results:
        logging.error("All algorithm runs failed. No data available for comparison plotting. Exiting.")
        return

    generate_comparison_plots(all_algorithm_results, save_dir=comparison_base_path)

    logging.info("\nComparison run finished successfully.")


if __name__ == "__main__":
    main()
