import numpy as np
import random
import logging
import json
import os


class QLearningHybridAgent:
    """
    一个混合Q-learning代理，结合了两种自适应策略：
    1. 主要策略：基于个体适应度排名（微观状态）来选择算子。
    2. 元策略：基于种群宏观表现（宏观状态）来动态调整探索率epsilon。
    """

    def __init__(self, actions, num_objectives=2, num_ranks=3, alpha=0.1, gamma=0.9,
                 base_epsilon=0.05, high_epsilon=0.3):
        self.actions = actions
        self.num_objectives = num_objectives
        self.num_ranks = num_ranks
        self.alpha = alpha  # 学习率
        self.gamma = gamma  # 折扣因子
        self.base_epsilon = base_epsilon  # 基础探索率
        self.high_epsilon = high_epsilon  # 停滞时的高探索率
        self.current_epsilon = base_epsilon  # 当前有效的探索率
        self.q_table = {}

        # --- 用于宏观状态分析的属性 ---
        self.previous_best_fitness = None
        self.previous_diversity = None

        logging.info("Hybrid QLearningAgent initialized.")
        logging.info(f"Epsilon range: [{self.base_epsilon}, {self.high_epsilon}]")

    # ==================================================================
    # 1. 微观状态处理 (基于个体排名) - 主要决策机制
    # ==================================================================
    def get_individual_states(self, population):
        """
        为种群中的每个个体计算其基于排名的状态（微观状态）。
        返回: dict {individual_index: state_tuple}
        """
        pop_size = len(population)
        if pop_size == 0:
            return {}

        sorted_indices = []
        for i in range(self.num_objectives):
            s_indices = sorted(range(pop_size), key=lambda k: population[k].fitness.values[i])
            sorted_indices.append(s_indices)

        ranks = np.zeros((pop_size, self.num_objectives), dtype=int)
        rank_size = pop_size / self.num_ranks
        for i in range(pop_size):
            for obj_idx in range(self.num_objectives):
                pos = sorted_indices[obj_idx].index(i)
                rank = int(pos // rank_size) + 1
                ranks[i, obj_idx] = min(rank, self.num_ranks)

        return {i: tuple(ranks[i]) for i in range(pop_size)}

    def choose_action(self, state):
        """
        根据微观状态（个体排名）使用 epsilon-greedy策略选择一个动作。
        注意：它使用 self.current_epsilon，这个值是动态调整的。
        """
        if random.random() < self.current_epsilon:
            return random.choice(list(range(len(self.actions))))
        else:
            q_values = [self.get_q_value(state, i) for i in range(len(self.actions))]
            max_q = max(q_values)
            best_actions = [i for i, q in enumerate(q_values) if q == max_q]
            return random.choice(best_actions)

    def update_q_table_from_reward(self, state, action_idx, reward, next_state):
        """
        根据给定的奖励更新Q-table。这是简化的更新方式。
        """
        old_q_value = self.get_q_value(state, action_idx)
        next_max_q = max([self.get_q_value(next_state, i) for i in range(len(self.actions))])
        new_q_value = old_q_value + self.alpha * (reward + self.gamma * next_max_q - old_q_value)

        self.q_table.setdefault(state, {i: 0.0 for i in range(len(self.actions))})[action_idx] = new_q_value

    def get_q_value(self, state, action_idx):
        """安全地获取Q值，如果不存在则初始化为0.0。"""
        return self.q_table.get(state, {}).get(action_idx, 0.0)

    # ==================================================================
    # 2. 宏观状态处理 (基于种群表现) - 用于调整Epsilon
    # ==================================================================
    def update_epsilon_based_on_macro_state(self, population, generation):
        """
        分析种群宏观状态，并据此动态调整self.current_epsilon。
        """
        if generation <= 1:  # 早期保持基础探索率
            self.current_epsilon = self.base_epsilon
            return

        # 计算当前最优和多样性
        try:
            current_best_ind = min(population, key=lambda ind: ind.fitness.values[0])
            current_best_fitness = current_best_ind.fitness.values
            fitnesses = np.array([ind.fitness.values for ind in population])
            current_diversity = np.mean(np.std(fitnesses, axis=0))
        except (ValueError, IndexError):
            logging.warning("Could not calculate macro state due to invalid fitness values.")
            return  # 无法计算则不调整

        is_stagnant = False
        if self.previous_best_fitness is not None and self.previous_diversity is not None:
            # 判断是否停滞：没有改进 且 多样性降低
            # 改进判断：新的解是否支配旧的解
            is_improved = (current_best_fitness[0] < self.previous_best_fitness[0] and
                           current_best_fitness[1] <= self.previous_best_fitness[1]) or \
                          (current_best_fitness[0] <= self.previous_best_fitness[0] and
                           current_best_fitness[1] < self.previous_best_fitness[1])

            diversity_decreased = current_diversity < self.previous_diversity

            if not is_improved and diversity_decreased:
                is_stagnant = True

        # 更新历史记录
        self.previous_best_fitness = current_best_fitness
        self.previous_diversity = current_diversity

        # 动态调整Epsilon
        if is_stagnant:
            self.current_epsilon = self.high_epsilon
            logging.info(f"Stagnation detected. Epsilon increased to {self.current_epsilon}")
        else:
            self.current_epsilon = self.base_epsilon
            logging.info(f"Population is evolving. Epsilon set to {self.current_epsilon}")

    # ==================================================================
    # 3. 保存与加载
    # ==================================================================
    def save_q_table(self, filename="q_table_hybrid.json"):
        save_table = {str(k): v for k, v in self.q_table.items()}
        try:
            with open(filename, 'w') as f:
                json.dump(save_table, f, indent=4)
            logging.info(f"Q-table successfully saved to {filename}")
        except Exception as e:
            logging.error(f"Failed to save Q-table: {e}")

    def load_q_table(self, filename="q_table_hybrid.json"):
        if not os.path.exists(filename):
            logging.warning(f"Q-table file not found at {filename}. Starting with an empty table.")
            return
        try:
            with open(filename, 'r') as f:
                loaded_table = json.load(f)
                self.q_table = {eval(k): v for k, v in loaded_table.items()}
            logging.info(f"Q-table successfully loaded from {filename}")
        except Exception as e:
            logging.error(f"Failed to load Q-table: {e}")